import React, { createContext, useContext, useState, useEffect } from 'react';
import { Currency } from '../types';

export const SUPPORTED_CURRENCIES: Currency[] = [
  { code: 'USD', symbol: '$', name: 'US Dollar', position: 'prefix' },
  { code: 'EUR', symbol: '€', name: 'Euro', position: 'prefix' },
  { code: 'GBP', symbol: '£', name: 'British Pound', position: 'prefix' },
  { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar', position: 'prefix' },
  { code: 'AUD', symbol: 'AU$', name: 'Australian Dollar', position: 'prefix' },
  { code: 'TND', symbol: 'DT', name: 'Tunisian Dinar', position: 'suffix' },
];

interface CurrencyContextType {
  currency: Currency;
  setCurrencyCode: (code: string) => void;
  formatMoney: (amount: number) => string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currency, setCurrency] = useState<Currency>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('crexa_currency');
      const found = SUPPORTED_CURRENCIES.find((c) => c.code === stored);
      if (found) return found;
    }
    return SUPPORTED_CURRENCIES[0]; // USD default
  });

  useEffect(() => {
    localStorage.setItem('crexa_currency', currency.code);
  }, [currency]);

  const setCurrencyCode = (code: string) => {
    const found = SUPPORTED_CURRENCIES.find((c) => c.code === code);
    if (found) setCurrency(found);
  };

  const formatMoney = (amount: number): string => {
    if (!Number.isFinite(amount)) return `${currency.symbol}0.00`;
    const formatted = Math.abs(amount).toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    const sign = amount < 0 ? '-' : '';
    return currency.position === 'prefix'
      ? `${sign}${currency.symbol}${formatted}`
      : `${sign}${formatted} ${currency.symbol}`;
  };

  return (
    <CurrencyContext.Provider value={{ currency, setCurrencyCode, formatMoney }}>
      {children}
    </CurrencyContext.Provider>
  );
};

export function useCurrency(): CurrencyContextType {
  const ctx = useContext(CurrencyContext);
  if (!ctx) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return ctx;
}
