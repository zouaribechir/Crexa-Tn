import React from 'react';
import { RouterProvider, useRouter } from './context/RouterContext';
import { ThemeProvider } from './context/ThemeContext';
import { CurrencyProvider } from './context/CurrencyContext';
import { GoogleAnalytics } from './components/GoogleAnalytics';
import { Header } from './components/Header';
import { Footer } from './components/Footer';

// Pages
import { HomePage } from './pages/HomePage';
import { CalculatorsPage } from './pages/CalculatorsPage';
import { CategoryPage } from './pages/CategoryPage';
import { CalculatorDetailPage } from './pages/CalculatorDetailPage';
import { AboutPage } from './pages/AboutPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { TermsPage } from './pages/TermsPage';
import { SitemapPage } from './pages/SitemapPage';
import { NotFoundPage } from './pages/NotFoundPage';

import { CALCULATORS_BY_SLUG } from './data/calculators';
import { CalculatorCategory } from './types';

const CATEGORY_SLUGS: Record<string, CalculatorCategory> = {
  '/youtube': 'youtube',
  '/tiktok': 'tiktok',
  '/instagram': 'instagram',
  '/affiliate': 'affiliate',
  '/business': 'business',
  '/social-media': 'social-media',
};

const AppRoutes: React.FC = () => {
  const { currentPath } = useRouter();

  // 1. Root and Main Informational Pages
  if (currentPath === '/') {
    return <HomePage />;
  }
  if (currentPath === '/calculators') {
    return <CalculatorsPage />;
  }
  if (currentPath === '/about') {
    return <AboutPage />;
  }
  if (currentPath === '/privacy') {
    return <PrivacyPage />;
  }
  if (currentPath === '/terms') {
    return <TermsPage />;
  }
  if (currentPath === '/sitemap') {
    return <SitemapPage />;
  }

  // 2. Category Hubs
  if (currentPath in CATEGORY_SLUGS) {
    return <CategoryPage categoryId={CATEGORY_SLUGS[currentPath]} />;
  }

  // 3. Individual Calculator Pages
  const matchedCalculator = CALCULATORS_BY_SLUG.get(currentPath);
  if (matchedCalculator) {
    return <CalculatorDetailPage calculatorId={matchedCalculator.id} />;
  }

  // 4. Fallback 404
  return <NotFoundPage />;
};

export default function App() {
  return (
    <ThemeProvider>
      <CurrencyProvider>
        <RouterProvider>
          <div className="min-h-screen flex flex-col bg-[#0B0D10] text-[#F5F7FA] font-sans antialiased selection:bg-[#7C5CFC] selection:text-white transition-colors duration-200">
            <GoogleAnalytics />
            <Header />
            <main className="flex-1">
              <AppRoutes />
            </main>
            <Footer />
          </div>
        </RouterProvider>
      </CurrencyProvider>
    </ThemeProvider>
  );
}
