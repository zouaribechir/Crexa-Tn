import React from 'react';
import {
  Youtube,
  Smartphone,
  Instagram,
  ShoppingBag,
  Percent,
  TrendingUp,
  PlayCircle,
  Award,
  DollarSign,
  BarChart3,
  Activity,
  Layout,
  Briefcase,
  HelpCircle,
  Calculator,
  Search,
  Moon,
  Sun,
  ArrowRight,
  RotateCcw,
  ExternalLink,
  ChevronRight,
  Info,
  Check,
} from 'lucide-react';

interface DynamicIconProps {
  name: string;
  className?: string;
  size?: number;
}

export const DynamicIcon: React.FC<DynamicIconProps> = ({ name, className = 'w-5 h-5', size }) => {
  const props = { className, size };

  switch (name) {
    case 'Youtube':
      return <Youtube {...props} />;
    case 'Smartphone':
      return <Smartphone {...props} />;
    case 'Instagram':
      return <Instagram {...props} />;
    case 'ShoppingBag':
      return <ShoppingBag {...props} />;
    case 'Percent':
      return <Percent {...props} />;
    case 'TrendingUp':
      return <TrendingUp {...props} />;
    case 'PlayCircle':
      return <PlayCircle {...props} />;
    case 'Award':
      return <Award {...props} />;
    case 'DollarSign':
      return <DollarSign {...props} />;
    case 'BarChart3':
      return <BarChart3 {...props} />;
    case 'Activity':
      return <Activity {...props} />;
    case 'Layout':
      return <Layout {...props} />;
    case 'Briefcase':
      return <Briefcase {...props} />;
    case 'Search':
      return <Search {...props} />;
    case 'Moon':
      return <Moon {...props} />;
    case 'Sun':
      return <Sun {...props} />;
    case 'ArrowRight':
      return <ArrowRight {...props} />;
    case 'RotateCcw':
      return <RotateCcw {...props} />;
    case 'ExternalLink':
      return <ExternalLink {...props} />;
    case 'ChevronRight':
      return <ChevronRight {...props} />;
    case 'Info':
      return <Info {...props} />;
    case 'Check':
      return <Check {...props} />;
    default:
      return <Calculator {...props} />;
  }
};
