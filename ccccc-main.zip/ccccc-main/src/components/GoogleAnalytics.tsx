import { useEffect, useRef } from 'react';
import { useRouter } from '../context/RouterContext';

export const GA_MEASUREMENT_ID = 'G-X9QZ8256LD';

declare global {
  interface Window {
    dataLayer?: unknown[];
    gtag?: (...args: unknown[]) => void;
  }
}

// Track non-sensitive user actions (e.g. calculator calculation triggered)
export function trackCalculatorAction(calculatorId: string): void {
  if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
    try {
      window.gtag('event', 'calculator_interact', {
        calculator_id: calculatorId,
      });
    } catch {
      // Silently ignore if blocked
    }
  }
}

export const GoogleAnalytics = () => {
  const { currentPath } = useRouter();
  const lastTrackedPath = useRef<string | null>(null);

  // Initialize GA4 script once
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Check if script already injected
    const existingScript = document.getElementById('ga-gtag-script');
    if (!existingScript) {
      window.dataLayer = window.dataLayer || [];
      // Define gtag helper
      window.gtag = function gtag() {
        // eslint-disable-next-line prefer-rest-params
        window.dataLayer?.push(arguments);
      };

      window.gtag('js', new Date());

      // Crucial: send_page_view is set to false so automatic pageview is suppressed.
      // This prevents double-counting on the initial page load in our React SPA.
      window.gtag('config', GA_MEASUREMENT_ID, {
        send_page_view: false,
      });

      const script = document.createElement('script');
      script.id = 'ga-gtag-script';
      script.async = true;
      script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
      document.head.appendChild(script);
    }
  }, []);

  // SPA client-side page_view dispatcher
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Avoid duplicate page_view on identical route re-renders
    if (lastTrackedPath.current === currentPath) return;
    lastTrackedPath.current = currentPath;

    // Small delay so that the SeoHead component has updated document.title
    const timer = setTimeout(() => {
      if (typeof window.gtag === 'function') {
        try {
          window.gtag('event', 'page_view', {
            page_title: document.title,
            page_location: window.location.href,
            page_path: currentPath,
          });
        } catch {
          // Gracefully suppress analytics errors when adblocker is active
        }
      }
    }, 50);

    return () => clearTimeout(timer);
  }, [currentPath]);

  return null;
};
