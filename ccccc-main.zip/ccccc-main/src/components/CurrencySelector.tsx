import React, { useState, useRef, useEffect } from 'react';
import { useCurrency, SUPPORTED_CURRENCIES } from '../context/CurrencyContext';
import { DollarSign, ChevronDown } from 'lucide-react';

export const CurrencySelector: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { currency, setCurrencyCode } = useCurrency();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-label={`Select currency, current is ${currency.code}`}
        className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border border-[#252B33] dark:border-[#252B33] light:border-slate-200 bg-[#12161B] dark:bg-[#12161B] light:bg-white text-[#F5F7FA] dark:text-[#F5F7FA] light:text-slate-800 hover:border-[#7C5CFC] transition-colors focus:outline-none focus:ring-2 focus:ring-[#7C5CFC]"
      >
        <span className="text-[#7C5CFC] font-semibold">{currency.symbol}</span>
        <span>{currency.code}</span>
        <ChevronDown className="w-3.5 h-3.5 text-[#A7B0BC] dark:text-[#A7B0BC] light:text-slate-400" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-1.5 w-40 rounded-lg border border-[#252B33] dark:border-[#252B33] light:border-slate-200 bg-[#181D23] dark:bg-[#181D23] light:bg-white shadow-xl z-50 py-1">
          {SUPPORTED_CURRENCIES.map((c) => (
            <button
              key={c.code}
              type="button"
              onClick={() => {
                setCurrencyCode(c.code);
                setIsOpen(false);
              }}
              className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-[#252B33] dark:hover:bg-[#252B33] light:hover:bg-slate-100 transition-colors ${
                c.code === currency.code
                  ? 'text-[#7C5CFC] font-semibold'
                  : 'text-[#F5F7FA] dark:text-[#F5F7FA] light:text-slate-700'
              }`}
            >
              <span className="flex items-center gap-2">
                <span className="w-6 text-right font-mono text-[#A7B0BC]">{c.symbol}</span>
                <span>{c.name}</span>
              </span>
              <span className="text-[10px] uppercase text-[#A7B0BC]">{c.code}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
