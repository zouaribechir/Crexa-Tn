import React from 'react';

interface NumberInputProps {
  id: string;
  label: string;
  value: number;
  onChange: (val: number) => void;
  min?: number;
  max?: number;
  step?: number;
  prefix?: string;
  suffix?: string;
  helperText?: string;
  placeholder?: string;
  disabled?: boolean;
}

export const NumberInput: React.FC<NumberInputProps> = ({
  id,
  label,
  value,
  onChange,
  min = 0,
  max,
  step = 1,
  prefix,
  suffix,
  helperText,
  placeholder = '0',
  disabled = false,
}) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    if (raw === '') {
      onChange(0);
      return;
    }
    const parsed = parseFloat(raw);
    if (!Number.isFinite(parsed)) {
      onChange(0);
      return;
    }
    let val = parsed;
    if (min !== undefined && val < min) val = min;
    if (max !== undefined && val > max) val = max;
    onChange(val);
  };

  return (
    <div className="flex flex-col space-y-1.5">
      <div className="flex items-center justify-between">
        <label htmlFor={id} className="text-xs font-semibold text-[#F5F7FA]">
          {label}
        </label>
        {helperText && (
          <span className="text-[11px] text-[#A7B0BC]">{helperText}</span>
        )}
      </div>

      <div className="relative flex items-center rounded-lg border border-[#252B33] bg-[#12161B] focus-within:border-[#7C5CFC] focus-within:ring-1 focus-within:ring-[#7C5CFC] transition-colors">
        {prefix && (
          <span className="pl-3 pr-1 text-xs font-mono font-medium text-[#A7B0BC] select-none">
            {prefix}
          </span>
        )}
        <input
          id={id}
          type="number"
          min={min}
          max={max}
          step={step}
          value={value === 0 ? '' : value}
          onChange={handleChange}
          placeholder={placeholder}
          disabled={disabled}
          className="w-full bg-transparent px-3 py-2 text-sm text-[#F5F7FA] placeholder-[#A7B0BC]/50 focus:outline-none disabled:opacity-50"
        />
        {suffix && (
          <span className="pr-3 pl-1 text-xs font-mono font-medium text-[#A7B0BC] select-none">
            {suffix}
          </span>
        )}
      </div>
    </div>
  );
};
