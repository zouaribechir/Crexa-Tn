import React from 'react';
import { CalculatorFaq } from '../types';
import { ChevronDown } from 'lucide-react';

interface FaqSectionProps {
  faqs: CalculatorFaq[];
  title?: string;
  subtitle?: string;
}

export const FaqSection: React.FC<FaqSectionProps> = ({
  faqs,
  title = 'Frequently Asked Questions',
  subtitle = 'Clear answers to common questions about calculations and platform benchmarks.',
}) => {
  if (!faqs || faqs.length === 0) return null;

  return (
    <section className="py-8 border-t border-[#252B33]">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-[#F5F7FA] tracking-tight">{title}</h2>
        {subtitle && <p className="text-xs text-[#A7B0BC] mt-1">{subtitle}</p>}
      </div>

      <div className="space-y-3">
        {faqs.map((faq, idx) => (
          <details
            key={idx}
            className="group rounded-xl border border-[#252B33] bg-[#12161B] p-4 [&_summary::-webkit-details-marker]:hidden transition-colors"
          >
            <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-[#F5F7FA] list-none select-none focus:outline-none focus:text-[#7C5CFC]">
              <span>{faq.question}</span>
              <ChevronDown className="w-4 h-4 text-[#A7B0BC] transition-transform duration-200 group-open:rotate-180 flex-shrink-0 ml-2" />
            </summary>
            <div className="mt-3 text-xs leading-relaxed text-[#A7B0BC] pt-3 border-t border-[#252B33]">
              {faq.answer}
            </div>
          </details>
        ))}
      </div>
    </section>
  );
};
