import React from 'react';
import { CalculatorDefinition } from '../types';
import { Link } from './Link';
import { DynamicIcon } from './DynamicIcon';
import { ArrowRight } from 'lucide-react';

interface CalculatorCardProps {
  calculator: CalculatorDefinition;
  compact?: boolean;
}

export const CalculatorCard: React.FC<CalculatorCardProps> = ({ calculator, compact = false }) => {
  return (
    <Link
      href={calculator.slug}
      className="group relative flex flex-col justify-between rounded-xl border border-[#252B33] bg-[#12161B] p-5 hover:border-[#7C5CFC] hover:bg-[#181D23]/60 transition-all focus:outline-none focus:ring-2 focus:ring-[#7C5CFC]"
    >
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="p-2.5 rounded-lg bg-[#181D23] group-hover:bg-[#7C5CFC]/10 text-[#7C5CFC] border border-[#252B33] transition-colors">
            <DynamicIcon name={calculator.iconName} className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-[#A7B0BC] group-hover:text-[#F5F7FA] transition-colors">
            {calculator.categoryName}
          </span>
        </div>

        <h3 className="text-base font-bold text-[#F5F7FA] group-hover:text-[#7C5CFC] transition-colors line-clamp-1 mb-1.5">
          {calculator.name}
        </h3>

        {!compact && (
          <p className="text-xs text-[#A7B0BC] line-clamp-2 leading-relaxed">
            {calculator.shortDescription}
          </p>
        )}
      </div>

      <div className="mt-4 pt-3 border-t border-[#252B33] flex items-center justify-between text-xs font-semibold text-[#7C5CFC]">
        <span>Open Calculator</span>
        <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
      </div>
    </Link>
  );
};
