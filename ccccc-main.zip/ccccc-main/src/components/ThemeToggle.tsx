import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { Sun, Moon } from 'lucide-react';

export const ThemeToggle: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
      className={`p-2 rounded-lg border border-[#252B33] dark:border-[#252B33] light:border-slate-200 bg-[#12161B] dark:bg-[#12161B] light:bg-white text-[#F5F7FA] dark:text-[#F5F7FA] light:text-slate-800 hover:border-[#7C5CFC] transition-colors focus:outline-none focus:ring-2 focus:ring-[#7C5CFC] ${className}`}
    >
      {theme === 'dark' ? (
        <Sun className="w-4 h-4 text-amber-400" aria-hidden="true" />
      ) : (
        <Moon className="w-4 h-4 text-slate-700" aria-hidden="true" />
      )}
    </button>
  );
};
