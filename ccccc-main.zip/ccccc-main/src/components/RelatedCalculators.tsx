import React from 'react';
import { CALCULATORS_BY_ID } from '../data/calculators';
import { CalculatorCard } from './CalculatorCard';

interface RelatedCalculatorsProps {
  relatedIds: string[];
}

export const RelatedCalculators: React.FC<RelatedCalculatorsProps> = ({ relatedIds }) => {
  const related = relatedIds
    .map((id) => CALCULATORS_BY_ID.get(id))
    .filter((c): c is NonNullable<typeof c> => c !== undefined);

  if (related.length === 0) return null;

  return (
    <section className="py-8 border-t border-[#252B33]">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-[#F5F7FA] tracking-tight">
          Related Calculators
        </h2>
        <p className="text-xs text-[#A7B0BC] mt-1">
          Explore more tools to analyze your revenue, engagement, and online business performance.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {related.map((calc) => (
          <CalculatorCard key={calc.id} calculator={calc} compact />
        ))}
      </div>
    </section>
  );
};
