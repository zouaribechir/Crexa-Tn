import React from 'react';
import { Link } from './Link';
import { CATEGORIES } from '../data/categories';
import { CALCULATORS } from '../data/calculators';
import { Calculator } from 'lucide-react';

export const Footer: React.FC = () => {
  const priorityCalculators = CALCULATORS.filter((c) => c.priority).slice(0, 6);

  return (
    <footer className="w-full border-t border-[#252B33] bg-[#0B0D10] text-[#A7B0BC] transition-colors mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <Link href="/" className="flex items-center gap-2.5 inline-flex focus:outline-none focus:ring-2 focus:ring-[#7C5CFC] rounded-lg">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#7C5CFC] to-[#6847F5] flex items-center justify-center text-white">
                <Calculator className="w-4 h-4" />
              </div>
              <span className="text-xl font-bold tracking-tight text-[#F5F7FA]">CREXA</span>
            </Link>
            <p className="text-sm leading-relaxed max-w-sm">
              Calculate smarter. Grow faster. CREXA is a global digital calculator platform for content creators, influencers, affiliates, and online businesses.
            </p>
            <div className="text-xs text-[#A7B0BC] pt-2">
              <span className="inline-block px-2 py-0.5 rounded border border-[#252B33] bg-[#12161B] text-[11px] font-mono">
                100% Client-Side &middot; Private &middot; Free
              </span>
            </div>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#F5F7FA] mb-4">
              Category Hubs
            </h3>
            <ul className="space-y-2.5 text-xs">
              {CATEGORIES.map((cat) => (
                <li key={cat.id}>
                  <Link
                    href={cat.slug}
                    className="hover:text-[#F5F7FA] hover:underline transition-colors"
                  >
                    {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Top Calculators */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#F5F7FA] mb-4">
              Priority Calculators
            </h3>
            <ul className="space-y-2.5 text-xs">
              {priorityCalculators.map((calc) => (
                <li key={calc.id}>
                  <Link
                    href={calc.slug}
                    className="hover:text-[#F5F7FA] hover:underline transition-colors"
                  >
                    {calc.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal & Informational */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#F5F7FA] mb-4">
              Platform & Legal
            </h3>
            <ul className="space-y-2.5 text-xs">
              <li>
                <Link href="/calculators" className="hover:text-[#F5F7FA] hover:underline transition-colors">
                  All 12 Calculators
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-[#F5F7FA] hover:underline transition-colors">
                  About CREXA
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-[#F5F7FA] hover:underline transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-[#F5F7FA] hover:underline transition-colors">
                  Terms of Use
                </Link>
              </li>
              <li>
                <Link href="/sitemap" className="hover:text-[#F5F7FA] hover:underline transition-colors">
                  HTML Sitemap
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Disclaimer & Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-[#252B33] text-xs space-y-4">
          <p className="text-[11px] leading-relaxed text-[#A7B0BC]/80">
            <strong>Disclaimer:</strong> CREXA provides numerical estimation calculators based on standard mathematical formulas and user-entered assumptions. All results are illustrative estimates and do not guarantee actual platform payouts, advertising bids, or sponsorship contracts. CREXA is an independent platform and is not affiliated, endorsed, or partnered with YouTube, Google, TikTok, ByteDance, Instagram, or Meta.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#A7B0BC]">
            <span>&copy; {new Date().getFullYear()} CREXA (<a href="https://crexa.tn" className="hover:underline">crexa.tn</a>). All rights reserved.</span>
            <div className="flex items-center space-x-4">
              <Link href="/privacy" className="hover:text-[#F5F7FA]">Privacy</Link>
              <span aria-hidden="true">&middot;</span>
              <Link href="/terms" className="hover:text-[#F5F7FA]">Terms</Link>
              <span aria-hidden="true">&middot;</span>
              <a href="https://crexa.tn/sitemap.xml" className="hover:text-[#F5F7FA]" target="_blank" rel="noopener noreferrer">
                XML Sitemap
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
