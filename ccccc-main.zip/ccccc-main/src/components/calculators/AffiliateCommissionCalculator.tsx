import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateAffiliateCommission, formatNumber, formatPercent } from '../../lib/calculatorMath';
import { useCurrency } from '../../context/CurrencyContext';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const AffiliateCommissionCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('affiliate-commission-calculator')!;
  const { formatMoney, currency } = useCurrency();

  const [salesCount, setSalesCount] = useState<number>(50);
  const [averageOrderValue, setAverageOrderValue] = useState<number>(75);
  const [commissionRatePercent, setCommissionRatePercent] = useState<number>(15);

  const result = useMemo(() => {
    trackCalculatorAction('affiliate-commission-calculator');
    return calculateAffiliateCommission({
      salesCount,
      averageOrderValue,
      commissionRatePercent,
    });
  }, [salesCount, averageOrderValue, commissionRatePercent]);

  const handleReset = () => {
    setSalesCount(50);
    setAverageOrderValue(75);
    setCommissionRatePercent(15);
  };

  const inputsComponent = (
    <div className="space-y-4">
      <NumberInput
        id="aff-sales"
        label="Number of Completed Product Sales"
        value={salesCount}
        onChange={setSalesCount}
        min={0}
        step={5}
        helperText="Referred conversions generated"
      />

      <NumberInput
        id="aff-aov"
        label="Average Order Value (AOV)"
        value={averageOrderValue}
        onChange={setAverageOrderValue}
        min={0}
        step={5}
        prefix={currency.symbol}
        helperText="Average cart total per purchase"
      />

      <NumberInput
        id="aff-rate"
        label="Commission Rate Percentage"
        value={commissionRatePercent}
        onChange={setCommissionRatePercent}
        min={0}
        max={100}
        step={1}
        suffix="%"
        helperText="Merchant affiliate commission terms"
      />

      {/* Quick Rate Presets */}
      <div className="pt-2">
        <span className="text-[11px] text-[#A7B0BC] block mb-1.5">Typical Commission Rates:</span>
        <div className="flex flex-wrap gap-1.5">
          {[
            { label: 'Amazon Retail (3%)', val: 3 },
            { label: 'Fashion / Beauty (10%)', val: 10 },
            { label: 'SaaS Software (25%)', val: 25 },
            { label: 'Digital Courses (40%)', val: 40 },
          ].map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => setCommissionRatePercent(item.val)}
              className="text-[11px] px-2.5 py-1 rounded-md border border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA] hover:border-[#7C5CFC] transition-colors"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <span className="text-xs uppercase tracking-wider text-[#A7B0BC] block mb-1">
          Total Commission Earned
        </span>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {formatMoney(result.commissionEarned)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          From {formatMoney(result.grossSales)} in Gross Merchandise Volume (GMV)
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Commission Per Sale</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatMoney(result.averageCommissionPerSale)}
          </span>
        </div>

        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Total Sales Count</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatNumber(salesCount)} orders
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] flex items-center justify-between">
        <span className="text-xs text-[#A7B0BC]">Effective Payout Share:</span>
        <span className="text-sm font-bold text-[#3CCB8E]">
          {formatPercent(commissionRatePercent)} of gross sales
        </span>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
