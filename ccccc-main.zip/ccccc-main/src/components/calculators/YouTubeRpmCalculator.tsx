import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateYouTubeRpm, formatNumber } from '../../lib/calculatorMath';
import { useCurrency } from '../../context/CurrencyContext';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const YouTubeRpmCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('youtube-rpm-calculator')!;
  const { formatMoney, currency } = useCurrency();

  const [revenue, setRevenue] = useState<number>(350);
  const [views, setViews] = useState<number>(70000);

  const result = useMemo(() => {
    trackCalculatorAction('youtube-rpm-calculator');
    return calculateYouTubeRpm({ revenue, views });
  }, [revenue, views]);

  const handleReset = () => {
    setRevenue(350);
    setViews(70000);
  };

  const inputsComponent = (
    <div className="space-y-4">
      <NumberInput
        id="yt-rev"
        label="Total Video or Channel Revenue"
        value={revenue}
        onChange={setRevenue}
        min={0}
        step={10}
        prefix={currency.symbol}
        helperText="As reported in YouTube Studio"
      />

      <NumberInput
        id="yt-views-count"
        label="Total Views Received"
        value={views}
        onChange={setViews}
        min={0}
        step={5000}
        helperText="All monetized & non-monetized views in the period"
      />
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <span className="text-xs uppercase tracking-wider text-[#A7B0BC] block mb-1">
          Calculated Revenue Per 1,000 Views (RPM)
        </span>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {currency.symbol}{result.rpm.toFixed(2)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          Effective revenue across {formatNumber(views)} total views
        </p>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] flex items-center justify-between">
        <span className="text-xs text-[#A7B0BC]">Earnings Per Single View:</span>
        <span className="text-sm font-mono font-bold text-[#F5F7FA]">
          {currency.symbol}{result.earningsPerView.toFixed(5)}
        </span>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] flex items-center justify-between">
        <span className="text-xs text-[#A7B0BC]">Estimated Earnings on 100k Views:</span>
        <span className="text-sm font-bold text-[#3CCB8E]">
          {formatMoney(result.rpm * 100)}
        </span>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
