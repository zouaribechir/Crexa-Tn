import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateYouTubeMoney, formatNumber } from '../../lib/calculatorMath';
import { useCurrency } from '../../context/CurrencyContext';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const YouTubeMoneyCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('youtube-money-calculator')!;
  const { formatMoney, currency } = useCurrency();

  const [views, setViews] = useState<number>(100000);
  const [rpm, setRpm] = useState<number>(4.0);
  const [timeframe, setTimeframe] = useState<'monthly' | 'daily' | 'total'>('monthly');

  const result = useMemo(() => {
    trackCalculatorAction('youtube-money-calculator');
    return calculateYouTubeMoney({ views, rpm, timeframe });
  }, [views, rpm, timeframe]);

  const handleReset = () => {
    setViews(100000);
    setRpm(4.0);
    setTimeframe('monthly');
  };

  const inputsComponent = (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
          View Count Timeframe
        </label>
        <div className="grid grid-cols-3 gap-2">
          {(['daily', 'monthly', 'total'] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => setTimeframe(mode)}
              className={`py-1.5 text-xs font-medium rounded-lg border capitalize transition-colors ${
                timeframe === mode
                  ? 'border-[#7C5CFC] bg-[#7C5CFC] text-white'
                  : 'border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA]'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      <NumberInput
        id="yt-views"
        label={`${timeframe === 'total' ? 'Total' : timeframe === 'daily' ? 'Daily' : 'Monthly'} Video Views`}
        value={views}
        onChange={setViews}
        min={0}
        step={5000}
        helperText="Typical active channel range: 10,000 - 1,000,000+"
      />

      <NumberInput
        id="yt-rpm"
        label="Estimated RPM (Revenue Per 1,000 Views)"
        value={rpm}
        onChange={setRpm}
        min={0}
        step={0.25}
        prefix={currency.symbol}
        helperText="Average YouTube RPM ranges from $1.50 to $10.00"
      />

      {/* Preset RPM helper chips */}
      <div className="pt-2">
        <span className="text-[11px] text-[#A7B0BC] block mb-1.5">Quick Niche RPM Benchmarks:</span>
        <div className="flex flex-wrap gap-1.5">
          {[
            { label: 'Gaming ($2.00)', val: 2.0 },
            { label: 'Lifestyle ($3.50)', val: 3.5 },
            { label: 'Tech & Reviews ($7.00)', val: 7.0 },
            { label: 'Finance & B2B ($14.00)', val: 14.0 },
          ].map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => setRpm(item.val)}
              className="text-[11px] px-2.5 py-1 rounded-md border border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA] hover:border-[#7C5CFC] transition-colors"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <span className="text-xs uppercase tracking-wider text-[#A7B0BC] block mb-1">
          {timeframe === 'daily' ? 'Daily Estimated Earnings' : timeframe === 'monthly' ? 'Monthly Estimated Earnings' : 'Estimated Period Earnings'}
        </span>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {formatMoney(result.estimatedEarnings)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          Based on {formatNumber(views)} views at {currency.symbol}{rpm.toFixed(2)} RPM
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Daily Projection</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatMoney(result.dailyEarnings)}
          </span>
        </div>

        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Monthly Projection</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatMoney(result.monthlyEarnings)}
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] flex items-center justify-between">
        <span className="text-xs text-[#A7B0BC]">Annual Run Rate (12 Months):</span>
        <span className="text-base font-bold text-[#3CCB8E]">
          {formatMoney(result.yearlyEarnings)}
        </span>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
