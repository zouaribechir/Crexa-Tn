import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateInstagramEngagement, formatNumber, formatPercent } from '../../lib/calculatorMath';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const InstagramEngagementCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('instagram-engagement-calculator')!;

  const [likes, setLikes] = useState<number>(1400);
  const [comments, setComments] = useState<number>(85);
  const [followers, setFollowers] = useState<number>(40000);

  const result = useMemo(() => {
    trackCalculatorAction('instagram-engagement-calculator');
    return calculateInstagramEngagement({ likes, comments, followers });
  }, [likes, comments, followers]);

  const handleReset = () => {
    setLikes(1400);
    setComments(85);
    setFollowers(40000);
  };

  const statusBadge = {
    low: { label: 'Below Average (<1.5%)', color: 'text-amber-400 bg-amber-400/10 border-amber-400/30' },
    good: { label: 'Good / Healthy (1.5% - 4%)', color: 'text-[#3CCB8E] bg-[#3CCB8E]/10 border-[#3CCB8E]/30' },
    high: { label: 'High / Top Tier (>4%)', color: 'text-[#7C5CFC] bg-[#7C5CFC]/10 border-[#7C5CFC]/30' },
  }[result.benchmarkStatus];

  const inputsComponent = (
    <div className="space-y-4">
      <NumberInput
        id="ig-followers"
        label="Total Instagram Followers"
        value={followers}
        onChange={setFollowers}
        min={0}
        step={5000}
        helperText="Account total following"
      />

      <NumberInput
        id="ig-likes"
        label="Average Likes Per Post"
        value={likes}
        onChange={setLikes}
        min={0}
        step={100}
        helperText="Average over recent 6 to 12 posts"
      />

      <NumberInput
        id="ig-comments"
        label="Average Comments Per Post"
        value={comments}
        onChange={setComments}
        min={0}
        step={10}
        helperText="Excluding spam / bot comments"
      />
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs uppercase tracking-wider text-[#A7B0BC]">
            Instagram Engagement Rate
          </span>
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${statusBadge.color}`}>
            {statusBadge.label}
          </span>
        </div>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {formatPercent(result.engagementRatePercent)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          {formatNumber(result.totalInteractions)} total interactions per post across {formatNumber(followers)} followers
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Likes to Follower Ratio</span>
          <span className="text-sm font-bold text-[#F5F7FA]">
            {formatPercent(followers > 0 ? (likes / followers) * 100 : 0)}
          </span>
        </div>

        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Comments to Follower Ratio</span>
          <span className="text-sm font-bold text-[#F5F7FA]">
            {formatPercent(followers > 0 ? (comments / followers) * 100 : 0)}
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] text-xs text-[#A7B0BC] space-y-1.5">
        <span className="font-semibold text-[#F5F7FA] block">Agency Benchmark Guidelines:</span>
        <div className="flex justify-between border-b border-[#252B33] pb-1 text-[11px]">
          <span>Nano (1k - 10k followers):</span>
          <span className="text-[#F5F7FA] font-medium">4.0% - 7.0%</span>
        </div>
        <div className="flex justify-between border-b border-[#252B33] pb-1 text-[11px]">
          <span>Micro (10k - 50k followers):</span>
          <span className="text-[#F5F7FA] font-medium">2.5% - 4.0%</span>
        </div>
        <div className="flex justify-between text-[11px]">
          <span>Macro (100k+ followers):</span>
          <span className="text-[#F5F7FA] font-medium">1.2% - 2.5%</span>
        </div>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
