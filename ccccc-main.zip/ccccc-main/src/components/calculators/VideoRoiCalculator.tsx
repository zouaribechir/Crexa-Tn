import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateVideoRoi, formatPercent } from '../../lib/calculatorMath';
import { useCurrency } from '../../context/CurrencyContext';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const VideoRoiCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('video-roi-calculator')!;
  const { formatMoney, currency } = useCurrency();

  const [productionCost, setProductionCost] = useState<number>(600);
  const [promotionSpend, setPromotionSpend] = useState<number>(200);
  const [attributableRevenue, setAttributableRevenue] = useState<number>(2000);

  const result = useMemo(() => {
    trackCalculatorAction('video-roi-calculator');
    return calculateVideoRoi({
      productionCost,
      promotionSpend,
      attributableRevenue,
    });
  }, [productionCost, promotionSpend, attributableRevenue]);

  const handleReset = () => {
    setProductionCost(600);
    setPromotionSpend(200);
    setAttributableRevenue(2000);
  };

  const inputsComponent = (
    <div className="space-y-4">
      <NumberInput
        id="roi-prod"
        label="Video Production Expenses"
        value={productionCost}
        onChange={setProductionCost}
        min={0}
        step={50}
        prefix={currency.symbol}
        helperText="Editing, thumbnail design, gear, studio rental"
      />

      <NumberInput
        id="roi-promo"
        label="Promotion / Paid Advertising Spend"
        value={promotionSpend}
        onChange={setPromotionSpend}
        min={0}
        step={25}
        prefix={currency.symbol}
        helperText="YouTube Discovery ads, Meta ads, influencer shoutouts"
      />

      <NumberInput
        id="roi-rev"
        label="Total Attributable Revenue"
        value={attributableRevenue}
        onChange={setAttributableRevenue}
        min={0}
        step={100}
        prefix={currency.symbol}
        helperText="AdSense + sponsorships + affiliate sales + products"
      />

      <div className="p-3 rounded-lg bg-[#181D23] border border-[#252B33] text-xs text-[#A7B0BC]">
        <span className="font-semibold text-[#F5F7FA] block mb-1">Zero Investment Safe:</span>
        <p>
          If you shoot and edit with $0 external spend, CREXA avoids division-by-zero crashes and safely models pure net return.
        </p>
      </div>
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs uppercase tracking-wider text-[#A7B0BC]">
            Return On Investment (ROI)
          </span>
          <span
            className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
              result.isPositive
                ? 'text-[#3CCB8E] bg-[#3CCB8E]/10 border-[#3CCB8E]/30'
                : 'text-rose-400 bg-rose-400/10 border-rose-400/30'
            }`}
          >
            {result.isPositive ? 'Positive Return' : 'Unprofitable'}
          </span>
        </div>
        <div
          className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            result.isPositive ? 'text-[#3CCB8E]' : 'text-rose-400'
          }`}
        >
          {formatPercent(result.roiPercent)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          {result.isPositive
            ? `You generated ${formatMoney(result.netReturn)} profit over your investment`
            : `Investment exceeded revenue by ${formatMoney(Math.abs(result.netReturn))}`}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Total Investment</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatMoney(result.totalInvestment)}
          </span>
        </div>

        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Net Profit / Return</span>
          <span
            className={`text-lg font-bold ${
              result.isPositive ? 'text-[#3CCB8E]' : 'text-rose-400'
            }`}
          >
            {formatMoney(result.netReturn)}
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] text-xs text-[#A7B0BC] space-y-1">
        <div className="flex justify-between text-[11px]">
          <span>Revenue-to-Cost Multiple:</span>
          <span className="text-[#F5F7FA] font-medium font-mono">
            {result.totalInvestment > 0 ? (attributableRevenue / result.totalInvestment).toFixed(2) : 'N/A'}x
          </span>
        </div>
        <div className="flex justify-between text-[11px]">
          <span>Break-Even Revenue Needed:</span>
          <span className="text-[#A7B0BC] font-medium font-mono">
            {formatMoney(result.totalInvestment)}
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
