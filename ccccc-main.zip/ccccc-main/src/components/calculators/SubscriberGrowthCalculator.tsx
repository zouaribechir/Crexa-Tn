import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateSubscriberGrowth, formatNumber, formatPercent } from '../../lib/calculatorMath';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const SubscriberGrowthCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('subscriber-growth-calculator')!;

  const [currentSubscribers, setCurrentSubscribers] = useState<number>(10000);
  const [newSubscribersPerMonth, setNewSubscribersPerMonth] = useState<number>(1200);
  const [lostSubscribersPerMonth, setLostSubscribersPerMonth] = useState<number>(200);
  const [forecastMonths, setForecastMonths] = useState<number>(12);

  const result = useMemo(() => {
    trackCalculatorAction('subscriber-growth-calculator');
    return calculateSubscriberGrowth({
      currentSubscribers,
      newSubscribersPerMonth,
      lostSubscribersPerMonth,
      forecastMonths,
    });
  }, [currentSubscribers, newSubscribersPerMonth, lostSubscribersPerMonth, forecastMonths]);

  const handleReset = () => {
    setCurrentSubscribers(10000);
    setNewSubscribersPerMonth(1200);
    setLostSubscribersPerMonth(200);
    setForecastMonths(12);
  };

  const inputsComponent = (
    <div className="space-y-4">
      <NumberInput
        id="sub-current"
        label="Current Subscriber / Follower Count"
        value={currentSubscribers}
        onChange={setCurrentSubscribers}
        min={0}
        step={1000}
        helperText="Current active audience baseline"
      />

      <div className="grid grid-cols-2 gap-3">
        <NumberInput
          id="sub-new"
          label="New Subscribers / Month"
          value={newSubscribersPerMonth}
          onChange={setNewSubscribersPerMonth}
          min={0}
          step={50}
          helperText="Gross new monthly additions"
        />

        <NumberInput
          id="sub-lost"
          label="Lost Subscribers (Churn) / Mo"
          value={lostSubscribersPerMonth}
          onChange={setLostSubscribersPerMonth}
          min={0}
          step={10}
          helperText="Monthly unsubscriptions / deletes"
        />
      </div>

      <div>
        <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
          Forecast Timeframe ({forecastMonths} Months)
        </label>
        <div className="flex gap-2">
          {[3, 6, 12, 24, 36].map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setForecastMonths(m)}
              className={`flex-1 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                forecastMonths === m
                  ? 'border-[#7C5CFC] bg-[#7C5CFC] text-white'
                  : 'border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA]'
              }`}
            >
              {m} mo
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <span className="text-xs uppercase tracking-wider text-[#A7B0BC] block mb-1">
          Projected Subscribers in {forecastMonths} Months
        </span>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {formatNumber(result.projectedSubscribers)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          From {formatNumber(currentSubscribers)} initial base ({formatNumber(result.projectedSubscribers - currentSubscribers)} net change)
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Net Monthly Growth</span>
          <span
            className={`text-lg font-bold ${
              result.netMonthlyGrowth >= 0 ? 'text-[#3CCB8E]' : 'text-rose-400'
            }`}
          >
            {result.netMonthlyGrowth >= 0 ? '+' : ''}{formatNumber(result.netMonthlyGrowth)}/mo
          </span>
        </div>

        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Monthly Growth Rate</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatPercent(result.monthlyGrowthRatePercent)}
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] text-xs text-[#A7B0BC] space-y-1">
        <div className="flex justify-between text-[11px]">
          <span>Total Gained Over Period:</span>
          <span className="text-[#3CCB8E] font-medium font-mono">+{formatNumber(result.totalGained)}</span>
        </div>
        <div className="flex justify-between text-[11px]">
          <span>Total Lost (Audience Churn):</span>
          <span className="text-rose-400 font-medium font-mono">-{formatNumber(result.totalLost)}</span>
        </div>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
