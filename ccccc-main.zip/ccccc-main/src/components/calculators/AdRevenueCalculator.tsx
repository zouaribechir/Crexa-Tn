import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateAdRevenue, formatNumber } from '../../lib/calculatorMath';
import { useCurrency } from '../../context/CurrencyContext';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const AdRevenueCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('ad-revenue-calculator')!;
  const { formatMoney, currency } = useCurrency();

  const [volume, setVolume] = useState<number>(250000);
  const [ratePerThousand, setRatePerThousand] = useState<number>(12.0);
  const [metricType, setMetricType] = useState<'pageviews' | 'impressions'>('pageviews');

  const result = useMemo(() => {
    trackCalculatorAction('ad-revenue-calculator');
    return calculateAdRevenue({ volume, ratePerThousand, metricType });
  }, [volume, ratePerThousand, metricType]);

  const handleReset = () => {
    setVolume(250000);
    setRatePerThousand(12.0);
    setMetricType('pageviews');
  };

  const inputsComponent = (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
          Traffic Metric Type
        </label>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setMetricType('pageviews')}
            className={`py-2 text-xs font-medium rounded-lg border transition-colors ${
              metricType === 'pageviews'
                ? 'border-[#7C5CFC] bg-[#7C5CFC] text-white'
                : 'border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA]'
            }`}
          >
            Website Pageviews (Page RPM)
          </button>
          <button
            type="button"
            onClick={() => setMetricType('impressions')}
            className={`py-2 text-xs font-medium rounded-lg border transition-colors ${
              metricType === 'impressions'
                ? 'border-[#7C5CFC] bg-[#7C5CFC] text-white'
                : 'border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA]'
            }`}
          >
            Ad Impressions (Ad CPM)
          </button>
        </div>
        <p className="text-[11px] text-[#A7B0BC] mt-1.5 leading-relaxed">
          {metricType === 'pageviews'
            ? 'Pageviews measure total pages loaded. A single pageview can show multiple ads.'
            : 'Ad Impressions count every individual banner or video unit displayed across your pages.'}
        </p>
      </div>

      <NumberInput
        id="ad-volume"
        label={`Monthly ${metricType === 'pageviews' ? 'Pageviews' : 'Ad Impressions'}`}
        value={volume}
        onChange={setVolume}
        min={0}
        step={10000}
        helperText="Monthly visitor volume"
      />

      <NumberInput
        id="ad-rate"
        label={`Estimated ${metricType === 'pageviews' ? 'Page RPM' : 'Ad CPM'} (Per 1,000 units)`}
        value={ratePerThousand}
        onChange={setRatePerThousand}
        min={0}
        step={0.5}
        prefix={currency.symbol}
        helperText="AdSense: $2-$7, Mediavine/Raptive: $12-$35+"
      />

      {/* Network Presets */}
      <div className="pt-2">
        <span className="text-[11px] text-[#A7B0BC] block mb-1.5">Network Averages:</span>
        <div className="flex flex-wrap gap-1.5">
          {[
            { label: 'AdSense ($4.00)', val: 4.0 },
            { label: 'Ezoic ($9.00)', val: 9.0 },
            { label: 'Mediavine ($18.00)', val: 18.0 },
            { label: 'Raptive ($28.00)', val: 28.0 },
          ].map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => setRatePerThousand(item.val)}
              className="text-[11px] px-2.5 py-1 rounded-md border border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA] hover:border-[#7C5CFC] transition-colors"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <span className="text-xs uppercase tracking-wider text-[#A7B0BC] block mb-1">
          Monthly Estimated Ad Revenue
        </span>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {formatMoney(result.monthlyRevenue)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          Based on {formatNumber(volume)} {metricType} at {currency.symbol}{ratePerThousand.toFixed(2)} rate
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Daily Pace</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatMoney(result.dailyRevenue)}
          </span>
        </div>

        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Yearly Projected Run-Rate</span>
          <span className="text-lg font-bold text-[#3CCB8E]">
            {formatMoney(result.yearlyRevenue)}
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] flex items-center justify-between">
        <span className="text-xs text-[#A7B0BC]">Revenue Per 1,000 Visitors:</span>
        <span className="text-sm font-bold text-[#F5F7FA]">
          {currency.symbol}{ratePerThousand.toFixed(2)}
        </span>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
