import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateProfitMargin, formatPercent } from '../../lib/calculatorMath';
import { useCurrency } from '../../context/CurrencyContext';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const ProfitMarginCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('profit-margin-calculator')!;
  const { formatMoney, currency } = useCurrency();

  const [revenue, setRevenue] = useState<number>(200);
  const [cost, setCost] = useState<number>(60);

  const result = useMemo(() => {
    trackCalculatorAction('profit-margin-calculator');
    return calculateProfitMargin({ revenue, cost });
  }, [revenue, cost]);

  const handleReset = () => {
    setRevenue(200);
    setCost(60);
  };

  const inputsComponent = (
    <div className="space-y-4">
      <NumberInput
        id="profit-rev"
        label="Gross Revenue or Selling Price"
        value={revenue}
        onChange={setRevenue}
        min={0}
        step={10}
        prefix={currency.symbol}
        helperText="Total income received from customer or product"
      />

      <NumberInput
        id="profit-cost"
        label="Total Cost of Goods / Expenses"
        value={cost}
        onChange={setCost}
        min={0}
        step={10}
        prefix={currency.symbol}
        helperText="Direct production, contractor, or software expenses"
      />

      <div className="p-3 rounded-lg bg-[#181D23] border border-[#252B33] text-xs text-[#A7B0BC]">
        <span className="font-semibold text-[#F5F7FA] block mb-1">Safety Verification:</span>
        <p>
          CREXA automatically guards against division-by-zero errors. If revenue is zero, profit margin is evaluated safely as 0.00% without crashes.
        </p>
      </div>
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs uppercase tracking-wider text-[#A7B0BC]">
            Profit Margin Percentage
          </span>
          <span
            className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
              result.isProfitable
                ? 'text-[#3CCB8E] bg-[#3CCB8E]/10 border-[#3CCB8E]/30'
                : 'text-rose-400 bg-rose-400/10 border-rose-400/30'
            }`}
          >
            {result.isProfitable ? 'Profitable' : 'Net Loss'}
          </span>
        </div>
        <div
          className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            result.isProfitable ? 'text-[#3CCB8E]' : 'text-rose-400'
          }`}
        >
          {formatPercent(result.profitMarginPercent)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          Portion of each {currency.symbol}1.00 revenue retained as gross profit
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Gross Profit</span>
          <span
            className={`text-lg font-bold ${
              result.isProfitable ? 'text-[#3CCB8E]' : 'text-rose-400'
            }`}
          >
            {formatMoney(result.grossProfit)}
          </span>
        </div>

        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Markup Percentage</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatPercent(result.markupPercent)}
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] text-xs text-[#A7B0BC] space-y-1">
        <div className="flex justify-between text-[11px]">
          <span>Cost Ratio (% of revenue):</span>
          <span className="text-[#F5F7FA] font-medium font-mono">
            {formatPercent(revenue > 0 ? (cost / revenue) * 100 : 0)}
          </span>
        </div>
        <div className="flex justify-between text-[11px]">
          <span>Profit Ratio (% of revenue):</span>
          <span className="text-[#3CCB8E] font-medium font-mono">
            {formatPercent(result.profitMarginPercent)}
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
