import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateSponsorship, formatNumber } from '../../lib/calculatorMath';
import { useCurrency } from '../../context/CurrencyContext';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const SponsorshipCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('sponsorship-calculator')!;
  const { formatMoney, currency } = useCurrency();

  const [estimatedViews, setEstimatedViews] = useState<number>(35000);
  const [baseCpm, setBaseCpm] = useState<number>(25.0);
  const [deliverableMultiplier, setDeliverableMultiplier] = useState<number>(1.0);
  const [exclusivityMultiplier, setExclusivityMultiplier] = useState<number>(1.0);
  const [usageRightsMultiplier, setUsageRightsMultiplier] = useState<number>(1.0);

  const result = useMemo(() => {
    trackCalculatorAction('sponsorship-calculator');
    return calculateSponsorship({
      estimatedViews,
      baseCpm,
      deliverableMultiplier,
      exclusivityMultiplier,
      usageRightsMultiplier,
    });
  }, [estimatedViews, baseCpm, deliverableMultiplier, exclusivityMultiplier, usageRightsMultiplier]);

  const handleReset = () => {
    setEstimatedViews(35000);
    setBaseCpm(25.0);
    setDeliverableMultiplier(1.0);
    setExclusivityMultiplier(1.0);
    setUsageRightsMultiplier(1.0);
  };

  const inputsComponent = (
    <div className="space-y-4">
      <NumberInput
        id="spon-views"
        label="Expected Video Views / Reach"
        value={estimatedViews}
        onChange={setEstimatedViews}
        min={0}
        step={5000}
        helperText="Use recent 30-day median views per video"
      />

      <NumberInput
        id="spon-cpm"
        label="Baseline Sponsorship CPM"
        value={baseCpm}
        onChange={setBaseCpm}
        min={0}
        step={2.5}
        prefix={currency.symbol}
        helperText="Industry standard: $20 to $40 per 1,000 views"
      />

      {/* Deliverable Type */}
      <div>
        <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
          Deliverable Format
        </label>
        <select
          value={deliverableMultiplier}
          onChange={(e) => setDeliverableMultiplier(parseFloat(e.target.value))}
          className="w-full rounded-lg border border-[#252B33] bg-[#12161B] px-3 py-2 text-xs text-[#F5F7FA] focus:outline-none focus:border-[#7C5CFC]"
        >
          <option value={0.6}>Short / Reel / TikTok Video (0.6x base)</option>
          <option value={0.8}>30-second Integration (0.8x base)</option>
          <option value={1.0}>60-90 second Integrated Segment (1.0x standard)</option>
          <option value={1.5}>Dedicated Full Video (1.5x base)</option>
          <option value={1.8}>Dedicated Video + Social Cross-Posts (1.8x)</option>
        </select>
      </div>

      {/* Exclusivity */}
      <div>
        <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
          Competitive Exclusivity Clause
        </label>
        <select
          value={exclusivityMultiplier}
          onChange={(e) => setExclusivityMultiplier(parseFloat(e.target.value))}
          className="w-full rounded-lg border border-[#252B33] bg-[#12161B] px-3 py-2 text-xs text-[#F5F7FA] focus:outline-none focus:border-[#7C5CFC]"
        >
          <option value={1.0}>None (Standard - no competitor restrictions)</option>
          <option value={1.2}>30-Day Category Exclusivity (+20%)</option>
          <option value={1.35}>60-Day Category Exclusivity (+35%)</option>
          <option value={1.5}>90-Day Full Category Lockout (+50%)</option>
        </select>
      </div>

      {/* Usage Rights */}
      <div>
        <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
          Commercial Usage Rights & Whitelisting
        </label>
        <select
          value={usageRightsMultiplier}
          onChange={(e) => setUsageRightsMultiplier(parseFloat(e.target.value))}
          className="w-full rounded-lg border border-[#252B33] bg-[#12161B] px-3 py-2 text-xs text-[#F5F7FA] focus:outline-none focus:border-[#7C5CFC]"
        >
          <option value={1.0}>Organic Posting Only (Creator channel only)</option>
          <option value={1.25}>Brand Social Reposting / Digital PR (+25%)</option>
          <option value={1.4}>Paid Ad Whitelisting for 30 Days (+40%)</option>
          <option value={1.6}>Perpetual Paid Advertising Usage Rights (+60%)</option>
        </select>
      </div>
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <span className="text-xs uppercase tracking-wider text-[#A7B0BC] block mb-1">
          Recommended Sponsorship Quote
        </span>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {formatMoney(result.recommendedQuote)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          Based on {formatNumber(estimatedViews)} views with deliverable and rights multipliers
        </p>
      </div>

      <div className="p-4 rounded-xl bg-[#12161B] border border-[#252B33] space-y-2">
        <span className="text-xs font-semibold text-[#F5F7FA] block">
          Suggested Negotiation Window
        </span>
        <div className="flex items-center justify-between text-xs">
          <span className="text-[#A7B0BC]">Floor (Minimum acceptable):</span>
          <span className="font-semibold text-[#F5F7FA] font-mono">
            {formatMoney(result.lowEstimate)}
          </span>
        </div>
        <div className="w-full bg-[#181D23] h-2 rounded-full overflow-hidden border border-[#252B33]">
          <div className="bg-gradient-to-r from-[#7C5CFC] to-[#3CCB8E] h-full w-full" />
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-[#A7B0BC]">Ceiling (Anchor pitch quote):</span>
          <span className="font-semibold text-[#3CCB8E] font-mono">
            {formatMoney(result.highEstimate)}
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] flex items-center justify-between">
        <span className="text-xs text-[#A7B0BC]">Unadjusted Base View Fee:</span>
        <span className="text-sm font-medium text-[#F5F7FA]">
          {formatMoney(result.baseFee)}
        </span>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
