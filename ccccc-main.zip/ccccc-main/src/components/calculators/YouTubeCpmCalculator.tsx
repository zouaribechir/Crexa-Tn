import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateYouTubeCpm, formatNumber } from '../../lib/calculatorMath';
import { useCurrency } from '../../context/CurrencyContext';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const YouTubeCpmCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('youtube-cpm-calculator')!;
  const { formatMoney, currency } = useCurrency();

  const [cost, setCost] = useState<number>(1200);
  const [impressions, setImpressions] = useState<number>(150000);

  const result = useMemo(() => {
    trackCalculatorAction('youtube-cpm-calculator');
    return calculateYouTubeCpm({ cost, impressions });
  }, [cost, impressions]);

  const handleReset = () => {
    setCost(1200);
    setImpressions(150000);
  };

  const creatorNetShare = result.cpm * 0.55;

  const inputsComponent = (
    <div className="space-y-4">
      <NumberInput
        id="cpm-cost"
        label="Total Ad Spend or Campaign Cost"
        value={cost}
        onChange={setCost}
        min={0}
        step={50}
        prefix={currency.symbol}
        helperText="Advertiser budget or media invoice"
      />

      <NumberInput
        id="cpm-impressions"
        label="Total Commercial Ad Impressions"
        value={impressions}
        onChange={setImpressions}
        min={0}
        step={10000}
        helperText="Total ad impressions rendered"
      />
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <span className="text-xs uppercase tracking-wider text-[#A7B0BC] block mb-1">
          Advertiser CPM (Cost Per 1,000 Impressions)
        </span>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {currency.symbol}{result.cpm.toFixed(2)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          Based on {formatMoney(cost)} spend across {formatNumber(impressions)} impressions
        </p>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] flex items-center justify-between">
        <span className="text-xs text-[#A7B0BC]">Cost Per Individual Impression:</span>
        <span className="text-sm font-mono font-bold text-[#F5F7FA]">
          {currency.symbol}{result.costPerImpression.toFixed(5)}
        </span>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] flex items-center justify-between">
        <div>
          <span className="text-xs text-[#A7B0BC] block">Estimated Creator 55% Cut (RPM):</span>
          <span className="text-[11px] text-[#A7B0BC]">After YouTube 45% revenue split</span>
        </div>
        <span className="text-sm font-bold text-[#3CCB8E]">
          {currency.symbol}{creatorNetShare.toFixed(2)}
        </span>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
