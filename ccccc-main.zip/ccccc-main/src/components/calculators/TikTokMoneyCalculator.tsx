import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateTikTokMoney, formatNumber } from '../../lib/calculatorMath';
import { useCurrency } from '../../context/CurrencyContext';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const TikTokMoneyCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('tiktok-money-calculator')!;
  const { formatMoney, currency } = useCurrency();

  const [views, setViews] = useState<number>(500000);
  const [estimatedRpm, setEstimatedRpm] = useState<number>(0.60);

  const result = useMemo(() => {
    trackCalculatorAction('tiktok-money-calculator');
    return calculateTikTokMoney({ views, estimatedRpm });
  }, [views, estimatedRpm]);

  const handleReset = () => {
    setViews(500000);
    setEstimatedRpm(0.60);
  };

  const inputsComponent = (
    <div className="space-y-4">
      <NumberInput
        id="tt-views"
        label="Estimated Qualified Video Views"
        value={views}
        onChange={setViews}
        min={0}
        step={50000}
        helperText="Eligible FYP views on videos longer than 1 minute"
      />

      <NumberInput
        id="tt-rpm"
        label="Estimated RPM (Rate per 1,000 Qualified Views)"
        value={estimatedRpm}
        onChange={setEstimatedRpm}
        min={0}
        step={0.05}
        prefix={currency.symbol}
        helperText="Creator Rewards Program averages $0.30 - $1.20"
      />

      {/* Program Presets */}
      <div className="pt-2">
        <span className="text-[11px] text-[#A7B0BC] block mb-1.5">Program Assumptions:</span>
        <div className="flex flex-wrap gap-1.5">
          {[
            { label: 'Legacy Fund ($0.03)', val: 0.03 },
            { label: 'Rewards Low ($0.35)', val: 0.35 },
            { label: 'Rewards Mid ($0.65)', val: 0.65 },
            { label: 'Rewards High ($1.10)', val: 1.10 },
          ].map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => setEstimatedRpm(item.val)}
              className="text-[11px] px-2.5 py-1 rounded-md border border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA] hover:border-[#7C5CFC] transition-colors"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <span className="text-xs uppercase tracking-wider text-[#A7B0BC] block mb-1">
          Estimated Video Rewards Payout
        </span>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {formatMoney(result.estimatedEarnings)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          For {formatNumber(views)} qualified views at {currency.symbol}{estimatedRpm.toFixed(2)} RPM
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Earnings Per 100k Views</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatMoney(estimatedRpm * 100)}
          </span>
        </div>

        <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[11px] text-[#A7B0BC] block">Earnings Per 1M Views</span>
          <span className="text-lg font-bold text-[#F5F7FA]">
            {formatMoney(estimatedRpm * 1000)}
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] flex items-center justify-between">
        <span className="text-xs text-[#A7B0BC]">Effective Per-View Return:</span>
        <span className="text-sm font-mono font-bold text-[#3CCB8E]">
          {currency.symbol}{result.effectivePerView.toFixed(6)}
        </span>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
