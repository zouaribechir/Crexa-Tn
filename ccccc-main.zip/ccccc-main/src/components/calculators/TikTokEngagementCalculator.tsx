import React, { useState, useMemo } from 'react';
import { CALCULATORS_BY_ID } from '../../data/calculators';
import { CalculatorLayout } from '../CalculatorLayout';
import { NumberInput } from '../NumberInput';
import { calculateTikTokEngagement, formatNumber, formatPercent } from '../../lib/calculatorMath';
import { trackCalculatorAction } from '../GoogleAnalytics';

export const TikTokEngagementCalculator: React.FC = () => {
  const calculator = CALCULATORS_BY_ID.get('tiktok-engagement-calculator')!;

  const [likes, setLikes] = useState<number>(3500);
  const [comments, setComments] = useState<number>(180);
  const [shares, setShares] = useState<number>(120);
  const [saves, setSaves] = useState<number>(200);
  const [denominatorType, setDenominatorType] = useState<'views' | 'followers'>('views');
  const [denominatorValue, setDenominatorValue] = useState<number>(45000);

  const result = useMemo(() => {
    trackCalculatorAction('tiktok-engagement-calculator');
    return calculateTikTokEngagement({
      likes,
      comments,
      shares,
      saves,
      denominatorType,
      denominatorValue,
    });
  }, [likes, comments, shares, saves, denominatorType, denominatorValue]);

  const handleReset = () => {
    setLikes(3500);
    setComments(180);
    setShares(120);
    setSaves(200);
    setDenominatorType('views');
    setDenominatorValue(45000);
  };

  const inputsComponent = (
    <div className="space-y-4">
      {/* Denominator Type Selector */}
      <div>
        <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
          Calculation Basis (Denominator)
        </label>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setDenominatorType('views')}
            className={`py-2 text-xs font-medium rounded-lg border transition-colors ${
              denominatorType === 'views'
                ? 'border-[#7C5CFC] bg-[#7C5CFC] text-white'
                : 'border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA]'
            }`}
          >
            By Video Views (Recommended)
          </button>
          <button
            type="button"
            onClick={() => setDenominatorType('followers')}
            className={`py-2 text-xs font-medium rounded-lg border transition-colors ${
              denominatorType === 'followers'
                ? 'border-[#7C5CFC] bg-[#7C5CFC] text-white'
                : 'border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA]'
            }`}
          >
            By Profile Followers
          </button>
        </div>
        <p className="text-[11px] text-[#A7B0BC] mt-1">
          {denominatorType === 'views'
            ? 'Measures content resonance with viewers who actually saw the video.'
            : 'Measures community engagement relative to total account following.'}
        </p>
      </div>

      <NumberInput
        id="tt-denom"
        label={denominatorType === 'views' ? 'Total Video Views' : 'Total Account Followers'}
        value={denominatorValue}
        onChange={setDenominatorValue}
        min={0}
        step={5000}
        helperText={`Active denominator for rate calculation`}
      />

      <div className="grid grid-cols-2 gap-3 pt-2">
        <NumberInput
          id="tt-likes"
          label="Likes"
          value={likes}
          onChange={setLikes}
          min={0}
          step={100}
        />

        <NumberInput
          id="tt-comments"
          label="Comments"
          value={comments}
          onChange={setComments}
          min={0}
          step={20}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <NumberInput
          id="tt-shares"
          label="Shares"
          value={shares}
          onChange={setShares}
          min={0}
          step={20}
        />

        <NumberInput
          id="tt-saves"
          label="Saves / Favorites"
          value={saves}
          onChange={setSaves}
          min={0}
          step={20}
        />
      </div>
    </div>
  );

  const resultsComponent = (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-[#0B0D10] border border-[#252B33]">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs uppercase tracking-wider text-[#A7B0BC]">
            Engagement Rate (by {denominatorType})
          </span>
          <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-[#7C5CFC]/20 text-[#7C5CFC]">
            {denominatorType} mode
          </span>
        </div>
        <div className="text-3xl sm:text-4xl font-extrabold text-[#3CCB8E] tracking-tight">
          {formatPercent(result.engagementRatePercent)}
        </div>
        <p className="text-xs text-[#A7B0BC] mt-1.5">
          {formatNumber(result.totalInteractions)} total interactions across {formatNumber(denominatorValue)} {denominatorType}
        </p>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="p-2.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[10px] text-[#A7B0BC] block">Likes Ratio</span>
          <span className="text-xs font-bold text-[#F5F7FA]">
            {formatPercent(result.likesRatio)}
          </span>
        </div>
        <div className="p-2.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[10px] text-[#A7B0BC] block">Comments Ratio</span>
          <span className="text-xs font-bold text-[#F5F7FA]">
            {formatPercent(result.commentsRatio)}
          </span>
        </div>
        <div className="p-2.5 rounded-lg bg-[#12161B] border border-[#252B33]">
          <span className="text-[10px] text-[#A7B0BC] block">Shares Ratio</span>
          <span className="text-xs font-bold text-[#F5F7FA]">
            {formatPercent(result.sharesRatio)}
          </span>
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-[#12161B] border border-[#252B33] text-xs text-[#A7B0BC]">
        <span className="font-semibold text-[#F5F7FA] block mb-1">TikTok Benchmark Reference:</span>
        <p>
          Average view-based engagement on TikTok is <strong>4%–8%</strong>. Exceptional viral videos achieve <strong>10%+</strong>.
        </p>
      </div>
    </div>
  );

  return (
    <CalculatorLayout
      calculator={calculator}
      inputsComponent={inputsComponent}
      resultsComponent={resultsComponent}
      onReset={handleReset}
    />
  );
};
