import React from 'react';
import { CATEGORIES } from '../data/categories';
import { CalculatorCategory } from '../types';

interface CategoryFilterProps {
  activeCategory: CalculatorCategory | 'all';
  onSelect: (category: CalculatorCategory | 'all') => void;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({ activeCategory, onSelect }) => {
  return (
    <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
      <button
        type="button"
        onClick={() => onSelect('all')}
        className={`px-3.5 py-1.5 text-xs font-medium rounded-lg border transition-all whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-[#7C5CFC] ${
          activeCategory === 'all'
            ? 'border-[#7C5CFC] bg-[#7C5CFC] text-white shadow-sm'
            : 'border-[#252B33] bg-[#12161B] text-[#A7B0BC] hover:text-[#F5F7FA] hover:bg-[#181D23]'
        }`}
      >
        All Categories (12)
      </button>

      {CATEGORIES.map((cat) => {
        const isActive = activeCategory === cat.id;
        return (
          <button
            key={cat.id}
            type="button"
            onClick={() => onSelect(cat.id)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg border transition-all whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-[#7C5CFC] ${
              isActive
                ? 'border-[#7C5CFC] bg-[#7C5CFC] text-white shadow-sm'
                : 'border-[#252B33] bg-[#12161B] text-[#A7B0BC] hover:text-[#F5F7FA] hover:bg-[#181D23]'
            }`}
          >
            {cat.name}
          </button>
        );
      })}
    </div>
  );
};
