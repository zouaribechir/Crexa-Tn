import React, { useEffect } from 'react';
import { useRouter } from '../context/RouterContext';
import { CalculatorFaq } from '../types';

interface SeoHeadProps {
  title: string;
  description: string;
  canonicalPath?: string;
  type?: 'website' | 'article';
  breadcrumbs?: { name: string; path: string }[];
  faqs?: CalculatorFaq[];
  softwareApp?: {
    name: string;
    description: string;
    applicationCategory?: string;
  };
}

const CANONICAL_ORIGIN = 'https://crexa.tn';

function updateMetaTag(attrName: 'name' | 'property', attrValue: string, content: string): void {
  let element = document.querySelector(`meta[${attrName}="${attrValue}"]`) as HTMLMetaElement | null;
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attrName, attrValue);
    document.head.appendChild(element);
  }
  element.setAttribute('content', content);
}

function updateLinkCanonical(url: string): void {
  let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', 'canonical');
    document.head.appendChild(link);
  }
  link.setAttribute('href', url);
}

function updateJsonLd(id: string, data: Record<string, unknown>): void {
  let script = document.getElementById(id) as HTMLScriptElement | null;
  if (!script) {
    script = document.createElement('script');
    script.id = id;
    script.type = 'application/ld+json';
    document.head.appendChild(script);
  }
  script.text = JSON.stringify(data);
}

export const SeoHead: React.FC<SeoHeadProps> = ({
  title,
  description,
  canonicalPath,
  type = 'website',
  breadcrumbs,
  faqs,
  softwareApp,
}) => {
  const { currentPath } = useRouter();
  const effectivePath = canonicalPath || currentPath;
  const canonicalUrl = `${CANONICAL_ORIGIN}${effectivePath === '/' ? '' : effectivePath}`;
  const ogImageUrl = `${CANONICAL_ORIGIN}/og-image.png`;

  useEffect(() => {
    // 1. Page Title
    document.title = title;

    // 2. Meta description
    updateMetaTag('name', 'description', description);

    // 3. Canonical link
    updateLinkCanonical(canonicalUrl);

    // 4. OpenGraph tags
    updateMetaTag('property', 'og:title', title);
    updateMetaTag('property', 'og:description', description);
    updateMetaTag('property', 'og:url', canonicalUrl);
    updateMetaTag('property', 'og:type', type);
    updateMetaTag('property', 'og:site_name', 'CREXA');
    updateMetaTag('property', 'og:image', ogImageUrl);

    // 5. Twitter Card tags
    updateMetaTag('name', 'twitter:card', 'summary_large_image');
    updateMetaTag('name', 'twitter:title', title);
    updateMetaTag('name', 'twitter:description', description);
    updateMetaTag('name', 'twitter:image', ogImageUrl);

    // 6. Organization & WebSite JSON-LD
    const baseSiteSchema = {
      '@context': 'https://schema.org',
      '@graph': [
        {
          '@type': 'Organization',
          '@id': `${CANONICAL_ORIGIN}/#organization`,
          name: 'CREXA',
          url: CANONICAL_ORIGIN,
          logo: `${CANONICAL_ORIGIN}/favicon.svg`,
          description: 'Global digital calculator platform for creators and online businesses.',
          sameAs: [],
        },
        {
          '@type': 'WebSite',
          '@id': `${CANONICAL_ORIGIN}/#website`,
          url: CANONICAL_ORIGIN,
          name: 'CREXA',
          publisher: { '@id': `${CANONICAL_ORIGIN}/#organization` },
          description: 'Calculate smarter. Grow faster. Creator and business calculators.',
        },
      ],
    };
    updateJsonLd('jsonld-crexa-base', baseSiteSchema);

    // 7. BreadcrumbList JSON-LD if present
    if (breadcrumbs && breadcrumbs.length > 0) {
      const breadcrumbSchema = {
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: breadcrumbs.map((b, index) => ({
          '@type': 'ListItem',
          position: index + 1,
          name: b.name,
          item: `${CANONICAL_ORIGIN}${b.path}`,
        })),
      };
      updateJsonLd('jsonld-crexa-breadcrumbs', breadcrumbSchema);
    } else {
      const existing = document.getElementById('jsonld-crexa-breadcrumbs');
      if (existing) existing.remove();
    }

    // 8. SoftwareApplication JSON-LD if present
    if (softwareApp) {
      const softwareSchema = {
        '@context': 'https://schema.org',
        '@type': 'SoftwareApplication',
        name: softwareApp.name,
        applicationCategory: softwareApp.applicationCategory || 'BusinessApplication',
        operatingSystem: 'All',
        url: canonicalUrl,
        description: softwareApp.description,
        offers: {
          '@type': 'Offer',
          price: '0',
          priceCurrency: 'USD',
        },
      };
      updateJsonLd('jsonld-crexa-software', softwareSchema);
    } else {
      const existing = document.getElementById('jsonld-crexa-software');
      if (existing) existing.remove();
    }

    // 9. FAQPage JSON-LD if present
    if (faqs && faqs.length > 0) {
      const faqSchema = {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqs.map((f) => ({
          '@type': 'Question',
          name: f.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: f.answer,
          },
        })),
      };
      updateJsonLd('jsonld-crexa-faq', faqSchema);
    } else {
      const existing = document.getElementById('jsonld-crexa-faq');
      if (existing) existing.remove();
    }
  }, [title, description, canonicalUrl, type, ogImageUrl, breadcrumbs, faqs, softwareApp]);

  return null;
};
