import React from 'react';
import { CalculatorDefinition } from '../types';
import { SeoHead } from './SeoHead';
import { Breadcrumbs } from './Breadcrumbs';
import { DynamicIcon } from './DynamicIcon';
import { FaqSection } from './FaqSection';
import { RelatedCalculators } from './RelatedCalculators';
import { Check, HelpCircle, AlertCircle, BookOpen, Calculator as CalcIcon } from 'lucide-react';

interface CalculatorLayoutProps {
  calculator: CalculatorDefinition;
  inputsComponent: React.ReactNode;
  resultsComponent: React.ReactNode;
  onReset?: () => void;
}

export const CalculatorLayout: React.FC<CalculatorLayoutProps> = ({
  calculator,
  inputsComponent,
  resultsComponent,
  onReset,
}) => {
  const breadcrumbs = [
    { label: 'Calculators', href: '/calculators' },
    { label: calculator.categoryName, href: `/${calculator.category}` },
    { label: calculator.name },
  ];

  return (
    <>
      <SeoHead
        title={calculator.metaTitle}
        description={calculator.metaDescription}
        canonicalPath={calculator.slug}
        breadcrumbs={[
          { name: 'Home', path: '/' },
          { name: 'Calculators', path: '/calculators' },
          { name: calculator.categoryName, path: `/${calculator.category}` },
          { name: calculator.name, path: calculator.slug },
        ]}
        faqs={calculator.faqs}
        softwareApp={{
          name: calculator.name,
          description: calculator.shortDescription,
        }}
      />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
        {/* Breadcrumbs */}
        <Breadcrumbs items={breadcrumbs} />

        {/* Header Hero */}
        <div className="border-b border-[#252B33] pb-6">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#7C5CFC] mb-2">
            <DynamicIcon name={calculator.iconName} className="w-4 h-4" />
            <span>{calculator.categoryName} Calculator</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-[#F5F7FA]">
            {calculator.name}
          </h1>

          <p className="mt-2 text-sm sm:text-base text-[#A7B0BC] max-w-3xl leading-relaxed">
            {calculator.shortDescription}
          </p>
        </div>

        {/* Main Interactive Tool Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Inputs Column */}
          <div className="lg:col-span-6 rounded-xl border border-[#252B33] bg-[#12161B] p-6 shadow-lg space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-[#252B33]">
              <div className="flex items-center gap-2">
                <CalcIcon className="w-4 h-4 text-[#7C5CFC]" />
                <h2 className="text-sm font-bold uppercase tracking-wider text-[#F5F7FA]">
                  Inputs & Assumptions
                </h2>
              </div>
              {onReset && (
                <button
                  type="button"
                  onClick={onReset}
                  className="text-xs text-[#A7B0BC] hover:text-[#F5F7FA] underline focus:outline-none"
                >
                  Reset Defaults
                </button>
              )}
            </div>

            {inputsComponent}
          </div>

          {/* Results Column */}
          <div className="lg:col-span-6 space-y-6">
            <div className="rounded-xl border border-[#252B33] bg-[#181D23] p-6 shadow-lg space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#252B33]">
                <h2 className="text-sm font-bold uppercase tracking-wider text-[#3CCB8E]">
                  Calculation Results
                </h2>
                <span className="text-[11px] text-[#A7B0BC] font-mono">Real-time estimate</span>
              </div>

              {resultsComponent}
            </div>

            {/* Formula Summary Box */}
            <div className="rounded-xl border border-[#252B33] bg-[#12161B] p-5 text-xs space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F5F7FA]">
                <HelpCircle className="w-3.5 h-3.5 text-[#7C5CFC]" />
                <span>Formula Used:</span>
              </div>
              <p className="font-mono bg-[#0B0D10] p-2.5 rounded-lg border border-[#252B33] text-[#3CCB8E] text-[13px]">
                {calculator.formulaSummary}
              </p>
              <p className="text-[#A7B0BC] leading-relaxed pt-1">
                {calculator.formulaExplanation}
              </p>
            </div>
          </div>
        </div>

        {/* Worked Example */}
        <section className="rounded-xl border border-[#252B33] bg-[#12161B] p-6 space-y-4">
          <h2 className="text-lg font-bold text-[#F5F7FA] flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-[#7C5CFC]" />
            <span>Worked Example: {calculator.workedExample.scenario}</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-lg bg-[#181D23] border border-[#252B33]">
              <span className="font-semibold text-[#A7B0BC] uppercase tracking-wider block mb-2 text-[10px]">
                Sample Inputs
              </span>
              <ul className="space-y-1 font-mono text-[#F5F7FA]">
                {Object.entries(calculator.workedExample.inputs).map(([key, val]) => (
                  <li key={key}>
                    <span className="text-[#A7B0BC]">{key}:</span> {val}
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-lg bg-[#181D23] border border-[#252B33]">
              <span className="font-semibold text-[#A7B0BC] uppercase tracking-wider block mb-2 text-[10px]">
                Step-by-Step Calculation
              </span>
              <p className="font-mono text-[#F5F7FA] leading-relaxed">
                {calculator.workedExample.calculation}
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#181D23] border border-[#252B33]">
              <span className="font-semibold text-[#3CCB8E] uppercase tracking-wider block mb-2 text-[10px]">
                Final Output
              </span>
              <p className="font-semibold text-[#3CCB8E] text-sm leading-relaxed">
                {calculator.workedExample.result}
              </p>
            </div>
          </div>
        </section>

        {/* How to Use Section */}
        <section className="rounded-xl border border-[#252B33] bg-[#12161B] p-6 space-y-4">
          <h2 className="text-lg font-bold text-[#F5F7FA]">
            How to Use This Calculator
          </h2>
          <ol className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-[#A7B0BC]">
            {calculator.howToUseSteps.map((step, idx) => (
              <li key={idx} className="flex items-start gap-2.5 p-3 rounded-lg bg-[#181D23] border border-[#252B33]">
                <span className="w-5 h-5 rounded-full bg-[#7C5CFC]/20 text-[#7C5CFC] font-semibold flex items-center justify-center flex-shrink-0 text-[11px]">
                  {idx + 1}
                </span>
                <span className="leading-relaxed text-[#F5F7FA]">{step}</span>
              </li>
            ))}
          </ol>
        </section>

        {/* Educational Guide */}
        <article className="rounded-xl border border-[#252B33] bg-[#12161B] p-6 sm:p-8 space-y-4">
          <h2 className="text-xl font-bold text-[#F5F7FA]">
            {calculator.educationalContent.title}
          </h2>
          <div className="space-y-3 text-sm text-[#A7B0BC] leading-relaxed">
            {calculator.educationalContent.paragraphs.map((p, idx) => (
              <p key={idx}>{p}</p>
            ))}
          </div>
        </article>

        {/* Disclaimer */}
        <div className="flex items-start gap-3 p-4 rounded-xl border border-[#252B33] bg-[#181D23] text-xs text-[#A7B0BC]">
          <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-semibold text-[#F5F7FA]">Platform Estimate Disclaimer</span>
            <p className="leading-relaxed">{calculator.disclaimer}</p>
          </div>
        </div>

        {/* FAQs */}
        <FaqSection faqs={calculator.faqs} />

        {/* Related Calculators */}
        <RelatedCalculators relatedIds={calculator.relatedCalculatorIds} />
      </div>
    </>
  );
};
