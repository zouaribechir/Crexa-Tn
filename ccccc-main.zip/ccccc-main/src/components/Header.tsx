import React, { useState, useEffect } from 'react';
import { useRouter } from '../context/RouterContext';
import { Link } from './Link';
import { ThemeToggle } from './ThemeToggle';
import { CurrencySelector } from './CurrencySelector';
import { SearchModal } from './SearchModal';
import { Search, Menu, X, Calculator } from 'lucide-react';

export const Header: React.FC = () => {
  const { currentPath } = useRouter();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Keyboard shortcut Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [currentPath]);

  const navLinks = [
    { label: 'All Calculators', href: '/calculators' },
    { label: 'YouTube', href: '/youtube' },
    { label: 'TikTok', href: '/tiktok' },
    { label: 'Instagram', href: '/instagram' },
    { label: 'Affiliate', href: '/affiliate' },
    { label: 'Business', href: '/business' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#252B33] bg-[#0B0D10]/90 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo / Brand */}
          <Link href="/" className="flex items-center gap-3 group focus:outline-none focus:ring-2 focus:ring-[#7C5CFC] rounded-lg p-1">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#7C5CFC] to-[#6847F5] flex items-center justify-center text-white shadow-md shadow-[#7C5CFC]/20">
              <Calculator className="w-4 h-4" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight text-[#F5F7FA]">CREXA</span>
              <span className="text-[10px] tracking-wider uppercase text-[#A7B0BC] font-medium hidden sm:block">
                Calculate smarter
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center space-x-1" aria-label="Main Navigation">
            {navLinks.map((link) => {
              const isActive = currentPath === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    isActive
                      ? 'text-[#F5F7FA] bg-[#181D23]'
                      : 'text-[#A7B0BC] hover:text-[#F5F7FA] hover:bg-[#12161B]'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* Right Tools: Search, Currency, Theme, Mobile toggle */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsSearchOpen(true)}
              aria-label="Search calculators"
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#252B33] bg-[#12161B] text-xs text-[#A7B0BC] hover:text-[#F5F7FA] hover:border-[#7C5CFC] transition-colors focus:outline-none focus:ring-2 focus:ring-[#7C5CFC]"
            >
              <Search className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Search...</span>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-[#181D23] rounded border border-[#252B33]">
                ⌘K
              </kbd>
            </button>

            <CurrencySelector />
            <ThemeToggle />

            {/* Mobile menu button */}
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Toggle navigation menu"
              className="lg:hidden p-2 rounded-lg border border-[#252B33] bg-[#12161B] text-[#F5F7FA] hover:border-[#7C5CFC] transition-colors focus:outline-none focus:ring-2 focus:ring-[#7C5CFC]"
            >
              {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-[#252B33] bg-[#0B0D10] px-4 pt-3 pb-6 space-y-1">
          {navLinks.map((link) => {
            const isActive = currentPath === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`block px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                  isActive
                    ? 'text-[#F5F7FA] bg-[#181D23]'
                    : 'text-[#A7B0BC] hover:text-[#F5F7FA] hover:bg-[#12161B]'
                }`}
              >
                {link.label}
              </Link>
            );
          })}
          <div className="pt-2 border-t border-[#252B33] flex flex-col gap-1 text-xs text-[#A7B0BC]">
            <Link href="/about" className="px-3 py-1.5 hover:text-[#F5F7FA]">About CREXA</Link>
            <Link href="/privacy" className="px-3 py-1.5 hover:text-[#F5F7FA]">Privacy Policy</Link>
            <Link href="/terms" className="px-3 py-1.5 hover:text-[#F5F7FA]">Terms of Use</Link>
            <Link href="/sitemap" className="px-3 py-1.5 hover:text-[#F5F7FA]">Sitemap</Link>
          </div>
        </div>
      )}

      {/* Search Modal */}
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </header>
  );
};
