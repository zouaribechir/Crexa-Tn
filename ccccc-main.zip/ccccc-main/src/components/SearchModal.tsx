import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from '../context/RouterContext';
import { CALCULATORS } from '../data/calculators';
import { DynamicIcon } from './DynamicIcon';
import { Search, X, ArrowRight } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose }) => {
  const { navigate } = useRouter();
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  const filtered = query.trim() === ''
    ? CALCULATORS.slice(0, 6)
    : CALCULATORS.filter((c) => {
        const q = query.toLowerCase();
        return (
          c.name.toLowerCase().includes(q) ||
          c.shortDescription.toLowerCase().includes(q) ||
          c.categoryName.toLowerCase().includes(q) ||
          c.primaryKeyword.toLowerCase().includes(q)
        );
      });

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  const handleSelect = (slug: string) => {
    navigate(slug);
    onClose();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < filtered.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter' && filtered[selectedIndex]) {
      e.preventDefault();
      handleSelect(filtered[selectedIndex].slug);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="search-modal-title"
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/75 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl rounded-xl border border-[#252B33] bg-[#12161B] text-[#F5F7FA] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        <div className="flex items-center px-4 py-3.5 border-b border-[#252B33]">
          <Search className="w-5 h-5 text-[#A7B0BC] mr-3" />
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search calculators (e.g. YouTube money, TikTok, RPM, profit)..."
            className="w-full bg-transparent text-sm text-[#F5F7FA] placeholder-[#A7B0BC] focus:outline-none"
          />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close search"
            className="p-1 rounded text-[#A7B0BC] hover:text-[#F5F7FA] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="max-h-80 overflow-y-auto p-2">
          <div className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-[#A7B0BC]">
            {query.trim() === '' ? 'Popular Calculators' : `${filtered.length} Results`}
          </div>

          {filtered.length === 0 ? (
            <div className="py-8 text-center text-sm text-[#A7B0BC]">
              No calculators found matching &quot;{query}&quot;. Try searching for &quot;YouTube&quot;, &quot;RPM&quot;, or &quot;commission&quot;.
            </div>
          ) : (
            <div className="space-y-1">
              {filtered.map((item, index) => {
                const isSelected = index === selectedIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelect(item.slug)}
                    onMouseEnter={() => setSelectedIndex(index)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-[#181D23] border border-[#7C5CFC]/50 text-[#F5F7FA]'
                        : 'text-[#A7B0BC] hover:bg-[#181D23] hover:text-[#F5F7FA]'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="p-2 rounded-lg bg-[#252B33] text-[#7C5CFC] flex-shrink-0">
                        <DynamicIcon name={item.iconName} className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-[#F5F7FA] truncate">
                          {item.name}
                        </div>
                        <div className="text-xs text-[#A7B0BC] truncate">
                          {item.shortDescription}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#A7B0BC] flex-shrink-0 ml-2" />
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <div className="px-4 py-2 bg-[#0B0D10] border-t border-[#252B33] text-[11px] text-[#A7B0BC] flex items-center justify-between">
          <span>Navigate with &uarr; &darr; arrows &middot; Select with Enter</span>
          <span>Esc to exit</span>
        </div>
      </div>
    </div>
  );
};
