import { CalculatorDefinition } from '../types';

export const CALCULATORS: CalculatorDefinition[] = [
  {
    id: 'youtube-money-calculator',
    slug: '/youtube-money-calculator',
    name: 'YouTube Money Calculator',
    shortDescription: 'Estimate your YouTube ad revenue based on views and RPM assumptions.',
    category: 'youtube',
    categoryName: 'YouTube',
    iconName: 'Youtube',
    priority: true,
    metaTitle: 'YouTube Money Calculator: Estimate Ad Revenue | CREXA',
    metaDescription:
      'Estimate your YouTube channel revenue with CREXA. Enter views and RPM to calculate daily, monthly, and yearly creator ad earnings accurately.',
    primaryKeyword: 'YouTube money calculator',
    formulaSummary: 'Estimated Earnings = (Views ÷ 1,000) × RPM',
    formulaExplanation:
      'YouTube ad earnings are calculated on a Revenue Per Mille (RPM) basis. Since RPM represents the net dollars a creator receives for every 1,000 video views (after YouTube takes its 45% platform split), total earnings equal views divided by 1,000 multiplied by your average RPM.',
    workedExample: {
      scenario: 'A finance creator gets 120,000 monthly views with an RPM of $6.50.',
      inputs: {
        'Video Views': '120,000',
        'Estimated RPM': '$6.50',
      },
      calculation: '(120,000 ÷ 1,000) × $6.50 = 120 × $6.50',
      result: '$780.00 estimated monthly earnings ($9,360.00/year)',
    },
    howToUseSteps: [
      'Enter your total or monthly expected video views in the Views field.',
      'Input your estimated RPM (typical YouTube channels average between $1.50 and $10.00 depending on audience geography and niche).',
      'Review your estimated total, daily, monthly, and yearly income projections.',
      'Adjust the views or RPM sliders to simulate growth scenarios.',
    ],
    educationalContent: {
      title: 'Understanding YouTube Ad Monetization & RPM Mechanics',
      paragraphs: [
        'RPM (Revenue Per Mille) is the metric YouTube Studio provides to display how much money a creator earns per 1,000 views. Unlike CPM, which reflects what advertisers pay, RPM accounts for all monetized and non-monetized views, ad formats, YouTube Premium subscriptions, and channel memberships.',
        'Your channel RPM fluctuates depending on several crucial variables: audience location (viewers in North America and Western Europe command much higher ad rates), channel niche (finance, software, and real estate pay more than gaming and comedy), and seasonality (Q4 holiday advertising surges typically double creator RPMs compared to January).',
        'To maximize your RPM, focus on increasing average watch time (which triggers mid-roll ad opportunities on videos over 8 minutes), targeting commercial viewer intents, and building loyalty among high-value demographic regions.',
      ],
    },
    faqs: [
      {
        question: 'How much money do you make per 1,000 views on YouTube?',
        answer:
          'Most YouTube creators make between $1.50 and $8.00 per 1,000 views. High-paying niches such as personal finance, B2B software, and tech can reach $12.00 to $30.00+ RPM, while general entertainment, gaming, and compilation channels typically see $1.00 to $3.00.',
      },
      {
        question: 'Does YouTube take a cut from this estimated revenue?',
        answer:
          'RPM is already net of YouTube’s cut. YouTube takes 45% of long-form ad revenue from advertisers and awards 55% to the creator. When you input your net RPM, the calculator reflects your take-home amount before personal income taxes.',
      },
      {
        question: 'Why do my actual YouTube Studio earnings differ from this estimate?',
        answer:
          'Not every view serves an ad (ad-blockers, non-monetized regions, and viewer frequency caps reduce ad inventory), and RPM varies from video to video. This calculator provides a mathematical estimate based on your uniform assumptions.',
      },
      {
        question: 'Do YouTube Shorts earn the same RPM as long-form videos?',
        answer:
          'No. YouTube Shorts use a pooled revenue model where creators typically earn between $0.02 and $0.08 per 1,000 views. For Shorts calculations, input an RPM within that range.',
      },
    ],
    disclaimer:
      'Estimates provided by this tool are for educational and planning purposes only. Real YouTube earnings fluctuate depending on viewer location, ad blockers, advertiser demand, seasonality, and YouTube Partner Program terms.',
    relatedCalculatorIds: [
      'youtube-rpm-calculator',
      'youtube-cpm-calculator',
      'sponsorship-calculator',
      'video-roi-calculator',
    ],
  },
  {
    id: 'youtube-rpm-calculator',
    slug: '/youtube-rpm-calculator',
    name: 'YouTube RPM Calculator',
    shortDescription: 'Calculate your actual Revenue Per 1,000 views from your analytics.',
    category: 'youtube',
    categoryName: 'YouTube',
    iconName: 'DollarSign',
    metaTitle: 'YouTube RPM Calculator: Revenue Per 1,000 Views | CREXA',
    metaDescription:
      'Calculate your true YouTube RPM (Revenue Per Mille) accurately. Discover your earnings per 1,000 views and earnings per individual view with CREXA.',
    primaryKeyword: 'YouTube RPM calculator',
    formulaSummary: 'RPM = (Total Revenue ÷ Total Views) × 1,000',
    formulaExplanation:
      'Revenue Per Mille (RPM) reveals how much revenue your channel earns for every 1,000 video views. By dividing your total net creator revenue by total video views and multiplying by 1,000, you obtain your true monetized efficiency.',
    workedExample: {
      scenario: 'You earned $450.00 from a video that generated 75,000 views.',
      inputs: {
        'Total Revenue': '$450.00',
        'Total Views': '75,000',
      },
      calculation: '($450.00 ÷ 75,000) × 1,000 = $0.006 × 1,000',
      result: '$6.00 RPM ($0.006 per view)',
    },
    howToUseSteps: [
      'Find your video or channel total revenue in YouTube Studio.',
      'Check the corresponding view count over that same time period.',
      'Input the revenue and view count into the calculator.',
      'See your calculated RPM and effective earnings per single view.',
    ],
    educationalContent: {
      title: 'Why RPM Is the Single Most Important Creator Metric',
      paragraphs: [
        'Before YouTube introduced RPM in 2020, creators had to rely on CPM, which was misleading because it only measured views where an ad actually showed up and represented advertiser spend rather than creator payout.',
        'RPM measures your overall monetization efficiency across all views. If your RPM is rising while view counts remain steady, your channel is becoming more commercially valuable.',
        'Tracking RPM by video topic lets you identify your highest-earning content pillars so you can produce more videos that attract premium advertiser bids.',
      ],
    },
    faqs: [
      {
        question: 'What is considered a good YouTube RPM?',
        answer:
          'An RPM of $3.00 to $6.00 is solid for mainstream topics. RPMs above $8.00 are considered strong, and RPMs exceeding $15.00 are typical in high-intent commercial niches like personal finance, SaaS reviews, and digital marketing.',
      },
      {
        question: 'Can RPM be higher than CPM?',
        answer:
          'Generally CPM is higher than RPM because CPM represents gross advertiser spend before YouTube’s 45% cut. However, if a channel earns substantial revenue from Super Chats, memberships, and brand integrations, total RPM can occasionally surpass pure ad CPM.',
      },
      {
        question: 'Why did my RPM drop in January?',
        answer:
          'Advertisers exhaust their marketing budgets during Q4 holiday shopping (October–December). In January, brands reset budgets, leading to lower bids and industry-wide seasonal RPM dips of 30% to 50%.',
      },
    ],
    disclaimer:
      'Calculation is based purely on the entered values. It does not account for retroactive refunds, invalid traffic deductions, or tax withholdings made by Google AdSense.',
    relatedCalculatorIds: [
      'youtube-money-calculator',
      'youtube-cpm-calculator',
      'ad-revenue-calculator',
    ],
  },
  {
    id: 'youtube-cpm-calculator',
    slug: '/youtube-cpm-calculator',
    name: 'YouTube CPM Calculator',
    shortDescription: 'Calculate advertiser cost per 1,000 ad impressions.',
    category: 'youtube',
    categoryName: 'YouTube',
    iconName: 'BarChart3',
    metaTitle: 'YouTube CPM Calculator: Cost Per Mille Metrics | CREXA',
    metaDescription:
      'Calculate advertiser YouTube CPM (Cost Per 1,000 Impressions). Understand ad inventory value, campaign costs, and impression efficiency with CREXA.',
    primaryKeyword: 'YouTube CPM calculator',
    formulaSummary: 'CPM = (Total Ad Cost ÷ Total Ad Impressions) × 1,000',
    formulaExplanation:
      'CPM stands for Cost Per Mille (cost per thousand). It indicates the cost an advertiser incurs for every 1,000 commercial ad impressions served on your videos. Divide the campaign cost by impressions and multiply by 1,000.',
    workedExample: {
      scenario: 'An advertiser pays $1,200 for a campaign generating 150,000 video ad impressions.',
      inputs: {
        'Total Ad Spend': '$1,200.00',
        'Ad Impressions': '150,000',
      },
      calculation: '($1,200.00 ÷ 150,000) × 1,000 = $0.008 × 1,000',
      result: '$8.00 CPM ($0.008 per impression)',
    },
    howToUseSteps: [
      'Enter the total ad expenditure or advertiser invoice amount.',
      'Enter the total verified ad impressions served.',
      'View the calculated CPM and cost per individual impression.',
      'Use this figure to benchmark your media buys or channel inventory pricing.',
    ],
    educationalContent: {
      title: 'How CPM Powers YouTube Ad Auctions',
      paragraphs: [
        'YouTube ad placements are traded via real-time auctions through Google Ads. Advertisers bid against competitors for target demographic slots, video keywords, and viewer interests.',
        'A high CPM indicates high advertiser competition for your audience. For instance, mortgage brokers and insurance companies are willing to pay $30+ CPMs because a single closed client generates thousands of dollars in profit.',
        'Creators only receive 55% of the playback CPM, while YouTube keeps 45%. Furthermore, playback CPM only counts impressions where ads were delivered, not total video view counts.',
      ],
    },
    faqs: [
      {
        question: 'What is playback-based CPM vs. regular CPM?',
        answer:
          'Playback-based CPM is the cost advertisers pay for 1,000 monetized playbacks where at least one ad is shown. Standard CPM counts every individual ad impression (a video with 2 ads served during one playback counts as 2 impressions).',
      },
      {
        question: 'How do I convert CPM to estimated creator earnings?',
        answer:
          'Multiply CPM by 0.55 (the creator’s 55% share), and multiply by your monetized view percentage (usually 50% to 70% of total views depending on region and ad inventory).',
      },
      {
        question: 'Why is YouTube CPM higher in some countries?',
        answer:
          'Advertisers bid higher in markets with greater consumer purchasing power, such as the United States, United Kingdom, Germany, Canada, and Australia.',
      },
    ],
    disclaimer:
      'CPM metrics reflect gross advertising spend before platform revenue deductions and agency commissions. Real ad auction rates vary dynamically.',
    relatedCalculatorIds: [
      'youtube-rpm-calculator',
      'youtube-money-calculator',
      'ad-revenue-calculator',
    ],
  },
  {
    id: 'tiktok-money-calculator',
    slug: '/tiktok-money-calculator',
    name: 'TikTok Money Calculator',
    shortDescription: 'Estimate creator rewards revenue from video views.',
    category: 'tiktok',
    categoryName: 'TikTok',
    iconName: 'Smartphone',
    priority: true,
    metaTitle: 'TikTok Money Calculator: Estimate Creator Earnings | CREXA',
    metaDescription:
      'Calculate estimated TikTok earnings with CREXA. Enter views and RPM to model Creator Rewards payouts, qualified views, and monthly projections.',
    primaryKeyword: 'TikTok money calculator',
    formulaSummary: 'Estimated Earnings = (Qualified Views ÷ 1,000) × RPM',
    formulaExplanation:
      'TikTok payouts via the Creator Rewards Program depend on qualified views (views from eligible regions, on 1+ minute videos, watched for at least 5 seconds). Earnings equal qualified views divided by 1,000 multiplied by your creator rewards RPM.',
    workedExample: {
      scenario: 'A creator gets 850,000 qualified views on 1-minute videos with an RPM of $0.65.',
      inputs: {
        'Qualified Views': '850,000',
        'Estimated RPM': '$0.65',
      },
      calculation: '(850,000 ÷ 1,000) × $0.65 = 850 × $0.65',
      result: '$552.50 estimated payout ($0.00065/view)',
    },
    howToUseSteps: [
      'Enter your expected or actual TikTok video views.',
      'Specify your estimated RPM (Creator Rewards Program typically averages $0.30–$1.20 per 1,000 qualified views; legacy Creator Fund was $0.02–$0.04).',
      'Calculate your estimated video payout, monthly pace, and per-view return.',
      'Compare short-form returns against long-form YouTube revenue.',
    ],
    educationalContent: {
      title: 'How TikTok Monetization Really Works',
      paragraphs: [
        'TikTok has transitioned from the original Creator Fund into the Creator Rewards Program. Under the new model, videos must be at least 1 minute in length to be eligible for rewards, incentivizing richer storytelling and deeper audience retention.',
        'Not all views are qualified. Views must occur in the For You feed, come from eligible countries, and the viewer must watch for at least 5 seconds without spam behavior. Typical qualification rates range between 40% and 70% of total view counts.',
        'Because platform payouts remain modest compared to long-form video, top TikTok creators use views primarily as top-of-funnel reach to secure brand sponsorships, sell merch, and drive traffic to newsletter subscriptions.',
      ],
    },
    faqs: [
      {
        question: 'How much does TikTok pay for 1 million views?',
        answer:
          'On the Creator Rewards Program (1+ minute videos), 1 million qualified views typically earn between $300 and $1,200 ($0.30 to $1.20 RPM). On the legacy Creator Fund, 1 million views paid only $20 to $40.',
      },
      {
        question: 'What are qualified views on TikTok?',
        answer:
          'Qualified views are views of at least 5 seconds from the For You feed on videos longer than 60 seconds, generated by unique organic viewers in monetized countries.',
      },
      {
        question: 'Does CREXA connect to my TikTok account?',
        answer:
          'No. CREXA is 100% private and runs all formulas locally in your browser. We never ask for your account credentials or analytics access.',
      },
    ],
    disclaimer:
      'TikTok earnings are user-entered estimates. TikTok payouts vary widely based on video completion rate, audience geographic distribution, and internal program eligibility terms.',
    relatedCalculatorIds: [
      'tiktok-engagement-calculator',
      'sponsorship-calculator',
      'youtube-money-calculator',
    ],
  },
  {
    id: 'tiktok-engagement-calculator',
    slug: '/tiktok-engagement-calculator',
    name: 'TikTok Engagement Rate Calculator',
    shortDescription: 'Calculate engagement rate using views or followers as denominator.',
    category: 'tiktok',
    categoryName: 'TikTok',
    iconName: 'Activity',
    metaTitle: 'TikTok Engagement Rate Calculator (Views & Followers) | CREXA',
    metaDescription:
      'Calculate your TikTok engagement rate with precision. Compare engagement calculated by total views or followers and check industry benchmarks.',
    primaryKeyword: 'TikTok engagement rate calculator',
    formulaSummary: 'Engagement Rate = ((Likes + Comments + Shares + Saves) ÷ Denominator) × 100',
    formulaExplanation:
      'Engagement rate measures the ratio of audience interactions (likes, comments, shares, saves) relative to your audience base. You can choose whether to benchmark against total video views (recommended for TikTok) or total account followers.',
    workedExample: {
      scenario: 'A video gets 25,000 views, 2,200 likes, 110 comments, 85 shares, and 145 saves.',
      inputs: {
        'Total Views': '25,000',
        Likes: '2,200',
        Comments: '110',
        Shares: '85',
        Saves: '145',
      },
      calculation: '((2,200 + 110 + 85 + 145) ÷ 25,000) × 100 = (2,540 ÷ 25,000) × 100',
      result: '10.16% engagement rate by views',
    },
    howToUseSteps: [
      'Select your calculation basis: By Views (best for individual videos) or By Followers (best for account profile).',
      'Input the like, comment, and share counts from your TikTok analytics.',
      'Optionally enter saves/favorites.',
      'Input the total view count or follower count as the denominator.',
      'Check your overall engagement rate and breakdown ratios.',
    ],
    educationalContent: {
      title: 'Views vs. Followers: Which Denominator Matters on TikTok?',
      paragraphs: [
        'Unlike legacy social networks where follower feeds dictate reach, TikTok is an algorithmic discovery engine driven by the "For You" page (FYP). A video can easily amass 500,000 views on an account with just 2,000 followers.',
        'Consequently, calculating engagement per video view provides a much more meaningful indicator of how strongly your video resonated with the viewers who actually saw it.',
        'When pitching brand sponsors, highlight both metrics: your view-based engagement proves your creative hooks perform, while follower-based engagement demonstrates baseline community loyalty.',
      ],
    },
    faqs: [
      {
        question: 'What is a good TikTok engagement rate?',
        answer:
          'When calculated by views, 4% to 9% is average, while 10%+ is high performing. When calculated by followers, rates vary widely: micro-creators often see 15%+ while macro-creators average 4% to 8%.',
      },
      {
        question: 'Why do shares and saves matter more than likes?',
        answer:
          'TikTok algorithms treat shares and saves as strong intent signals. A share introduces new users to the app, while a save indicates high replay or reference value, triggering wider FYP distribution.',
      },
    ],
    disclaimer:
      'Calculation uses user-provided metrics. Official TikTok analytics may categorize re-watches and loop metrics differently.',
    relatedCalculatorIds: [
      'tiktok-money-calculator',
      'instagram-engagement-calculator',
      'sponsorship-calculator',
    ],
  },
  {
    id: 'instagram-engagement-calculator',
    slug: '/instagram-engagement-calculator',
    name: 'Instagram Engagement Rate Calculator',
    shortDescription: 'Calculate engagement rate from interactions and followers.',
    category: 'instagram',
    categoryName: 'Instagram',
    iconName: 'Instagram',
    priority: true,
    metaTitle: 'Instagram Engagement Rate Calculator & Benchmarks | CREXA',
    metaDescription:
      'Calculate your Instagram engagement percentage quickly. Enter likes, comments, and followers to assess your creator influence and benchmark standing.',
    primaryKeyword: 'Instagram engagement rate calculator',
    formulaSummary: 'Engagement Rate = ((Likes + Comments) ÷ Followers) × 100',
    formulaExplanation:
      'The industry-standard Instagram engagement rate formula calculates total post interactions (likes plus comments) as a percentage of your total follower count. This metric is the primary benchmark used by influencer agencies.',
    workedExample: {
      scenario: 'An Instagram creator with 42,000 followers receives 1,450 likes and 95 comments on a post.',
      inputs: {
        Followers: '42,000',
        Likes: '1,450',
        Comments: '95',
      },
      calculation: '((1,450 + 95) ÷ 42,000) × 100 = (1,545 ÷ 42,000) × 100',
      result: '3.68% engagement rate (Healthy / Good tier)',
    },
    howToUseSteps: [
      'Enter the average number of likes across your recent 6–12 posts.',
      'Enter the average number of comments across those same posts.',
      'Input your current total follower count.',
      'Review your calculated rate and see where it falls against global industry benchmarks.',
    ],
    educationalContent: {
      title: 'How Influencer Marketers Evaluate Instagram Engagement',
      paragraphs: [
        'Follower count alone is no longer enough to land high-paying brand sponsorships. Brands have realized that bought followers or dead accounts yield zero return. Instead, agencies examine your engagement rate to verify genuine human interest.',
        'As accounts grow larger, engagement rates naturally taper down. A nano-influencer with 5,000 followers might comfortably maintain a 6.5% rate, whereas a celebrity account with 2 million followers often hovers around 1.2%.',
        'To elevate your rate, write discussion-provoking captions, reply to comments within the first 60 minutes of posting, and publish interactive Instagram Stories and polls.',
      ],
    },
    faqs: [
      {
        question: 'What is a good Instagram engagement rate in 2026?',
        answer:
          'Below 1.5% is considered low; 1.5% to 3.5% is average/healthy; 3.5% to 6% is high; and above 6% is exceptional. Nano-influencers typically benchmark higher than macro-influencers.',
      },
      {
        question: 'Should I calculate engagement on single posts or an average?',
        answer:
          'For your media kit, always calculate the average across your last 10 to 12 regular feed posts (excluding obvious viral outliers) to give brands a representative baseline.',
      },
    ],
    disclaimer:
      'This calculation is an estimate based on user-provided counts. It does not inspect direct message conversations, link sticker clicks, or third-party bot auditing tools.',
    relatedCalculatorIds: [
      'sponsorship-calculator',
      'tiktok-engagement-calculator',
      'affiliate-commission-calculator',
    ],
  },
  {
    id: 'affiliate-commission-calculator',
    slug: '/affiliate-commission-calculator',
    name: 'Affiliate Commission Calculator',
    shortDescription: 'Calculate commission earnings from sales, order value, and rates.',
    category: 'affiliate',
    categoryName: 'Affiliate Marketing',
    iconName: 'ShoppingBag',
    priority: true,
    metaTitle: 'Affiliate Commission Calculator: Earnings & AOV | CREXA',
    metaDescription:
      'Calculate affiliate marketing earnings from orders, average order value, and commission rates. Plan profitable affiliate campaigns with CREXA.',
    primaryKeyword: 'affiliate commission calculator',
    formulaSummary: 'Commission = Sales Count × Average Order Value × (Commission Rate ÷ 100)',
    formulaExplanation:
      'Affiliate commission equals the total gross merchandise volume (sales count multiplied by average order value) multiplied by your agreed commission percentage.',
    workedExample: {
      scenario: 'You generate 65 product sales with an average order value of $85.00 at an 18% commission rate.',
      inputs: {
        'Number of Sales': '65',
        'Average Order Value': '$85.00',
        'Commission Rate': '18%',
      },
      calculation: '65 × $85.00 = $5,525.00 gross sales. $5,525.00 × 0.18',
      result: '$994.50 commission earned ($15.30 per sale)',
    },
    howToUseSteps: [
      'Enter the number of completed sales generated via your affiliate links.',
      'Enter the average order value (AOV) of the merchant or product.',
      'Enter the agreed affiliate commission percentage.',
      'Review your gross sales, total net commission earned, and average payout per transaction.',
    ],
    educationalContent: {
      title: 'Maximizing Earnings in Affiliate Marketing',
      paragraphs: [
        'Affiliate marketing is among the most scalable creator revenue streams because it disconnects earnings from ad views. A video with only 2,000 views can generate $3,000+ in affiliate commissions if targeted to high-intent buyers seeking software or camera equipment.',
        'Focus on two critical levers: Average Order Value (AOV) and conversion quality. While Amazon Associates offers broad appeal, their 1%–4% commissions require massive volume. In contrast, SaaS affiliate programs paying 25%–40% recurring monthly commissions build predictable MRR (Monthly Recurring Revenue).',
        'Always comply with FTC disclosure guidelines by transparently stating your affiliate relationships to maintain audience trust.',
      ],
    },
    faqs: [
      {
        question: 'What is a typical affiliate commission rate?',
        answer:
          'Rates vary by industry: Amazon physical products range from 1% to 10%; fashion and retail typically pay 5% to 15%; online courses and digital downloads pay 20% to 50%; and SaaS software pays 20% to 40% (often recurring).',
      },
      {
        question: 'Does this calculator handle recurring monthly commissions?',
        answer:
          'This tool models single-period earnings. For monthly recurring affiliate programs, enter your active paying customer base as the sales count and their monthly subscription fee as the order value.',
      },
    ],
    disclaimer:
      'Calculations do not account for merchant chargebacks, returned items, delayed payment hold periods, or payment processor fees.',
    relatedCalculatorIds: [
      'profit-margin-calculator',
      'video-roi-calculator',
      'ad-revenue-calculator',
    ],
  },
  {
    id: 'profit-margin-calculator',
    slug: '/profit-margin-calculator',
    name: 'Profit Margin Calculator',
    shortDescription: 'Calculate revenue, cost, profit, margin %, and markup %.',
    category: 'business',
    categoryName: 'Business',
    iconName: 'Percent',
    priority: true,
    metaTitle: 'Profit Margin Calculator: Gross Margin & Markup | CREXA',
    metaDescription:
      'Calculate gross profit, profit margin percentage, and markup percentage from revenue and costs. Essential financial tool for online businesses on CREXA.',
    primaryKeyword: 'profit margin calculator',
    formulaSummary: 'Profit Margin (%) = ((Revenue - Cost) ÷ Revenue) × 100',
    formulaExplanation:
      'Gross profit is total revenue minus total expenses. The profit margin percentage represents the proportion of each dollar of revenue retained as profit. Markup percentage represents the profit expressed as a percentage of the original cost.',
    workedExample: {
      scenario: 'You sell a digital template pack for $150.00 with $45.00 in total direct delivery and hosting costs.',
      inputs: {
        Revenue: '$150.00',
        Cost: '$45.00',
      },
      calculation: 'Gross Profit = $150 - $45 = $105. Margin = ($105 ÷ $150) × 100',
      result: '$105.00 profit | 70.00% profit margin | 233.33% markup',
    },
    howToUseSteps: [
      'Enter total gross revenue or selling price.',
      'Enter total costs (cost of goods sold, software tools, production, contractor costs).',
      'Instantly see net gross profit, profit margin percentage, and markup percentage.',
      'Use the tool to test different pricing tiers and protect your profit cushions.',
    ],
    educationalContent: {
      title: 'The Critical Difference Between Margin and Markup',
      paragraphs: [
        'Confusing profit margin with markup is one of the most common mistakes made by new entrepreneurs. Markup is the percentage added to your cost to reach your selling price. Margin is the percentage of the selling price that you keep as profit.',
        'A 50% markup on a $100 item results in a $150 selling price and a $50 profit. However, your profit margin on that $150 sale is 33.3% ($50 ÷ $150), not 50%.',
        'Digital creator businesses typically enjoy healthy gross margins (60% to 90%), but must remain disciplined regarding software subscriptions, contractor fees, and payment gateway cuts (Stripe/PayPal 2.9% + $0.30).',
      ],
    },
    faqs: [
      {
        question: 'What is a healthy profit margin for an online business?',
        answer:
          'For physical ecommerce and drop shipping, 15% to 30% net margin is common. For digital products, software, and creator services, healthy net profit margins typically range between 50% and 80%.',
      },
      {
        question: 'How does this calculator handle zero revenue or negative profit?',
        answer:
          'If revenue is zero or negative, the calculator safely returns 0% margin to prevent mathematical division-by-zero errors. If cost exceeds revenue, the calculator clearly displays the negative net loss.',
      },
    ],
    disclaimer:
      'This calculation represents gross margin based solely on the entered numbers and does not constitute formal accounting, tax, or legal financial advice.',
    relatedCalculatorIds: [
      'affiliate-commission-calculator',
      'video-roi-calculator',
      'sponsorship-calculator',
    ],
  },
  {
    id: 'ad-revenue-calculator',
    slug: '/ad-revenue-calculator',
    name: 'Ad Revenue Calculator',
    shortDescription: 'Estimate website and blog ad revenue using pageviews and RPM.',
    category: 'business',
    categoryName: 'Business',
    iconName: 'Layout',
    metaTitle: 'Ad Revenue Calculator: Website Pageviews & RPM | CREXA',
    metaDescription:
      'Estimate ad revenue from website pageviews or ad impressions with CREXA. Model daily, monthly, and annual digital advertising income.',
    primaryKeyword: 'ad revenue calculator',
    formulaSummary: 'Estimated Revenue = (Volume ÷ 1,000) × RPM',
    formulaExplanation:
      'Ad revenue equals your total impression or pageview volume divided by 1,000 multiplied by your average page RPM or ad unit CPM.',
    workedExample: {
      scenario: 'A content website generates 350,000 monthly pageviews with an RPM of $14.00 on Mediavine.',
      inputs: {
        'Monthly Pageviews': '350,000',
        'Page RPM': '$14.00',
      },
      calculation: '(350,000 ÷ 1,000) × $14.00 = 350 × $14.00',
      result: '$4,900.00 monthly ad revenue ($58,800.00/year)',
    },
    howToUseSteps: [
      'Enter your monthly pageviews or total ad impressions.',
      'Input your network RPM (e.g. Google AdSense: $2–$8; Raptive/Mediavine: $12–$35+).',
      'View your projected daily, monthly, and yearly digital ad income.',
      'Model what happens to income as your search traffic expands.',
    ],
    educationalContent: {
      title: 'Pageviews vs. Ad Impressions: Key Advertising Distinctions',
      paragraphs: [
        'Pageviews count how many individual web pages were loaded by visitors. Ad impressions count how many individual ad banners or video units were actually rendered on those pages.',
        'A single long-form blog post might serve 4 display ads, meaning 100,000 pageviews could generate 400,000 ad impressions. Premium ad management networks (like Mediavine and Raptive) optimize lazy-loading and ad density to maximize your effective Page RPM.',
        'Key factors that boost website ad revenue include visitor location (US visitors pay 4x–8x more than traffic from low-tier ad markets), session duration, and viewability scores above 70%.',
      ],
    },
    faqs: [
      {
        question: 'How much do websites make per 1,000 visitors?',
        answer:
          'On Google AdSense, typical websites make $2 to $7 per 1,000 visitors. On premium networks like Mediavine or Raptive, websites in finance, food, travel, and lifestyle commonly earn $15 to $40+ per 1,000 sessions.',
      },
      {
        question: 'What is the minimum traffic needed for premium ad networks?',
        answer:
          'Most top-tier networks require established traffic thresholds: Mediavine requires 50,000 monthly sessions, Raptive requires 100,000 monthly pageviews, and Monumetric starts at 10,000 monthly pageviews.',
      },
    ],
    disclaimer:
      'Ad rates are estimates. Real website ad earnings depend on ad viewability, layout density, ad-blocker usage, and seasonal brand spending cycles.',
    relatedCalculatorIds: [
      'youtube-money-calculator',
      'profit-margin-calculator',
      'subscriber-growth-calculator',
    ],
  },
  {
    id: 'subscriber-growth-calculator',
    slug: '/subscriber-growth-calculator',
    name: 'Subscriber Growth Calculator',
    shortDescription: 'Project future subscriber counts using growth rate and churn.',
    category: 'social-media',
    categoryName: 'Social Media',
    iconName: 'TrendingUp',
    priority: true,
    metaTitle: 'Subscriber Growth Calculator: Forecasting & Churn | CREXA',
    metaDescription:
      'Project your channel or newsletter subscriber growth with CREXA. Enter current audience, new gains, and churn to model future milestones accurately.',
    primaryKeyword: 'subscriber growth calculator',
    formulaSummary: 'Projected Subscribers = Current Subscribers + (Net Monthly Growth × Months)',
    formulaExplanation:
      'Net monthly growth equals new subscribers gained minus lost subscribers (churn). Multiply net monthly growth by your forecast duration (in months) and add to your current subscriber base.',
    workedExample: {
      scenario: 'A channel with 15,000 subscribers gains 1,800/mo and loses 300/mo, projected over 12 months.',
      inputs: {
        'Current Subscribers': '15,000',
        'New Subscribers / Month': '1,800',
        'Lost Subscribers / Month': '300',
        'Forecast Duration': '12 months',
      },
      calculation: 'Net Growth = 1,800 - 300 = 1,500/mo. 15,000 + (1,500 × 12) = 15,000 + 18,000',
      result: '33,000 projected subscribers (10.00% monthly growth rate)',
    },
    howToUseSteps: [
      'Enter your current subscriber, follower, or newsletter member count.',
      'Input the number of new subscribers you gain in an average month.',
      'Input the number of unsubscribers or churned members per month.',
      'Choose your forecast timeframe (between 1 and 60 months).',
      'Review your net monthly additions, growth rate percentage, and projected final tally.',
    ],
    educationalContent: {
      title: 'Managing the Growth Funnel: The Reality of Churn',
      paragraphs: [
        'Many creators look only at gross subscriber additions, leading to unrealistic growth projections. In reality, audience turnover is constant: YouTube users delete inactive Google accounts, newsletter readers change jobs, and viewer tastes evolve.',
        'Tracking net growth rather than gross additions keeps your strategic goals grounded in reality. If you gain 1,000 subscribers but lose 800, your effective growth is only 200.',
        'The best defense against churn is delivering on the core promise that prompted viewers to subscribe in the first place, avoiding sudden radical format pivots that alienate your existing core audience.',
      ],
    },
    faqs: [
      {
        question: 'What is a typical subscriber churn rate?',
        answer:
          'On YouTube, creators typically lose 10% to 25% of their gross new subscribers every month. In email newsletters, a healthy monthly churn rate is between 1% and 3% of the total list.',
      },
      {
        question: 'Does this calculator support compound growth rates?',
        answer:
          'This tool uses linear net monthly growth based on your consistent monthly baseline. For sudden viral spikes, recalculate periodically with updated monthly averages.',
      },
    ],
    disclaimer:
      'Projections are linear mathematical models based on constant user inputs. Real-world audience growth varies with viral hits, algorithm updates, and upload frequency.',
    relatedCalculatorIds: [
      'youtube-money-calculator',
      'ad-revenue-calculator',
      'video-roi-calculator',
    ],
  },
  {
    id: 'video-roi-calculator',
    slug: '/video-roi-calculator',
    name: 'Video ROI Calculator',
    shortDescription: 'Calculate return on investment for video production and promotion.',
    category: 'business',
    categoryName: 'Business',
    iconName: 'PlayCircle',
    metaTitle: 'Video ROI Calculator: Return on Production Spend | CREXA',
    metaDescription:
      'Measure return on investment (ROI) for video productions with CREXA. Factor in production costs, promo spend, and attributable revenue cleanly.',
    primaryKeyword: 'video ROI calculator',
    formulaSummary: 'ROI (%) = ((Attributable Revenue - Total Investment) ÷ Total Investment) × 100',
    formulaExplanation:
      'Total investment equals production costs (editing, gear, actors, studio rental) plus promotional ad spend. Net return is attributable revenue minus total investment. ROI percentage expresses that net return relative to your total outlay.',
    workedExample: {
      scenario: 'You spend $800 on editing/thumbnails and $400 on promotional ads. The video generates $2,600 in ad revenue and course sales.',
      inputs: {
        'Production Cost': '$800.00',
        'Promotion Spend': '$400.00',
        'Attributable Revenue': '$2,600.00',
      },
      calculation: 'Total Cost = $800 + $400 = $1,200. Net Return = $2,600 - $1,200 = $1,400. ROI = ($1,400 ÷ $1,200) × 100',
      result: '$1,400.00 net return | 116.67% ROI (Profitable)',
    },
    howToUseSteps: [
      'Enter your video production expenses (editor fees, thumbnail design, voiceover, equipment depreciation).',
      'Enter any paid promotional spend (YouTube discovery ads, Meta ads, influencer shoutouts).',
      'Enter all attributable income (AdSense earnings, sponsorship fee, affiliate sales, merchandise conversions).',
      'Instantly see your total capital invested, net profit, and ROI percentage.',
    ],
    educationalContent: {
      title: 'Treating Content Creation as a High-Return Investment Portfolio',
      paragraphs: [
        'Top content creators do not view video production as an expense; they treat each upload as a revenue-generating digital asset with a multi-year shelf life. An evergreen video can continue producing returns for 5+ years through search traffic.',
        'Tracking ROI allows you to identify which video formats justify higher production budgets. If high-effort studio documentaries yield a 20% ROI while simple screen-recorded tutorials yield a 300% ROI, your production calendar should adjust accordingly.',
        'Be sure to attribute all revenue sources to the video, including affiliate links in the description, email list conversions, and sponsor integrations.',
      ],
    },
    faqs: [
      {
        question: 'What is considered a good ROI on a video?',
        answer:
          'Any positive ROI (>0%) means the video was profitable. An ROI of 100% means you doubled your money. In creator businesses, successful evergreen content regularly achieves 200% to 500%+ lifetime ROI.',
      },
      {
        question: 'How does the calculator handle zero investment?',
        answer:
          'If total investment is $0 (e.g. you shot and edited the video yourself with zero out-of-pocket costs), the calculator safely returns 0% ROI and displays your total revenue as 100% net return without division errors.',
      },
    ],
    disclaimer:
      'Attribution calculations rely on creator-reported revenue. Long-tail revenue over future years is not captured unless manually updated.',
    relatedCalculatorIds: [
      'profit-margin-calculator',
      'sponsorship-calculator',
      'youtube-money-calculator',
    ],
  },
  {
    id: 'sponsorship-calculator',
    slug: '/sponsorship-calculator',
    name: 'Sponsorship Calculator',
    shortDescription: 'Estimate brand deal rates based on views, deliverables, and rights.',
    category: 'business',
    categoryName: 'Business',
    iconName: 'Award',
    priority: true,
    metaTitle: 'Sponsorship Calculator: Brand Deal Rate Estimator | CREXA',
    metaDescription:
      'Estimate professional sponsorship quotes for brand deals with CREXA. Configure view benchmarks, deliverable types, exclusivity, and ad rights.',
    primaryKeyword: 'sponsorship calculator',
    formulaSummary: 'Quote = (Views ÷ 1,000) × Base CPM × Deliverable × Exclusivity × Rights',
    formulaExplanation:
      'A professional sponsorship quote begins with your baseline CPM for expected views, then applies industry standard multipliers for deliverable format (dedicated vs. integrated), category exclusivity clauses, and paid advertising usage rights.',
    workedExample: {
      scenario: 'A creator expecting 40,000 views quotes a 60-second integrated sponsorship with a $25 base CPM and 30-day category exclusivity (1.25x multiplier).',
      inputs: {
        'Estimated Views': '40,000',
        'Base CPM': '$25.00',
        'Deliverable Type': '60-second Integration (1.0x)',
        'Exclusivity Clause': 'Category Exclusivity (1.25x)',
        'Usage Rights': 'Organic Only (1.0x)',
      },
      calculation: '(40,000 ÷ 1,000) × $25.00 = $1,000 base. $1,000 × 1.0 × 1.25 × 1.0',
      result: '$1,250.00 recommended quote ($1,062.50 to $1,562.50 negotiated range)',
    },
    howToUseSteps: [
      'Enter your realistic expected video views (use your recent 30-day median).',
      'Set your base CPM (standard creator sponsorships range between $20 and $40 CPM).',
      'Select your deliverable format (e.g., 30s integration, 60s integration, dedicated video, Short/Reel).',
      'Adjust multipliers for category exclusivity clauses and paid ad usage rights/whitelisting.',
      'Review your recommended quote alongside a healthy negotiation range (low to high).',
    ],
    educationalContent: {
      title: 'How to Price Brand Sponsorships Like an Agency',
      paragraphs: [
        'Novice creators often undercharge brands by quoting purely on views. However, view count is only one component of a commercial contract. Brands also buy production labor, creative endorsement trust, and intellectual property rights.',
        'Never give away exclusivity or usage rights for free. If a sponsor demands that you do not work with any other VPN, software, or beverage company for 60 days, they are restricting your future income and must pay a 20%–50% premium.',
        'Similarly, if a brand wants to "whitelist" your video or run your likeness in paid Facebook/TikTok ads, they are extracting additional commercial value and should pay an extra 30%–50% usage fee.',
      ],
    },
    faqs: [
      {
        question: 'What is standard CPM for YouTube brand sponsorships?',
        answer:
          'Typical integrated sponsorship CPMs range between $20 and $35. High-intent niches like B2B SaaS, fintech, and cybersecurity regularly command $45 to $80+ CPMs.',
      },
      {
        question: 'Should I quote a fixed rate or view-based rate?',
        answer:
          'Always quote a flat fee based on your median historical views rather than a variable payout. This protects your revenue if algorithm distribution fluctuates and gives brands budget predictability.',
      },
      {
        question: 'Is this quote guaranteed?',
        answer:
          'No. This calculator produces a structured pricing framework. Final contractual compensation depends on your negotiation leverage, niche scarcity, and client marketing budget.',
      },
    ],
    disclaimer:
      'Results are suggested pricing benchmarks. The tool cannot guarantee market rates or contract agreements with advertisers.',
    relatedCalculatorIds: [
      'video-roi-calculator',
      'youtube-money-calculator',
      'instagram-engagement-calculator',
    ],
  },
];

export const CALCULATORS_BY_ID = new Map(CALCULATORS.map((c) => [c.id, c]));
export const CALCULATORS_BY_SLUG = new Map(CALCULATORS.map((c) => [c.slug, c]));
