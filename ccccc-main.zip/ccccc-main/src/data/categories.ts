import { CategoryDefinition } from '../types';

export const CATEGORIES: CategoryDefinition[] = [
  {
    id: 'youtube',
    slug: '/youtube',
    name: 'YouTube',
    tagline: 'Revenue, RPM, and CPM calculators for video creators',
    description:
      'Accurately estimate your YouTube ad revenue, calculate your true RPM (Revenue Per Mille), and understand advertiser CPM metrics with precision.',
    iconName: 'Youtube',
    seoTitle: 'YouTube Money, RPM & CPM Calculators | CREXA',
    seoDescription:
      'Free YouTube calculator suite for video creators. Estimate ad earnings, calculate RPM per 1,000 views, and analyze advertiser CPM metrics.',
    calculatorIds: [
      'youtube-money-calculator',
      'youtube-rpm-calculator',
      'youtube-cpm-calculator',
      'video-roi-calculator',
      'sponsorship-calculator',
    ],
    overview: [
      'YouTube remains one of the highest-paying digital video platforms, but estimating creator income requires understanding the distinct mechanics of ad impressions, playback RPM, and advertiser CPM bids.',
      'CREXA tools calculate both gross ad spend and net creator payouts, accounting for the standard 55% YouTube revenue share split on long-form video content.',
    ],
    keyFactors: [
      {
        title: 'Geographic Audience',
        description: 'Viewers in tier-1 countries (US, UK, CA, AU) generate significantly higher RPMs due to aggressive advertiser bidding.',
      },
      {
        title: 'Niche & Category',
        description: 'Finance, business, tech, and software niches command higher CPMs ($10–$35+) compared to general entertainment ($2–$6).',
      },
      {
        title: 'Video Length & Mid-rolls',
        description: 'Videos over 8 minutes can insert multiple mid-roll ads, increasing monetized playback opportunities per viewer.',
      },
    ],
    faqs: [
      {
        question: 'What is the difference between YouTube RPM and CPM?',
        answer:
          'CPM (Cost Per Mille) is what advertisers pay YouTube for 1,000 ad impressions before the platform fee. RPM (Revenue Per Mille) is the net earnings creators actually pocket per 1,000 total video views after YouTube takes its 45% revenue cut.',
      },
      {
        question: 'How much does YouTube pay for 100,000 views?',
        answer:
          'On average, 100,000 views generate between $150 and $2,000 depending on audience geography, niche, and video length. A tech channel might earn $800 to $1,500, while a gaming vlog might earn $200 to $400.',
      },
      {
        question: 'How do CREXA YouTube calculators handle YouTube revenue share?',
        answer:
          'Our RPM calculations reflect the creator net share. When converting advertiser CPM to creator earnings, we apply the platform standard 55% creator payout model.',
      },
    ],
  },
  {
    id: 'tiktok',
    slug: '/tiktok',
    name: 'TikTok',
    tagline: 'Earnings and engagement rate benchmarks for short-form creators',
    description:
      'Evaluate your TikTok monetization potential, analyze creator reward rates, and compute authentic engagement rates across views and followers.',
    iconName: 'Smartphone',
    seoTitle: 'TikTok Money & Engagement Rate Calculators | CREXA',
    seoDescription:
      'Estimate TikTok creator payout potential and calculate true engagement rates by views or followers with CREXA short-form analytics.',
    calculatorIds: [
      'tiktok-money-calculator',
      'tiktok-engagement-calculator',
      'sponsorship-calculator',
    ],
    overview: [
      'TikTok creator economics have evolved from the original low-paying Creator Fund into the Creator Rewards Program, which pays significantly more for high-retention 1+ minute videos.',
      'Understanding both view-based engagement and follower-based engagement is essential for landing brand deals and pitching marketing agencies.',
    ],
    keyFactors: [
      {
        title: 'Video Duration',
        description: 'Qualified views under the Creator Rewards Program require videos longer than 60 seconds with watch time above 5 seconds.',
      },
      {
        title: 'Engagement Depth',
        description: 'TikTok algorithms prioritize completion rate, re-watches, and saves over simple passive view counts.',
      },
      {
        title: 'Brand Partnership Value',
        description: 'Top TikTok creators generate 80%+ of their gross income from direct sponsorships rather than platform funds.',
      },
    ],
    faqs: [
      {
        question: 'How does the TikTok Creator Rewards Program calculate pay?',
        answer:
          'TikTok pays based on qualified views (views from the For You feed on videos longer than 1 minute). Typical RPMs range from $0.30 to $1.20 per 1,000 qualified views, though legacy views may yield $0.02 to $0.06.',
      },
      {
        question: 'Should I calculate TikTok engagement by views or followers?',
        answer:
          'Because the TikTok algorithm delivers content predominantly via the For You page rather than a follower feed, calculating engagement per video view provides a much more accurate reflection of content resonance.',
      },
    ],
  },
  {
    id: 'instagram',
    slug: '/instagram',
    name: 'Instagram',
    tagline: 'Engagement metrics and sponsorship rate insights',
    description:
      'Calculate your Instagram engagement percentage, compare against global creator benchmarks, and prepare data-driven media kits for brand sponsors.',
    iconName: 'Instagram',
    seoTitle: 'Instagram Engagement Rate Calculator & Benchmarks | CREXA',
    seoDescription:
      'Calculate your Instagram engagement rate with precision. Compare against industry benchmarks and value your creator profile for brand deals.',
    calculatorIds: [
      'instagram-engagement-calculator',
      'sponsorship-calculator',
      'affiliate-commission-calculator',
    ],
    overview: [
      'Instagram engagement is the foundational metric brand managers inspect when negotiating paid partnerships, influencer contracts, and affiliate activations.',
      'A creator with 20,000 followers and a 4% engagement rate often drives more sales than an account with 100,000 followers and a 0.8% rate.',
    ],
    keyFactors: [
      {
        title: 'Industry Benchmarks',
        description: 'Average Instagram engagement ranges from 1.5% to 3.5%. Accounts above 4% represent top-tier creator resonance.',
      },
      {
        title: 'Comments vs. Likes',
        description: 'Comments indicate active conversational commitment and carry higher algorithmic weight than quick double-taps.',
      },
      {
        title: 'Save & Share Multipliers',
        description: 'Educational carousels and recipe reels frequently achieve viral distribution through bookmark saves and DM shares.',
      },
    ],
    faqs: [
      {
        question: 'What is a good Instagram engagement rate in 2026?',
        answer:
          'For nano-creators (under 10k followers), 4%–7% is standard. For micro-creators (10k–50k), 2.5%–4% is healthy. Accounts above 100k typically average between 1.2% and 2.2%.',
      },
      {
        question: 'Does Instagram pay directly for views?',
        answer:
          'Instagram occasionally runs invite-only bonus programs for Reels in selected regions, but the vast majority of Instagram creator income comes from sponsored posts, affiliate links, and digital product sales.',
      },
    ],
  },
  {
    id: 'affiliate',
    slug: '/affiliate',
    name: 'Affiliate Marketing',
    tagline: 'Commission projections, conversion math, and earnings per sale',
    description:
      'Estimate affiliate income, calculate net commissions from gross merchandise value, and model revenue across varying conversion percentages.',
    iconName: 'ShoppingBag',
    seoTitle: 'Affiliate Commission & Earnings Calculator | CREXA',
    seoDescription:
      'Calculate affiliate marketing commissions, order values, and revenue splits. Plan profitable affiliate campaigns with CREXA.',
    calculatorIds: [
      'affiliate-commission-calculator',
      'profit-margin-calculator',
      'video-roi-calculator',
    ],
    overview: [
      'Affiliate marketing links content recommendation directly to consumer purchases, generating passive revenue streams across blogs, social links, and YouTube descriptions.',
      'Success hinges on three core levers: targeted traffic volume, conversion rate, and commission percentage per completed order.',
    ],
    keyFactors: [
      {
        title: 'Physical vs. Digital Products',
        description: 'Physical ecommerce items (Amazon, Walmart) offer 1%–6% margins, whereas digital courses and SaaS products regularly pay 20%–50% recurring commissions.',
      },
      {
        title: 'Cookie Duration',
        description: 'Programs offering 30 to 90-day cookie windows maximize conversion attribution compared to 24-hour retail windows.',
      },
      {
        title: 'High-Ticket Programs',
        description: 'Promoting products with $500+ average order values enables substantial income even with lower click-through volumes.',
      },
    ],
    faqs: [
      {
        question: 'How is affiliate commission calculated?',
        answer:
          'Gross Revenue = Number of Sales × Average Order Value. Commission Earned = Gross Revenue × (Commission Rate / 100).',
      },
      {
        question: 'What is a normal affiliate conversion rate?',
        answer:
          'Typical link conversion rates range from 1% to 3.5% for warm content audiences (e.g. YouTube review or tutorial viewers), and 0.5% to 1.5% for generic display or banner placements.',
      },
    ],
  },
  {
    id: 'business',
    slug: '/business',
    name: 'Business & Profitability',
    tagline: 'Financial margin analysis, production ROI, and quote generation',
    description:
      'Master the financial health of your online business with profit margin analysis, video production ROI calculations, and professional sponsorship quotes.',
    iconName: 'Briefcase',
    seoTitle: 'Creator Business, Profit Margin & ROI Calculators | CREXA',
    seoDescription:
      'Evaluate business profitability, calculate gross and net margins, measure video production ROI, and price brand deals accurately.',
    calculatorIds: [
      'profit-margin-calculator',
      'video-roi-calculator',
      'sponsorship-calculator',
      'ad-revenue-calculator',
    ],
    overview: [
      'A creator channel is a small digital enterprise. Growing sustainable revenue requires tracking operational expenses, production investments, and gross margins.',
      'CREXA business calculators empower solo entrepreneurs and digital agencies to make data-backed commercial decisions.',
    ],
    keyFactors: [
      {
        title: 'Gross Margin vs. Net Margin',
        description: 'Gross margin measures revenue minus direct production costs; net margin deducts taxes, software, team wages, and overhead.',
      },
      {
        title: 'Campaign ROI',
        description: 'Evaluating customer acquisition cost (CAC) and video production spend ensures content investments return tangible cash flow.',
      },
      {
        title: 'Contract Pricing',
        description: 'Pricing sponsorships must reflect usage rights, exclusivity clauses, and production complexity beyond simple view counts.',
      },
    ],
    faqs: [
      {
        question: 'What is the formula for profit margin?',
        answer:
          'Profit Margin (%) = ((Revenue - Cost) / Revenue) × 100. It reveals what portion of every dollar earned is retained as profit.',
      },
      {
        question: 'How do you calculate return on investment for video production?',
        answer:
          'Video ROI (%) = ((Attributable Revenue - Total Investment) / Total Investment) × 100. A 100% ROI means you doubled your invested capital.',
      },
    ],
  },
  {
    id: 'social-media',
    slug: '/social-media',
    name: 'Social Media & Growth',
    tagline: 'Audience trajectory forecasting and multi-platform reach',
    description:
      'Project subscriber trajectories, model organic growth rates, compare platform engagement formulas, and anticipate future audience milestones.',
    iconName: 'TrendingUp',
    seoTitle: 'Social Media & Subscriber Growth Calculators | CREXA',
    seoDescription:
      'Project subscriber growth, model audience churn, and calculate multi-platform engagement rates with CREXA creator growth tools.',
    calculatorIds: [
      'subscriber-growth-calculator',
      'ad-revenue-calculator',
      'youtube-money-calculator',
      'tiktok-money-calculator',
    ],
    overview: [
      'Sustainable online growth requires tracking not just gross subscriber additions, but net growth after audience churn and retention decay.',
      'Forecasting your audience trajectory lets you plan content release cadences and anticipate milestone monetizations.',
    ],
    keyFactors: [
      {
        title: 'Subscriber Churn',
        description: 'Every channel loses subscribers over time through deleted accounts and changing viewer interests. Net growth is the only metric that matters.',
      },
      {
        title: 'Compound Growth',
        description: 'Algorithmic distribution creates compounding growth inflection points when videos rank in search or hit recommendation engines.',
      },
      {
        title: 'Milestone Planning',
        description: 'Knowing exactly when you will hit 10k, 50k, or 100k subscribers helps you line up brand deals and product launches in advance.',
      },
    ],
    faqs: [
      {
        question: 'How is net subscriber growth calculated?',
        answer:
          'Net Monthly Growth = New Subscribers Gained - Lost Subscribers (Churn). Projected Subscribers = Current Base + (Net Monthly Growth × Months).',
      },
      {
        question: 'How can I reduce subscriber loss?',
        answer:
          'Maintain consistent thematic focus so subscribers get the content they subscribed for, optimize video pacing, and interact consistently in comments and community posts.',
      },
    ],
  },
];

export const CATEGORIES_BY_ID = new Map(CATEGORIES.map((c) => [c.id, c]));
