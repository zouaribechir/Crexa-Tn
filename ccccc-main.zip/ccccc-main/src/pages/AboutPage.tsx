import React from 'react';
import { SeoHead } from '../components/SeoHead';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Link } from '../components/Link';
import { CheckCircle2, Shield, Cpu, Sparkles, Target, ArrowRight } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <>
      <SeoHead
        title="About CREXA: Creator & Business Calculator Platform"
        description="Learn about CREXA's mission to give content creators, influencers, and digital businesses transparent, precision financial calculation tools."
        canonicalPath="/about"
        breadcrumbs={[
          { name: 'Home', path: '/' },
          { name: 'About CREXA', path: '/about' },
        ]}
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        <Breadcrumbs items={[{ label: 'About CREXA' }]} />

        {/* Hero */}
        <div className="border-b border-[#252B33] pb-8 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-[#7C5CFC]">
            Our Mission & Architecture
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#F5F7FA] tracking-tight">
            About CREXA
          </h1>
          <p className="text-base text-[#3CCB8E] font-medium">
            Calculate smarter. Grow faster.
          </p>
          <p className="text-sm sm:text-base text-[#A7B0BC] leading-relaxed">
            CREXA is an independent, global digital calculator platform built specifically for content creators, influencers, affiliate publishers, and small online business operators.
          </p>
        </div>

        {/* Why CREXA exists */}
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-[#F5F7FA]">
            Why We Built CREXA
          </h2>
          <p className="text-sm text-[#A7B0BC] leading-relaxed">
            The creator economy has grown into a multi-billion dollar commercial industry, yet most creators run their channels without access to basic financial modeling tools. When trying to estimate ad revenue, price a brand sponsorship, or calculate campaign ROI, creators are too often met with clunky websites cluttered with pop-up ads, paywalls, or outright misleading formulas.
          </p>
          <p className="text-sm text-[#A7B0BC] leading-relaxed">
            CREXA was engineered to solve this problem by providing clean, fast, mathematically rigorous, and 100% free digital calculators that put creator financial control first.
          </p>
        </section>

        {/* Core Architectural Tenets */}
        <section className="space-y-6">
          <h2 className="text-xl font-bold text-[#F5F7FA]">
            Our Engineering Principles
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-xl border border-[#252B33] bg-[#12161B] space-y-2">
              <div className="flex items-center gap-2 text-sm font-bold text-[#F5F7FA]">
                <Cpu className="w-4 h-4 text-[#7C5CFC]" />
                <span>100% Local Browser Execution</span>
              </div>
              <p className="text-xs text-[#A7B0BC] leading-relaxed">
                All 12 calculation models run locally in your browser. When you type in your views, revenues, or costs, not a single digit is sent to an external server or database.
              </p>
            </div>

            <div className="p-5 rounded-xl border border-[#252B33] bg-[#12161B] space-y-2">
              <div className="flex items-center gap-2 text-sm font-bold text-[#F5F7FA]">
                <Shield className="w-4 h-4 text-[#3CCB8E]" />
                <span>Zero Account Friction</span>
              </div>
              <p className="text-xs text-[#A7B0BC] leading-relaxed">
                No signups, no credit cards, and no login walls. CREXA is a public utility accessible to any creator anywhere in the world on desktop, tablet, or mobile.
              </p>
            </div>

            <div className="p-5 rounded-xl border border-[#252B33] bg-[#12161B] space-y-2">
              <div className="flex items-center gap-2 text-sm font-bold text-[#F5F7FA]">
                <Target className="w-4 h-4 text-[#7C5CFC]" />
                <span>Standardized Creator Metrics</span>
              </div>
              <p className="text-xs text-[#A7B0BC] leading-relaxed">
                We clearly define and explain the difference between confusing metrics—such as YouTube RPM vs. CPM, or TikTok view-based vs. follower-based engagement rates.
              </p>
            </div>

            <div className="p-5 rounded-xl border border-[#252B33] bg-[#12161B] space-y-2">
              <div className="flex items-center gap-2 text-sm font-bold text-[#F5F7FA]">
                <Sparkles className="w-4 h-4 text-[#3CCB8E]" />
                <span>Global Multi-Currency Support</span>
              </div>
              <p className="text-xs text-[#A7B0BC] leading-relaxed">
                Creators operate internationally. Switch between US Dollars, Euros, British Pounds, Canadian Dollars, Australian Dollars, and Tunisian Dinars seamlessly.
              </p>
            </div>
          </div>
        </section>

        {/* Independence Disclaimer */}
        <section className="p-6 rounded-xl border border-[#252B33] bg-[#181D23] space-y-3">
          <h2 className="text-base font-bold text-[#F5F7FA]">
            Platform Independence
          </h2>
          <p className="text-xs text-[#A7B0BC] leading-relaxed">
            CREXA is an independent platform and is not associated, affiliated, authorized, endorsed by, or in any way officially connected with YouTube, Google LLC, TikTok, ByteDance, Instagram, or Meta Platforms, Inc. All platform names and trademarks belong to their respective registered holders.
          </p>
        </section>

        {/* CTA */}
        <div className="text-center pt-4">
          <Link
            href="/calculators"
            className="inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold rounded-xl bg-[#7C5CFC] text-white hover:bg-[#6847F5] shadow-lg transition-all"
          >
            <span>Explore All 12 Calculators</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </>
  );
};
