import React, { useState } from 'react';
import { SeoHead } from '../components/SeoHead';
import { Link } from '../components/Link';
import { CALCULATORS } from '../data/calculators';
import { CATEGORIES } from '../data/categories';
import { CalculatorCard } from '../components/CalculatorCard';
import { SearchModal } from '../components/SearchModal';
import { DynamicIcon } from '../components/DynamicIcon';
import { FaqSection } from '../components/FaqSection';
import {
  Search,
  ArrowRight,
  ShieldCheck,
  Zap,
  Globe2,
  Lock,
  BarChart,
  DollarSign,
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const priorityCalculators = CALCULATORS.filter((c) => c.priority);

  const homeFaqs = [
    {
      question: 'What is CREXA?',
      answer:
        'CREXA is a global digital calculator platform created for content creators, influencers, affiliates, and online businesses. We provide precision mathematical calculators to model revenue, engagement rates, commissions, profitability, and audience growth.',
    },
    {
      question: 'Do I need an account or paid subscription to use CREXA calculators?',
      answer:
        'No. CREXA is 100% free with no registration, no sign-in, and no hidden subscriptions. All calculation formulas run entirely on your device in real-time.',
    },
    {
      question: 'Are my entered financial figures and analytics private?',
      answer:
        'Yes. All calculation math runs locally in your web browser. CREXA never stores, transmits, or tracks your entered numbers, revenues, or views.',
    },
    {
      question: 'How accurate are the revenue and RPM estimates?',
      answer:
        'Our formulas are based on standard platform financial models (such as YouTube’s 55% creator revenue split, TikTok Creator Rewards qualified views, and industry CPM benchmarks). However, because actual payouts depend on seasonality, audience geography, and advertiser bids, all results are illustrative estimates.',
    },
  ];

  return (
    <>
      <SeoHead
        title="CREXA: Creator & Online Business Calculator Platform"
        description="Calculate smarter. Grow faster. Free revenue, engagement, RPM, CPM, and profit calculators for content creators, influencers, and digital businesses."
        canonicalPath="/"
        faqs={homeFaqs}
      />

      <div className="space-y-16 lg:space-y-24 py-8 sm:py-12">
        {/* HERO SECTION */}
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#252B33] bg-[#12161B] text-xs font-semibold text-[#7C5CFC]">
            <span className="w-2 h-2 rounded-full bg-[#3CCB8E] animate-pulse" />
            <span>The Global Creator Economics Suite</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#F5F7FA] leading-[1.15]">
            Calculate smarter. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#7C5CFC] via-[#A892FE] to-[#3CCB8E]">
              Grow faster.
            </span>
          </h1>

          <p className="text-base sm:text-lg text-[#A7B0BC] max-w-2xl mx-auto leading-relaxed">
            CREXA provides precision digital calculators for YouTube creators, TikTok influencers, affiliate marketers, and modern online businesses.
          </p>

          {/* Quick Search Bar */}
          <div className="max-w-xl mx-auto pt-2">
            <button
              type="button"
              onClick={() => setIsSearchOpen(true)}
              className="w-full flex items-center justify-between px-4 py-3.5 rounded-xl border border-[#252B33] bg-[#12161B] text-sm text-[#A7B0BC] hover:border-[#7C5CFC] hover:text-[#F5F7FA] shadow-lg transition-all focus:outline-none focus:ring-2 focus:ring-[#7C5CFC]"
            >
              <div className="flex items-center gap-3">
                <Search className="w-4 h-4 text-[#7C5CFC]" />
                <span>Search all 12 calculators (e.g. YouTube money, RPM, profit)...</span>
              </div>
              <kbd className="hidden sm:inline-block px-2 py-0.5 text-xs font-mono bg-[#181D23] rounded border border-[#252B33]">
                ⌘K
              </kbd>
            </button>
          </div>

          {/* Category Quick Tags */}
          <div className="flex flex-wrap justify-center items-center gap-2 pt-2 text-xs">
            <span className="text-[#A7B0BC]">Browse categories:</span>
            {CATEGORIES.map((cat) => (
              <Link
                key={cat.id}
                href={cat.slug}
                className="px-2.5 py-1 rounded-md border border-[#252B33] bg-[#181D23] text-[#A7B0BC] hover:text-[#F5F7FA] hover:border-[#7C5CFC] transition-colors"
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </section>

        {/* PRIORITY CALCULATORS GRID */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#252B33] pb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#7C5CFC]">
                Essential Creator Tools
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#F5F7FA] mt-1">
                Popular Calculators
              </h2>
            </div>
            <Link
              href="/calculators"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#7C5CFC] hover:underline"
            >
              <span>View all 12 calculators</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {priorityCalculators.map((calc) => (
              <CalculatorCard key={calc.id} calculator={calc} />
            ))}
          </div>
        </section>

        {/* PLATFORM VALUE PILLARS */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="rounded-2xl border border-[#252B33] bg-[#12161B] p-8 lg:p-12">
            <div className="max-w-2xl mb-10">
              <span className="text-xs font-bold uppercase tracking-wider text-[#3CCB8E]">
                Why CREXA
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#F5F7FA] tracking-tight mt-1">
                Engineered for Creator Financial Clarity
              </h2>
              <p className="text-xs sm:text-sm text-[#A7B0BC] mt-2 leading-relaxed">
                Most online calculators are clunky, loaded with invasive trackers, or provide misleading numbers. CREXA is built to a higher engineering standard.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-2.5 p-4 rounded-xl bg-[#181D23] border border-[#252B33]">
                <div className="w-9 h-9 rounded-lg bg-[#7C5CFC]/15 text-[#7C5CFC] flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-[#F5F7FA]">100% Client-Side</h3>
                <p className="text-xs text-[#A7B0BC] leading-relaxed">
                  Calculations execute instantly in your browser. Zero server roundtrips, no loading spinners, and zero latency.
                </p>
              </div>

              <div className="space-y-2.5 p-4 rounded-xl bg-[#181D23] border border-[#252B33]">
                <div className="w-9 h-9 rounded-lg bg-[#3CCB8E]/15 text-[#3CCB8E] flex items-center justify-center">
                  <Lock className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-[#F5F7FA]">Privacy First</h3>
                <p className="text-xs text-[#A7B0BC] leading-relaxed">
                  Your channel statistics, revenue goals, and business numbers never leave your browser. Zero personal tracking.
                </p>
              </div>

              <div className="space-y-2.5 p-4 rounded-xl bg-[#181D23] border border-[#252B33]">
                <div className="w-9 h-9 rounded-lg bg-[#7C5CFC]/15 text-[#7C5CFC] flex items-center justify-center">
                  <BarChart className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-[#F5F7FA]">Tested Formulas</h3>
                <p className="text-xs text-[#A7B0BC] leading-relaxed">
                  Every formula is backed by unit tests verifying zero denominators, negative boundaries, and edge cases.
                </p>
              </div>

              <div className="space-y-2.5 p-4 rounded-xl bg-[#181D23] border border-[#252B33]">
                <div className="w-9 h-9 rounded-lg bg-[#3CCB8E]/15 text-[#3CCB8E] flex items-center justify-center">
                  <Globe2 className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-[#F5F7FA]">Multi-Currency</h3>
                <p className="text-xs text-[#A7B0BC] leading-relaxed">
                  Switch effortlessly between USD, EUR, GBP, CAD, AUD, and TND with persistent local preference.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CATEGORY EXPLORATION TILES */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="border-b border-[#252B33] pb-4">
            <span className="text-xs font-bold uppercase tracking-wider text-[#7C5CFC]">
              Explore by Platform
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#F5F7FA] mt-1">
              Category Directory
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {CATEGORIES.map((cat) => (
              <Link
                key={cat.id}
                href={cat.slug}
                className="group flex flex-col justify-between p-6 rounded-xl border border-[#252B33] bg-[#12161B] hover:border-[#7C5CFC] hover:bg-[#181D23]/60 transition-all focus:outline-none focus:ring-2 focus:ring-[#7C5CFC]"
              >
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2.5 rounded-lg bg-[#181D23] text-[#7C5CFC] border border-[#252B33]">
                      <DynamicIcon name={cat.iconName} className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-[#F5F7FA] group-hover:text-[#7C5CFC] transition-colors">
                        {cat.name}
                      </h3>
                      <span className="text-[11px] text-[#A7B0BC]">
                        {cat.calculatorIds.length} calculators
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-[#A7B0BC] leading-relaxed line-clamp-2">
                    {cat.tagline}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#252B33] flex items-center justify-between text-xs font-semibold text-[#7C5CFC]">
                  <span>Explore {cat.name} Hub</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* HOME FAQs */}
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <FaqSection
            faqs={homeFaqs}
            title="CREXA Platform FAQs"
            subtitle="Everything you need to know about using CREXA calculators."
          />
        </section>
      </div>

      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </>
  );
};
