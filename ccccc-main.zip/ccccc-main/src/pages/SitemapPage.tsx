import React from 'react';
import { SeoHead } from '../components/SeoHead';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Link } from '../components/Link';
import { CALCULATORS } from '../data/calculators';
import { CATEGORIES } from '../data/categories';
import { DynamicIcon } from '../components/DynamicIcon';

export const SitemapPage: React.FC = () => {
  return (
    <>
      <SeoHead
        title="HTML Sitemap: Complete Index of Pages & Tools | CREXA"
        description="Complete site index for CREXA. Direct links to all 12 creator calculators, category hubs, legal documentation, and platform resources."
        canonicalPath="/sitemap"
        breadcrumbs={[
          { name: 'Home', path: '/' },
          { name: 'Sitemap', path: '/sitemap' },
        ]}
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
        <Breadcrumbs items={[{ label: 'HTML Sitemap' }]} />

        <div className="border-b border-[#252B33] pb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#7C5CFC]">
            Full Index
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#F5F7FA] tracking-tight mt-1">
            Site Directory & XML Sitemap
          </h1>
          <p className="mt-2 text-sm text-[#A7B0BC] leading-relaxed">
            All indexable canonical URLs on https://crexa.tn. For search engine crawlers, see our machine-readable{' '}
            <a
              href="https://crexa.tn/sitemap.xml"
              className="text-[#7C5CFC] underline hover:text-[#A892FE]"
              target="_blank"
              rel="noopener noreferrer"
            >
              XML Sitemap
            </a>.
          </p>
        </div>

        {/* 1. Main Pages */}
        <section className="space-y-3">
          <h2 className="text-lg font-bold text-[#F5F7FA] border-b border-[#252B33] pb-2">
            Main Pages
          </h2>
          <ul className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
            <li className="p-3 rounded-lg border border-[#252B33] bg-[#12161B]">
              <Link href="/" className="font-semibold text-[#F5F7FA] hover:text-[#7C5CFC] block">
                Homepage (/)
              </Link>
              <span className="text-[11px] text-[#A7B0BC]">Calculate smarter. Grow faster.</span>
            </li>
            <li className="p-3 rounded-lg border border-[#252B33] bg-[#12161B]">
              <Link href="/calculators" className="font-semibold text-[#F5F7FA] hover:text-[#7C5CFC] block">
                Calculators Directory (/calculators)
              </Link>
              <span className="text-[11px] text-[#A7B0BC]">Full catalog of all 12 tools</span>
            </li>
            <li className="p-3 rounded-lg border border-[#252B33] bg-[#12161B]">
              <Link href="/about" className="font-semibold text-[#F5F7FA] hover:text-[#7C5CFC] block">
                About CREXA (/about)
              </Link>
              <span className="text-[11px] text-[#A7B0BC]">Mission, architecture, and principles</span>
            </li>
            <li className="p-3 rounded-lg border border-[#252B33] bg-[#12161B]">
              <Link href="/privacy" className="font-semibold text-[#F5F7FA] hover:text-[#7C5CFC] block">
                Privacy Policy (/privacy)
              </Link>
              <span className="text-[11px] text-[#A7B0BC]">Zero tracking pledge & analytics</span>
            </li>
            <li className="p-3 rounded-lg border border-[#252B33] bg-[#12161B]">
              <Link href="/terms" className="font-semibold text-[#F5F7FA] hover:text-[#7C5CFC] block">
                Terms of Use (/terms)
              </Link>
              <span className="text-[11px] text-[#A7B0BC]">Disclaimers & user responsibilities</span>
            </li>
          </ul>
        </section>

        {/* 2. Category Hubs */}
        <section className="space-y-3">
          <h2 className="text-lg font-bold text-[#F5F7FA] border-b border-[#252B33] pb-2">
            Category Hubs ({CATEGORIES.length})
          </h2>
          <ul className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
            {CATEGORIES.map((cat) => (
              <li key={cat.id} className="p-3 rounded-lg border border-[#252B33] bg-[#12161B]">
                <Link href={cat.slug} className="font-semibold text-[#F5F7FA] hover:text-[#7C5CFC] flex items-center gap-2 mb-1">
                  <DynamicIcon name={cat.iconName} className="w-3.5 h-3.5 text-[#7C5CFC]" />
                  <span>{cat.name} ({cat.slug})</span>
                </Link>
                <span className="text-[11px] text-[#A7B0BC] line-clamp-1">{cat.tagline}</span>
              </li>
            ))}
          </ul>
        </section>

        {/* 3. Individual Calculators */}
        <section className="space-y-3">
          <h2 className="text-lg font-bold text-[#F5F7FA] border-b border-[#252B33] pb-2">
            Individual Calculators ({CALCULATORS.length})
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
            {CALCULATORS.map((calc, idx) => (
              <div key={calc.id} className="p-3 rounded-lg border border-[#252B33] bg-[#12161B] space-y-1">
                <span className="text-[10px] font-mono text-[#7C5CFC] block">
                  #{idx + 1} &middot; {calc.categoryName}
                </span>
                <Link href={calc.slug} className="font-semibold text-[#F5F7FA] hover:text-[#7C5CFC] block">
                  {calc.name}
                </Link>
                <span className="text-[11px] font-mono text-[#A7B0BC] block">
                  https://crexa.tn{calc.slug}
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};
