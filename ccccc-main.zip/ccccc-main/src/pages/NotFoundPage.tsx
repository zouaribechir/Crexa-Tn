import React from 'react';
import { SeoHead } from '../components/SeoHead';
import { Link } from '../components/Link';
import { CALCULATORS } from '../data/calculators';
import { CalculatorCard } from '../components/CalculatorCard';
import { AlertTriangle, Home, Search } from 'lucide-react';

export const NotFoundPage: React.FC = () => {
  const popular = CALCULATORS.slice(0, 3);

  return (
    <>
      <SeoHead
        title="Page Not Found (404) | CREXA"
        description="The requested page could not be found. Explore our directory of 12 free creator and business calculators on CREXA."
        canonicalPath="/404"
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center space-y-8">
        <div className="w-16 h-16 rounded-2xl bg-amber-400/10 text-amber-400 border border-amber-400/20 flex items-center justify-center mx-auto">
          <AlertTriangle className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <span className="text-xs font-mono uppercase tracking-widest text-[#7C5CFC]">
            Error 404
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#F5F7FA] tracking-tight">
            Page Not Found
          </h1>
          <p className="text-sm text-[#A7B0BC] max-w-md mx-auto leading-relaxed">
            The page you are looking for may have moved, been renamed, or does not exist on CREXA.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/"
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-[#7C5CFC] text-white hover:bg-[#6847F5] transition-colors"
          >
            <Home className="w-4 h-4" />
            <span>Return to Homepage</span>
          </Link>

          <Link
            href="/calculators"
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg border border-[#252B33] bg-[#12161B] text-[#F5F7FA] hover:border-[#7C5CFC] transition-colors"
          >
            <Search className="w-4 h-4" />
            <span>Browse All Calculators</span>
          </Link>
        </div>

        <div className="pt-8 border-t border-[#252B33] text-left space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-[#A7B0BC]">
            Try One of These Popular Calculators:
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {popular.map((calc) => (
              <CalculatorCard key={calc.id} calculator={calc} compact />
            ))}
          </div>
        </div>
      </div>
    </>
  );
};
