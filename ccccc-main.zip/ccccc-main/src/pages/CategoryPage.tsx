import React from 'react';
import { SeoHead } from '../components/SeoHead';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { CalculatorCard } from '../components/CalculatorCard';
import { FaqSection } from '../components/FaqSection';
import { DynamicIcon } from '../components/DynamicIcon';
import { Link } from '../components/Link';
import { CATEGORIES_BY_ID, CATEGORIES } from '../data/categories';
import { CALCULATORS_BY_ID } from '../data/calculators';
import { CalculatorCategory } from '../types';
import { ArrowRight, BookOpen, Layers } from 'lucide-react';

interface CategoryPageProps {
  categoryId: CalculatorCategory;
}

export const CategoryPage: React.FC<CategoryPageProps> = ({ categoryId }) => {
  const category = CATEGORIES_BY_ID.get(categoryId);

  if (!category) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <h1 className="text-2xl font-bold text-[#F5F7FA]">Category Not Found</h1>
        <p className="text-sm text-[#A7B0BC]">
          The category you requested does not exist.
        </p>
        <Link
          href="/calculators"
          className="inline-block px-4 py-2 text-xs font-semibold rounded-lg bg-[#7C5CFC] text-white"
        >
          View All Calculators
        </Link>
      </div>
    );
  }

  const categoryCalculators = category.calculatorIds
    .map((id) => CALCULATORS_BY_ID.get(id))
    .filter((c): c is NonNullable<typeof c> => c !== undefined);

  const otherCategories = CATEGORIES.filter((c) => c.id !== category.id);

  return (
    <>
      <SeoHead
        title={category.seoTitle}
        description={category.seoDescription}
        canonicalPath={category.slug}
        breadcrumbs={[
          { name: 'Home', path: '/' },
          { name: 'Calculators', path: '/calculators' },
          { name: category.name, path: category.slug },
        ]}
        faqs={category.faqs}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
        <Breadcrumbs
          items={[
            { label: 'Calculators', href: '/calculators' },
            { label: category.name },
          ]}
        />

        {/* Hero */}
        <div className="border-b border-[#252B33] pb-8">
          <div className="flex items-center gap-2.5 text-xs font-semibold uppercase tracking-wider text-[#7C5CFC] mb-3">
            <DynamicIcon name={category.iconName} className="w-4 h-4" />
            <span>Category Hub</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#F5F7FA] tracking-tight">
            {category.name} Calculators
          </h1>

          <p className="mt-2 text-base text-[#3CCB8E] font-medium">
            {category.tagline}
          </p>

          <p className="mt-3 text-sm sm:text-base text-[#A7B0BC] max-w-3xl leading-relaxed">
            {category.description}
          </p>
        </div>

        {/* Calculators in Category */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-[#F5F7FA] tracking-tight flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#7C5CFC]" />
              <span>Available {category.name} Calculators ({categoryCalculators.length})</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {categoryCalculators.map((calc) => (
              <CalculatorCard key={calc.id} calculator={calc} />
            ))}
          </div>
        </section>

        {/* Key Industry Factors & Educational Insights */}
        <section className="rounded-2xl border border-[#252B33] bg-[#12161B] p-6 sm:p-8 space-y-6">
          <div className="border-b border-[#252B33] pb-4">
            <h2 className="text-lg sm:text-xl font-bold text-[#F5F7FA] flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#7C5CFC]" />
              <span>Key Levers Driving {category.name} Monetization</span>
            </h2>
            <p className="text-xs text-[#A7B0BC] mt-1">
              Essential dynamics creators should track when planning content and commercial deals.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {category.keyFactors.map((factor, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-[#181D23] border border-[#252B33] space-y-2"
              >
                <h3 className="text-sm font-bold text-[#F5F7FA]">
                  {factor.title}
                </h3>
                <p className="text-xs text-[#A7B0BC] leading-relaxed">
                  {factor.description}
                </p>
              </div>
            ))}
          </div>

          {/* Overview paragraphs */}
          <div className="pt-4 border-t border-[#252B33] space-y-3 text-xs sm:text-sm text-[#A7B0BC] leading-relaxed">
            {category.overview.map((p, idx) => (
              <p key={idx}>{p}</p>
            ))}
          </div>
        </section>

        {/* FAQs */}
        <FaqSection
          faqs={category.faqs}
          title={`${category.name} Economics FAQs`}
          subtitle={`Frequently asked questions regarding ${category.name} analytics and payouts.`}
        />

        {/* Other Categories */}
        <section className="pt-6 border-t border-[#252B33]">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-[#A7B0BC] mb-4">
            Browse Other Categories
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {otherCategories.map((c) => (
              <Link
                key={c.id}
                href={c.slug}
                className="p-3 rounded-lg border border-[#252B33] bg-[#12161B] hover:border-[#7C5CFC] transition-colors text-center block"
              >
                <span className="text-xs font-semibold text-[#F5F7FA] block">{c.name}</span>
                <span className="text-[10px] text-[#A7B0BC]">{c.calculatorIds.length} tools</span>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};
