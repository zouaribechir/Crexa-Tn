import React from 'react';
import { YouTubeMoneyCalculator } from '../components/calculators/YouTubeMoneyCalculator';
import { YouTubeRpmCalculator } from '../components/calculators/YouTubeRpmCalculator';
import { YouTubeCpmCalculator } from '../components/calculators/YouTubeCpmCalculator';
import { TikTokMoneyCalculator } from '../components/calculators/TikTokMoneyCalculator';
import { TikTokEngagementCalculator } from '../components/calculators/TikTokEngagementCalculator';
import { InstagramEngagementCalculator } from '../components/calculators/InstagramEngagementCalculator';
import { AffiliateCommissionCalculator } from '../components/calculators/AffiliateCommissionCalculator';
import { ProfitMarginCalculator } from '../components/calculators/ProfitMarginCalculator';
import { AdRevenueCalculator } from '../components/calculators/AdRevenueCalculator';
import { SubscriberGrowthCalculator } from '../components/calculators/SubscriberGrowthCalculator';
import { VideoRoiCalculator } from '../components/calculators/VideoRoiCalculator';
import { SponsorshipCalculator } from '../components/calculators/SponsorshipCalculator';
import { NotFoundPage } from './NotFoundPage';

interface CalculatorDetailPageProps {
  calculatorId: string;
}

export const CalculatorDetailPage: React.FC<CalculatorDetailPageProps> = ({ calculatorId }) => {
  switch (calculatorId) {
    case 'youtube-money-calculator':
      return <YouTubeMoneyCalculator />;
    case 'youtube-rpm-calculator':
      return <YouTubeRpmCalculator />;
    case 'youtube-cpm-calculator':
      return <YouTubeCpmCalculator />;
    case 'tiktok-money-calculator':
      return <TikTokMoneyCalculator />;
    case 'tiktok-engagement-calculator':
      return <TikTokEngagementCalculator />;
    case 'instagram-engagement-calculator':
      return <InstagramEngagementCalculator />;
    case 'affiliate-commission-calculator':
      return <AffiliateCommissionCalculator />;
    case 'profit-margin-calculator':
      return <ProfitMarginCalculator />;
    case 'ad-revenue-calculator':
      return <AdRevenueCalculator />;
    case 'subscriber-growth-calculator':
      return <SubscriberGrowthCalculator />;
    case 'video-roi-calculator':
      return <VideoRoiCalculator />;
    case 'sponsorship-calculator':
      return <SponsorshipCalculator />;
    default:
      return <NotFoundPage />;
  }
};
