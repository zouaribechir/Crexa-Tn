import React from 'react';
import { SeoHead } from '../components/SeoHead';
import { Breadcrumbs } from '../components/Breadcrumbs';

export const PrivacyPage: React.FC = () => {
  return (
    <>
      <SeoHead
        title="Privacy Policy | CREXA Platform"
        description="Learn how CREXA protects your privacy. Transparent details on Google Analytics 4, browser local storage, cookies, and our zero-data-collection policy."
        canonicalPath="/privacy"
        breadcrumbs={[
          { name: 'Home', path: '/' },
          { name: 'Privacy Policy', path: '/privacy' },
        ]}
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
        <Breadcrumbs items={[{ label: 'Privacy Policy' }]} />

        <div className="border-b border-[#252B33] pb-6 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-[#7C5CFC]">
            Data Protection & Transparency
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#F5F7FA] tracking-tight">
            Privacy Policy
          </h1>
          <p className="text-xs text-[#A7B0BC]">
            Last updated: October 2026 &middot; Effective for all visitors on https://crexa.tn
          </p>
        </div>

        <div className="space-y-8 text-sm text-[#A7B0BC] leading-relaxed">
          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              1. Our Fundamental Commitment to Privacy
            </h2>
            <p>
              CREXA (&quot;we&quot;, &quot;our&quot;, or &quot;us&quot;) operates the website https://crexa.tn. We believe your financial numbers, revenue targets, view counts, and creator assumptions are strictly your own business.
            </p>
            <p className="p-4 rounded-xl bg-[#12161B] border border-[#252B33] text-xs text-[#F5F7FA]">
              <strong>Zero Calculator Data Collection:</strong> All 12 calculator tools on CREXA operate entirely through client-side JavaScript inside your web browser. We do not transmit, log, record, or store any numbers, revenues, views, follower counts, or financial values you enter into any form field.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              2. Web Analytics (Google Analytics 4)
            </h2>
            <p>
              To understand aggregate website traffic trends, popular calculator tools, and technical device compatibility, we use Google Analytics 4 (Measurement ID: <code>G-X9QZ8256LD</code>), a web analysis service provided by Google LLC (&quot;Google&quot;).
            </p>
            <p>
              Google Analytics collects anonymized interaction data such as:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-xs">
              <li>Browser type, operating system, and screen resolution</li>
              <li>Referring website or search query URL</li>
              <li>Pages visited, route navigations, and session duration</li>
              <li>General geographic region (country or city level, with IP anonymization enabled)</li>
            </ul>
            <p className="text-xs">
              <strong>Strict Safeguard:</strong> We have configured Google Analytics to disable automatic form tracking. None of your entered calculator figures, sensitive personal details, or financial variables are ever passed to Google Analytics.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              3. Local Storage & Cookies
            </h2>
            <p>
              CREXA utilizes your browser&apos;s HTML5 Local Storage exclusively for functional user preferences:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-xs">
              <li><code>crexa_theme</code>: Saves your preferred visual theme (&apos;dark&apos; or &apos;light&apos;).</li>
              <li><code>crexa_currency</code>: Remembers your preferred display currency (e.g., USD, EUR, GBP, CAD, AUD, TND).</li>
            </ul>
            <p className="text-xs">
              This data remains on your physical device and is never uploaded to our servers. You can clear your browser local storage at any time via your browser settings.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              4. Third-Party Links
            </h2>
            <p>
              Our website may contain links to external third-party sites or documentation. We have no control over the privacy practices of third-party platforms and encourage you to review their policies directly.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              5. User Rights (GDPR & CCPA)
            </h2>
            <p>
              Under international data regulations including the European General Data Protection Regulation (GDPR) and the California Consumer Privacy Act (CCPA), you have rights regarding your personal information. Because CREXA does not maintain user accounts, databases, or identifiable user profiles, we do not possess personally identifiable records to access, modify, or delete.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              6. Contact Information
            </h2>
            <p>
              If you have any questions or feedback regarding this Privacy Policy or our engineering architecture, please contact us at:
            </p>
            <p className="text-xs font-mono text-[#7C5CFC]">
              Email: crexatn@gmail.com<br />
              Domain: https://crexa.tn
            </p>
          </section>
        </div>
      </div>
    </>
  );
};
