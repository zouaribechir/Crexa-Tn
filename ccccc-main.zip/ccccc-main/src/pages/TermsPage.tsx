import React from 'react';
import { SeoHead } from '../components/SeoHead';
import { Breadcrumbs } from '../components/Breadcrumbs';

export const TermsPage: React.FC = () => {
  return (
    <>
      <SeoHead
        title="Terms of Use | CREXA Platform"
        description="Review the terms of use for CREXA. Understand calculator estimates, numerical limitations, user responsibilities, and legal disclaimers."
        canonicalPath="/terms"
        breadcrumbs={[
          { name: 'Home', path: '/' },
          { name: 'Terms of Use', path: '/terms' },
        ]}
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
        <Breadcrumbs items={[{ label: 'Terms of Use' }]} />

        <div className="border-b border-[#252B33] pb-6 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-[#7C5CFC]">
            Legal Agreement & Disclaimers
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#F5F7FA] tracking-tight">
            Terms of Use
          </h1>
          <p className="text-xs text-[#A7B0BC]">
            Effective Date: October 2026 &middot; Platform: CREXA (https://crexa.tn)
          </p>
        </div>

        <div className="space-y-8 text-sm text-[#A7B0BC] leading-relaxed">
          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              1. Acceptance of Terms
            </h2>
            <p>
              By accessing and using CREXA (https://crexa.tn), you agree to comply with and be bound by these Terms of Use. If you do not agree with any part of these terms, please do not use our website.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              2. Nature of Calculator Tools: Estimates Only
            </h2>
            <div className="p-4 rounded-xl bg-[#12161B] border border-[#252B33] text-xs text-[#F5F7FA] space-y-2">
              <p>
                <strong>IMPORTANT NOTICE:</strong> All calculators, algorithms, formulas, and estimates provided on CREXA are strictly for educational, planning, and illustrative purposes.
              </p>
              <p>
                Actual financial outcomes—including YouTube AdSense payouts, TikTok Creator Rewards, Instagram sponsorship contracts, affiliate commissions, and business profit margins—are subject to substantial external volatility. Variables such as viewer demographics, ad-blocker rates, seasonality (Q1 vs. Q4), fluctuating advertiser demand, changes to platform terms of service, and algorithmic distribution shifts will cause real-world payouts to diverge from calculated numbers.
              </p>
            </div>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              3. No Financial, Investment, Legal, or Tax Advice
            </h2>
            <p>
              Nothing contained on CREXA constitutes professional financial, tax, accounting, investment, or legal advice. You should consult a licensed Certified Public Accountant (CPA), financial advisor, or legal attorney before making significant business investments, signing commercial sponsorship agreements, or making binding contractual commitments.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              4. User Responsibility
            </h2>
            <p>
              You assume full responsibility for any commercial decisions, marketing budgets, content production expenses, sponsorship quotes, or business plans you make based on numbers calculated through this platform. CREXA and its authors are not liable for any financial losses, missed revenue opportunities, or disputes with brand partners or platforms.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              5. Trademark & Platform Disclaimers
            </h2>
            <p>
              YouTube&trade; and Google&trade; are registered trademarks of Google LLC.<br />
              TikTok&trade; is a registered trademark of ByteDance Ltd.<br />
              Instagram&trade; is a registered trademark of Meta Platforms, Inc.
            </p>
            <p className="text-xs">
              CREXA is an independent platform and has not been authorized, sponsored, endorsed, or otherwise approved by YouTube, Google, TikTok, ByteDance, Instagram, or Meta.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              6. Limitation of Liability
            </h2>
            <p>
              To the fullest extent permitted by applicable law, CREXA disclaims all warranties, express or implied, regarding the accuracy, completeness, or reliability of any calculation. CREXA shall not be liable for any direct, indirect, incidental, consequential, or punitive damages arising from the use or inability to use this site.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-lg font-bold text-[#F5F7FA]">
              7. Governing Law & Contact
            </h2>
            <p>
              These Terms shall be governed by and construed in accordance with the applicable laws. For questions regarding these Terms, contact <code>crexatn@gmail.com</code>.
            </p>
          </section>
        </div>
      </div>
    </>
  );
};
