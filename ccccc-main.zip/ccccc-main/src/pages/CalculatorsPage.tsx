import React, { useState, useMemo } from 'react';
import { SeoHead } from '../components/SeoHead';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { CategoryFilter } from '../components/CategoryFilter';
import { CalculatorCard } from '../components/CalculatorCard';
import { CALCULATORS } from '../data/calculators';
import { CalculatorCategory } from '../types';
import { Search } from 'lucide-react';

export const CalculatorsPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<CalculatorCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = useMemo(() => {
    return CALCULATORS.filter((c) => {
      const matchesCat = activeCategory === 'all' || c.category === activeCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesQuery =
        q === '' ||
        c.name.toLowerCase().includes(q) ||
        c.shortDescription.toLowerCase().includes(q) ||
        c.categoryName.toLowerCase().includes(q) ||
        c.primaryKeyword.toLowerCase().includes(q);
      return matchesCat && matchesQuery;
    });
  }, [activeCategory, searchQuery]);

  return (
    <>
      <SeoHead
        title="All Calculators Directory: Creator & Business Tools | CREXA"
        description="Browse the complete directory of all 12 CREXA digital calculators. Calculate YouTube RPM, TikTok money, Instagram engagement, profit margins, and sponsorships."
        canonicalPath="/calculators"
        breadcrumbs={[
          { name: 'Home', path: '/' },
          { name: 'Calculators', path: '/calculators' },
        ]}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <Breadcrumbs items={[{ label: 'All Calculators' }]} />

        {/* Header */}
        <div className="border-b border-[#252B33] pb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#7C5CFC]">
            Complete Toolkit
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#F5F7FA] tracking-tight mt-1">
            Calculator Directory
          </h1>
          <p className="mt-2 text-sm text-[#A7B0BC] max-w-2xl leading-relaxed">
            Explore all 12 free mathematical calculators designed for creators, digital marketers, and online businesses.
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <CategoryFilter
            activeCategory={activeCategory}
            onSelect={setActiveCategory}
          />

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-[#A7B0BC] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter calculators..."
              className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-[#252B33] bg-[#12161B] text-xs text-[#F5F7FA] placeholder-[#A7B0BC] focus:outline-none focus:border-[#7C5CFC]"
            />
          </div>
        </div>

        {/* Results Count & Grid */}
        <div>
          <div className="flex items-center justify-between text-xs text-[#A7B0BC] mb-4">
            <span>Showing {filtered.length} of {CALCULATORS.length} calculators</span>
            {(activeCategory !== 'all' || searchQuery !== '') && (
              <button
                type="button"
                onClick={() => {
                  setActiveCategory('all');
                  setSearchQuery('');
                }}
                className="text-[#7C5CFC] hover:underline"
              >
                Clear filters
              </button>
            )}
          </div>

          {filtered.length === 0 ? (
            <div className="text-center py-16 rounded-xl border border-[#252B33] bg-[#12161B] space-y-3">
              <p className="text-sm text-[#F5F7FA] font-medium">
                No calculators match your search criteria.
              </p>
              <p className="text-xs text-[#A7B0BC]">
                Try adjusting your search query or selecting a different category.
              </p>
              <button
                type="button"
                onClick={() => {
                  setActiveCategory('all');
                  setSearchQuery('');
                }}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#7C5CFC] text-white hover:bg-[#6847F5] transition-colors"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filtered.map((calc) => (
                <CalculatorCard key={calc.id} calculator={calc} />
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};
