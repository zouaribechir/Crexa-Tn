export type CalculatorCategory =
  | 'youtube'
  | 'tiktok'
  | 'instagram'
  | 'affiliate'
  | 'business'
  | 'social-media';

export interface CalculatorFaq {
  question: string;
  answer: string;
}

export interface CalculatorDefinition {
  id: string;
  slug: string; // e.g. '/youtube-money-calculator'
  name: string;
  shortDescription: string;
  category: CalculatorCategory;
  categoryName: string;
  iconName: string;
  metaTitle: string;
  metaDescription: string;
  primaryKeyword: string;
  formulaSummary: string;
  formulaExplanation: string;
  workedExample: {
    scenario: string;
    inputs: Record<string, string>;
    calculation: string;
    result: string;
  };
  howToUseSteps: string[];
  educationalContent: {
    title: string;
    paragraphs: string[];
  };
  faqs: CalculatorFaq[];
  disclaimer: string;
  relatedCalculatorIds: string[];
  priority?: boolean;
}

export interface CategoryDefinition {
  id: CalculatorCategory;
  slug: string; // e.g. '/youtube'
  name: string;
  tagline: string;
  description: string;
  iconName: string;
  seoTitle: string;
  seoDescription: string;
  calculatorIds: string[];
  overview: string[];
  keyFactors: { title: string; description: string }[];
  faqs: CalculatorFaq[];
}

export interface Currency {
  code: string;
  symbol: string;
  name: string;
  position: 'prefix' | 'suffix';
}
