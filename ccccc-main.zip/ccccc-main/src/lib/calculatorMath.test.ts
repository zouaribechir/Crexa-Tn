import { describe, it, expect } from 'vitest';
import {
  calculateYouTubeMoney,
  calculateYouTubeRpm,
  calculateYouTubeCpm,
  calculateTikTokMoney,
  calculateTikTokEngagement,
  calculateInstagramEngagement,
  calculateAffiliateCommission,
  calculateProfitMargin,
  calculateAdRevenue,
  calculateSubscriberGrowth,
  calculateVideoRoi,
  calculateSponsorship,
  formatCurrency,
  formatNumber,
  formatPercent,
  sanitizeNumber,
} from './calculatorMath';

describe('calculatorMath library', () => {
  describe('sanitizeNumber helper', () => {
    it('handles normal numbers', () => {
      expect(sanitizeNumber(50)).toBe(50);
    });
    it('clamps negative numbers to min', () => {
      expect(sanitizeNumber(-20, 0)).toBe(0);
      expect(sanitizeNumber(-5, -10)).toBe(-5);
    });
    it('handles string numbers', () => {
      expect(sanitizeNumber('125.5')).toBe(125.5);
    });
    it('returns default for null, undefined, empty string, NaN', () => {
      expect(sanitizeNumber(null, 0, 10)).toBe(10);
      expect(sanitizeNumber(undefined, 0, 5)).toBe(5);
      expect(sanitizeNumber('', 0, 0)).toBe(0);
      expect(sanitizeNumber('abc', 0, 0)).toBe(0);
      expect(sanitizeNumber(NaN, 0, 0)).toBe(0);
    });
  });

  describe('1. calculateYouTubeMoney', () => {
    it('calculates correctly for 100,000 views at $4 RPM', () => {
      const res = calculateYouTubeMoney({ views: 100000, rpm: 4 });
      expect(res.estimatedEarnings).toBe(400);
      expect(res.monthlyEarnings).toBe(400);
      expect(res.yearlyEarnings).toBe(4800);
    });

    it('handles zero views and zero RPM without errors', () => {
      const res = calculateYouTubeMoney({ views: 0, rpm: 0 });
      expect(res.estimatedEarnings).toBe(0);
      expect(res.monthlyEarnings).toBe(0);
      expect(res.yearlyEarnings).toBe(0);
      expect(Number.isFinite(res.estimatedEarnings)).toBe(true);
    });

    it('rejects negative numbers safely', () => {
      const res = calculateYouTubeMoney({ views: -5000, rpm: -3 });
      expect(res.estimatedEarnings).toBe(0);
    });
  });

  describe('2. calculateYouTubeRpm', () => {
    it('calculates RPM from $500 earned on 125,000 views ($4.00 RPM)', () => {
      const res = calculateYouTubeRpm({ revenue: 500, views: 125000 });
      expect(res.rpm).toBe(4);
      expect(res.earningsPerView).toBe(0.004);
    });

    it('safely handles zero views without division by zero', () => {
      const res = calculateYouTubeRpm({ revenue: 100, views: 0 });
      expect(res.rpm).toBe(0);
      expect(res.earningsPerView).toBe(0);
    });

    it('handles fractional revenue and views', () => {
      const res = calculateYouTubeRpm({ revenue: 12.5, views: 2500 });
      expect(res.rpm).toBe(5);
    });
  });

  describe('3. calculateYouTubeCpm', () => {
    it('calculates advertiser CPM correctly ($200 cost on 25,000 impressions = $8 CPM)', () => {
      const res = calculateYouTubeCpm({ cost: 200, impressions: 25000 });
      expect(res.cpm).toBe(8);
      expect(res.costPerImpression).toBe(0.008);
    });

    it('safely handles zero impressions', () => {
      const res = calculateYouTubeCpm({ cost: 100, impressions: 0 });
      expect(res.cpm).toBe(0);
      expect(res.costPerImpression).toBe(0);
    });
  });

  describe('4. calculateTikTokMoney', () => {
    it('estimates TikTok creator earnings for 1,000,000 views at $0.03 RPM', () => {
      const res = calculateTikTokMoney({ views: 1000000, estimatedRpm: 0.03 });
      expect(res.estimatedEarnings).toBe(30);
      expect(res.effectivePerView).toBe(0.00003);
    });

    it('handles zero views safely', () => {
      const res = calculateTikTokMoney({ views: 0, estimatedRpm: 0.05 });
      expect(res.estimatedEarnings).toBe(0);
      expect(res.effectivePerView).toBe(0);
    });
  });

  describe('5. calculateTikTokEngagement', () => {
    it('calculates engagement using views as denominator', () => {
      const res = calculateTikTokEngagement({
        likes: 5000,
        comments: 200,
        shares: 300,
        saves: 100,
        denominatorType: 'views',
        denominatorValue: 50000,
      });
      // (5000 + 200 + 300 + 100) / 50000 = 5600 / 50000 = 11.2%
      expect(res.totalInteractions).toBe(5600);
      expect(res.engagementRatePercent).toBe(11.2);
    });

    it('calculates engagement using followers as denominator', () => {
      const res = calculateTikTokEngagement({
        likes: 2000,
        comments: 100,
        shares: 50,
        denominatorType: 'followers',
        denominatorValue: 20000,
      });
      // 2150 / 20000 = 10.75%
      expect(res.engagementRatePercent).toBe(10.75);
    });

    it('handles zero denominator without NaN', () => {
      const res = calculateTikTokEngagement({
        likes: 100,
        comments: 10,
        shares: 5,
        denominatorType: 'views',
        denominatorValue: 0,
      });
      expect(res.engagementRatePercent).toBe(0);
      expect(Number.isNaN(res.engagementRatePercent)).toBe(false);
    });
  });

  describe('6. calculateInstagramEngagement', () => {
    it('calculates engagement rate based on followers', () => {
      const res = calculateInstagramEngagement({
        likes: 1500,
        comments: 100,
        followers: 50000,
      });
      // 1600 / 50000 = 3.2%
      expect(res.totalInteractions).toBe(1600);
      expect(res.engagementRatePercent).toBe(3.2);
      expect(res.benchmarkStatus).toBe('good');
    });

    it('safely handles zero followers', () => {
      const res = calculateInstagramEngagement({
        likes: 100,
        comments: 10,
        followers: 0,
      });
      expect(res.engagementRatePercent).toBe(0);
    });
  });

  describe('7. calculateAffiliateCommission', () => {
    it('calculates affiliate commission correctly (50 sales * $80 AOV * 10% rate)', () => {
      const res = calculateAffiliateCommission({
        salesCount: 50,
        averageOrderValue: 80,
        commissionRatePercent: 10,
      });
      expect(res.grossSales).toBe(4000);
      expect(res.commissionEarned).toBe(400);
      expect(res.averageCommissionPerSale).toBe(8);
    });

    it('handles zero sales count', () => {
      const res = calculateAffiliateCommission({
        salesCount: 0,
        averageOrderValue: 100,
        commissionRatePercent: 15,
      });
      expect(res.grossSales).toBe(0);
      expect(res.commissionEarned).toBe(0);
      expect(res.averageCommissionPerSale).toBe(0);
    });
  });

  describe('8. calculateProfitMargin', () => {
    it('calculates profit margin and markup for profitable product ($100 revenue, $40 cost)', () => {
      const res = calculateProfitMargin({ revenue: 100, cost: 40 });
      expect(res.grossProfit).toBe(60);
      expect(res.profitMarginPercent).toBe(60);
      expect(res.markupPercent).toBe(150);
      expect(res.isProfitable).toBe(true);
    });

    it('handles zero revenue safely without division by zero', () => {
      const res = calculateProfitMargin({ revenue: 0, cost: 50 });
      expect(res.grossProfit).toBe(-50);
      expect(res.profitMarginPercent).toBe(0);
      expect(res.markupPercent).toBe(-100);
      expect(res.isProfitable).toBe(false);
    });

    it('handles zero cost safely', () => {
      const res = calculateProfitMargin({ revenue: 100, cost: 0 });
      expect(res.grossProfit).toBe(100);
      expect(res.profitMarginPercent).toBe(100);
      expect(res.markupPercent).toBe(0);
    });
  });

  describe('9. calculateAdRevenue', () => {
    it('calculates revenue for 500,000 pageviews at $6.50 RPM', () => {
      const res = calculateAdRevenue({ volume: 500000, ratePerThousand: 6.5 });
      expect(res.estimatedRevenue).toBe(3250);
      expect(res.yearlyRevenue).toBe(39000);
    });

    it('handles 0 volume safely', () => {
      const res = calculateAdRevenue({ volume: 0, ratePerThousand: 10 });
      expect(res.estimatedRevenue).toBe(0);
    });
  });

  describe('10. calculateSubscriberGrowth', () => {
    it('projects growth correctly (10,000 current, +1,200 gained, -200 lost/mo, 6 months)', () => {
      const res = calculateSubscriberGrowth({
        currentSubscribers: 10000,
        newSubscribersPerMonth: 1200,
        lostSubscribersPerMonth: 200,
        forecastMonths: 6,
      });
      // net monthly: +1,000
      // growth rate: 10%
      // 6 months projection: 10,000 + 6,000 = 16,000
      expect(res.netMonthlyGrowth).toBe(1000);
      expect(res.monthlyGrowthRatePercent).toBe(10);
      expect(res.projectedSubscribers).toBe(16000);
      expect(res.totalGained).toBe(7200);
      expect(res.totalLost).toBe(1200);
    });

    it('handles negative net growth (churn > new subscribers)', () => {
      const res = calculateSubscriberGrowth({
        currentSubscribers: 5000,
        newSubscribersPerMonth: 100,
        lostSubscribersPerMonth: 300,
        forecastMonths: 10,
      });
      // net monthly: -200
      // 10 months: 5,000 - 2,000 = 3,000
      expect(res.netMonthlyGrowth).toBe(-200);
      expect(res.projectedSubscribers).toBe(3000);
    });
  });

  describe('11. calculateVideoRoi', () => {
    it('calculates positive ROI ($1,000 production + $500 promo, $3,000 revenue)', () => {
      const res = calculateVideoRoi({
        productionCost: 1000,
        promotionSpend: 500,
        attributableRevenue: 3000,
      });
      expect(res.totalInvestment).toBe(1500);
      expect(res.netReturn).toBe(1500);
      expect(res.roiPercent).toBe(100);
      expect(res.isPositive).toBe(true);
    });

    it('handles zero investment without division by zero', () => {
      const res = calculateVideoRoi({
        productionCost: 0,
        promotionSpend: 0,
        attributableRevenue: 500,
      });
      expect(res.totalInvestment).toBe(0);
      expect(res.netReturn).toBe(500);
      expect(res.roiPercent).toBe(0);
      expect(Number.isFinite(res.roiPercent)).toBe(true);
    });
  });

  describe('12. calculateSponsorship', () => {
    it('calculates sponsorship quote range (50,000 views at $25 CPM)', () => {
      const res = calculateSponsorship({
        estimatedViews: 50000,
        baseCpm: 25,
        deliverableMultiplier: 1.0,
        exclusivityMultiplier: 1.0,
        usageRightsMultiplier: 1.0,
      });
      // baseFee = 50 * 25 = $1250
      expect(res.baseFee).toBe(1250);
      expect(res.recommendedQuote).toBe(1250);
      expect(res.lowEstimate).toBe(1062.5);
      expect(res.highEstimate).toBe(1562.5);
    });

    it('accounts for deliverable and exclusivity multipliers', () => {
      const res = calculateSponsorship({
        estimatedViews: 20000,
        baseCpm: 30,
        deliverableMultiplier: 1.5, // dedicated video
        exclusivityMultiplier: 1.2, // category exclusivity
        usageRightsMultiplier: 1.0,
      });
      // base: 20 * 30 = 600
      // recommended: 600 * 1.5 * 1.2 = 1080
      expect(res.baseFee).toBe(600);
      expect(res.recommendedQuote).toBe(1080);
    });
  });

  describe('formatters', () => {
    it('formats currency correctly', () => {
      expect(formatCurrency(1250.5)).toBe('$1,250.50');
      expect(formatCurrency(0)).toBe('$0.00');
      expect(formatCurrency(100, '€')).toBe('€100.00');
    });

    it('formats numbers with commas', () => {
      expect(formatNumber(1500000)).toBe('1,500,000');
      expect(formatNumber(42.345, 1)).toBe('42.3');
    });

    it('formats percentages', () => {
      expect(formatPercent(12.3456)).toBe('12.35%');
      expect(formatPercent(0)).toBe('0.00%');
    });
  });
});
