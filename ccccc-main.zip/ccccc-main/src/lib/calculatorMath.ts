/**
 * Core mathematical calculation utilities for CREXA calculators.
 * All functions are pure, robustly handle edge cases, and never return NaN or Infinity.
 */

export function roundFloat(val: number, decimals: number = 4): number {
  if (!Number.isFinite(val)) return 0;
  const factor = 10 ** decimals;
  return Math.round(val * factor) / factor;
}

export function sanitizeNumber(value: unknown, min: number = 0, defaultValue: number = 0): number {
  if (value === undefined || value === null || value === '') {
    return defaultValue;
  }
  const num = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(num)) {
    return defaultValue;
  }
  return Math.max(min, num);
}

// 1. YouTube Money Calculator
export interface YouTubeMoneyInputs {
  views: number;
  rpm: number;
  timeframe?: 'daily' | 'monthly' | 'total';
}

export interface YouTubeMoneyResult {
  estimatedEarnings: number;
  dailyEarnings: number;
  monthlyEarnings: number;
  yearlyEarnings: number;
}

export function calculateYouTubeMoney(inputs: YouTubeMoneyInputs): YouTubeMoneyResult {
  const views = sanitizeNumber(inputs.views, 0);
  const rpm = sanitizeNumber(inputs.rpm, 0);
  const timeframe = inputs.timeframe || 'total';

  const baseEarnings = (views / 1000) * rpm;

  let daily = 0;
  let monthly = 0;
  let yearly = 0;

  if (timeframe === 'daily') {
    daily = baseEarnings;
    monthly = daily * 30.417;
    yearly = daily * 365;
  } else if (timeframe === 'monthly') {
    monthly = baseEarnings;
    daily = monthly / 30.417;
    yearly = monthly * 12;
  } else {
    // Total views entered
    daily = baseEarnings / 30.417;
    monthly = baseEarnings;
    yearly = baseEarnings * 12;
  }

  return {
    estimatedEarnings: baseEarnings,
    dailyEarnings: Math.max(0, daily),
    monthlyEarnings: Math.max(0, monthly),
    yearlyEarnings: Math.max(0, yearly),
  };
}

// 2. YouTube RPM Calculator
export interface YouTubeRpmInputs {
  revenue: number;
  views: number;
}

export interface YouTubeRpmResult {
  rpm: number;
  earningsPerView: number;
}

export function calculateYouTubeRpm(inputs: YouTubeRpmInputs): YouTubeRpmResult {
  const revenue = sanitizeNumber(inputs.revenue, 0);
  const views = sanitizeNumber(inputs.views, 0);

  if (views <= 0) {
    return { rpm: 0, earningsPerView: 0 };
  }

  const rpm = (revenue / views) * 1000;
  const earningsPerView = revenue / views;

  return {
    rpm: Number.isFinite(rpm) ? rpm : 0,
    earningsPerView: Number.isFinite(earningsPerView) ? earningsPerView : 0,
  };
}

// 3. YouTube CPM Calculator
export interface YouTubeCpmInputs {
  cost: number;
  impressions: number;
}

export interface YouTubeCpmResult {
  cpm: number;
  costPerImpression: number;
}

export function calculateYouTubeCpm(inputs: YouTubeCpmInputs): YouTubeCpmResult {
  const cost = sanitizeNumber(inputs.cost, 0);
  const impressions = sanitizeNumber(inputs.impressions, 0);

  if (impressions <= 0) {
    return { cpm: 0, costPerImpression: 0 };
  }

  const cpm = (cost / impressions) * 1000;
  const costPerImpression = cost / impressions;

  return {
    cpm: Number.isFinite(cpm) ? cpm : 0,
    costPerImpression: Number.isFinite(costPerImpression) ? costPerImpression : 0,
  };
}

// 4. TikTok Money Calculator
export interface TikTokMoneyInputs {
  views: number;
  estimatedRpm: number;
}

export interface TikTokMoneyResult {
  estimatedEarnings: number;
  dailyEstimate: number;
  monthlyEstimate: number;
  effectivePerView: number;
}

export function calculateTikTokMoney(inputs: TikTokMoneyInputs): TikTokMoneyResult {
  const views = sanitizeNumber(inputs.views, 0);
  const rpm = sanitizeNumber(inputs.estimatedRpm, 0);

  const estimatedEarnings = (views / 1000) * rpm;
  const dailyEstimate = estimatedEarnings / 30;
  const monthlyEstimate = estimatedEarnings;
  const effectivePerView = views > 0 ? estimatedEarnings / views : 0;

  return {
    estimatedEarnings: Number.isFinite(estimatedEarnings) ? estimatedEarnings : 0,
    dailyEstimate: Number.isFinite(dailyEstimate) ? dailyEstimate : 0,
    monthlyEstimate: Number.isFinite(monthlyEstimate) ? monthlyEstimate : 0,
    effectivePerView: Number.isFinite(effectivePerView) ? effectivePerView : 0,
  };
}

// 5. TikTok Engagement Rate Calculator
export interface TikTokEngagementInputs {
  likes: number;
  comments: number;
  shares: number;
  saves?: number;
  denominatorType: 'views' | 'followers';
  denominatorValue: number;
}

export interface TikTokEngagementResult {
  totalInteractions: number;
  engagementRatePercent: number;
  likesRatio: number;
  commentsRatio: number;
  sharesRatio: number;
}

export function calculateTikTokEngagement(inputs: TikTokEngagementInputs): TikTokEngagementResult {
  const likes = sanitizeNumber(inputs.likes, 0);
  const comments = sanitizeNumber(inputs.comments, 0);
  const shares = sanitizeNumber(inputs.shares, 0);
  const saves = sanitizeNumber(inputs.saves, 0);
  const denominator = sanitizeNumber(inputs.denominatorValue, 0);

  const totalInteractions = likes + comments + shares + saves;

  if (denominator <= 0) {
    return {
      totalInteractions,
      engagementRatePercent: 0,
      likesRatio: 0,
      commentsRatio: 0,
      sharesRatio: 0,
    };
  }

  const engagementRate = roundFloat((totalInteractions / denominator) * 100);
  const likesRatio = roundFloat((likes / denominator) * 100);
  const commentsRatio = roundFloat((comments / denominator) * 100);
  const sharesRatio = roundFloat((shares / denominator) * 100);

  return {
    totalInteractions,
    engagementRatePercent: Number.isFinite(engagementRate) ? engagementRate : 0,
    likesRatio: Number.isFinite(likesRatio) ? likesRatio : 0,
    commentsRatio: Number.isFinite(commentsRatio) ? commentsRatio : 0,
    sharesRatio: Number.isFinite(sharesRatio) ? sharesRatio : 0,
  };
}

// 6. Instagram Engagement Rate Calculator
export interface InstagramEngagementInputs {
  likes: number;
  comments: number;
  followers: number;
}

export interface InstagramEngagementResult {
  totalInteractions: number;
  engagementRatePercent: number;
  benchmarkStatus: 'low' | 'good' | 'high';
}

export function calculateInstagramEngagement(inputs: InstagramEngagementInputs): InstagramEngagementResult {
  const likes = sanitizeNumber(inputs.likes, 0);
  const comments = sanitizeNumber(inputs.comments, 0);
  const followers = sanitizeNumber(inputs.followers, 0);

  const totalInteractions = likes + comments;

  if (followers <= 0) {
    return {
      totalInteractions,
      engagementRatePercent: 0,
      benchmarkStatus: 'low',
    };
  }

  const rate = (totalInteractions / followers) * 100;
  const validRate = Number.isFinite(rate) ? rate : 0;

  let benchmarkStatus: 'low' | 'good' | 'high' = 'good';
  if (validRate < 1.5) {
    benchmarkStatus = 'low';
  } else if (validRate > 4.0) {
    benchmarkStatus = 'high';
  }

  return {
    totalInteractions,
    engagementRatePercent: validRate,
    benchmarkStatus,
  };
}

// 7. Affiliate Commission Calculator
export interface AffiliateCommissionInputs {
  salesCount: number;
  averageOrderValue: number;
  commissionRatePercent: number;
}

export interface AffiliateCommissionResult {
  grossSales: number;
  commissionEarned: number;
  averageCommissionPerSale: number;
}

export function calculateAffiliateCommission(inputs: AffiliateCommissionInputs): AffiliateCommissionResult {
  const salesCount = sanitizeNumber(inputs.salesCount, 0);
  const aov = sanitizeNumber(inputs.averageOrderValue, 0);
  const rate = sanitizeNumber(inputs.commissionRatePercent, 0);

  const grossSales = salesCount * aov;
  const commissionEarned = grossSales * (rate / 100);
  const perSale = salesCount > 0 ? commissionEarned / salesCount : 0;

  return {
    grossSales: Number.isFinite(grossSales) ? grossSales : 0,
    commissionEarned: Number.isFinite(commissionEarned) ? commissionEarned : 0,
    averageCommissionPerSale: Number.isFinite(perSale) ? perSale : 0,
  };
}

// 8. Profit Margin Calculator
export interface ProfitMarginInputs {
  revenue: number;
  cost: number;
}

export interface ProfitMarginResult {
  grossProfit: number;
  profitMarginPercent: number;
  markupPercent: number;
  isProfitable: boolean;
}

export function calculateProfitMargin(inputs: ProfitMarginInputs): ProfitMarginResult {
  const revenue = sanitizeNumber(inputs.revenue, 0);
  const cost = sanitizeNumber(inputs.cost, 0);

  const grossProfit = revenue - cost;

  let profitMarginPercent = 0;
  if (revenue > 0) {
    profitMarginPercent = (grossProfit / revenue) * 100;
  }

  let markupPercent = 0;
  if (cost > 0) {
    markupPercent = (grossProfit / cost) * 100;
  }

  return {
    grossProfit: Number.isFinite(grossProfit) ? grossProfit : 0,
    profitMarginPercent: Number.isFinite(profitMarginPercent) ? profitMarginPercent : 0,
    markupPercent: Number.isFinite(markupPercent) ? markupPercent : 0,
    isProfitable: grossProfit >= 0,
  };
}

// 9. Ad Revenue Calculator
export interface AdRevenueInputs {
  volume: number; // pageviews or ad impressions
  ratePerThousand: number; // RPM or CPM
  metricType?: 'pageviews' | 'impressions';
}

export interface AdRevenueResult {
  estimatedRevenue: number;
  dailyRevenue: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
}

export function calculateAdRevenue(inputs: AdRevenueInputs): AdRevenueResult {
  const volume = sanitizeNumber(inputs.volume, 0);
  const rate = sanitizeNumber(inputs.ratePerThousand, 0);

  const estimatedRevenue = (volume / 1000) * rate;
  const daily = estimatedRevenue / 30;
  const monthly = estimatedRevenue;
  const yearly = estimatedRevenue * 12;

  return {
    estimatedRevenue: Number.isFinite(estimatedRevenue) ? estimatedRevenue : 0,
    dailyRevenue: Number.isFinite(daily) ? daily : 0,
    monthlyRevenue: Number.isFinite(monthly) ? monthly : 0,
    yearlyRevenue: Number.isFinite(yearly) ? yearly : 0,
  };
}

// 10. Subscriber Growth Calculator
export interface SubscriberGrowthInputs {
  currentSubscribers: number;
  newSubscribersPerMonth: number;
  lostSubscribersPerMonth: number;
  forecastMonths: number;
}

export interface SubscriberGrowthResult {
  netMonthlyGrowth: number;
  monthlyGrowthRatePercent: number;
  projectedSubscribers: number;
  totalGained: number;
  totalLost: number;
}

export function calculateSubscriberGrowth(inputs: SubscriberGrowthInputs): SubscriberGrowthResult {
  const current = sanitizeNumber(inputs.currentSubscribers, 0);
  const gained = sanitizeNumber(inputs.newSubscribersPerMonth, 0);
  const lost = sanitizeNumber(inputs.lostSubscribersPerMonth, 0);
  const months = Math.min(60, sanitizeNumber(inputs.forecastMonths, 1, 1));

  const netMonthly = gained - lost;
  let growthRatePercent = 0;
  if (current > 0) {
    growthRatePercent = (netMonthly / current) * 100;
  }

  const projected = Math.max(0, current + netMonthly * months);
  const totalGained = gained * months;
  const totalLost = lost * months;

  return {
    netMonthlyGrowth: netMonthly,
    monthlyGrowthRatePercent: Number.isFinite(growthRatePercent) ? growthRatePercent : 0,
    projectedSubscribers: Number.isFinite(projected) ? projected : 0,
    totalGained,
    totalLost,
  };
}

// 11. Video ROI Calculator
export interface VideoRoiInputs {
  productionCost: number;
  promotionSpend: number;
  attributableRevenue: number;
}

export interface VideoRoiResult {
  totalInvestment: number;
  netReturn: number;
  roiPercent: number;
  isPositive: boolean;
}

export function calculateVideoRoi(inputs: VideoRoiInputs): VideoRoiResult {
  const production = sanitizeNumber(inputs.productionCost, 0);
  const promotion = sanitizeNumber(inputs.promotionSpend, 0);
  const revenue = sanitizeNumber(inputs.attributableRevenue, 0);

  const totalInvestment = production + promotion;
  const netReturn = revenue - totalInvestment;

  let roiPercent = 0;
  if (totalInvestment > 0) {
    roiPercent = (netReturn / totalInvestment) * 100;
  }

  return {
    totalInvestment: Number.isFinite(totalInvestment) ? totalInvestment : 0,
    netReturn: Number.isFinite(netReturn) ? netReturn : 0,
    roiPercent: Number.isFinite(roiPercent) ? roiPercent : 0,
    isPositive: netReturn >= 0,
  };
}

// 12. Sponsorship Calculator
export interface SponsorshipInputs {
  estimatedViews: number;
  views?: number;
  baseCpm: number;
  deliverableMultiplier?: number; // e.g. 1.0 (60s integrated), 1.5 (dedicated), 0.6 (short/reel)
  exclusivityMultiplier?: number; // e.g. 1.0 (none), 1.25 (30-day category exclusivity)
  usageRightsMultiplier?: number; // e.g. 1.0 (organic only), 1.30 (paid ads whitelist)
}

export interface SponsorshipResult {
  baseFee: number;
  recommendedQuote: number;
  lowEstimate: number;
  highEstimate: number;
}

export function calculateSponsorship(inputs: SponsorshipInputs): SponsorshipResult {
  const views = sanitizeNumber(inputs.views || inputs.estimatedViews, 0);
  const cpm = sanitizeNumber(inputs.baseCpm, 0);
  const delivMul = sanitizeNumber(inputs.deliverableMultiplier, 0.1, 1.0);
  const exclMul = sanitizeNumber(inputs.exclusivityMultiplier, 0.1, 1.0);
  const rightsMul = sanitizeNumber(inputs.usageRightsMultiplier, 0.1, 1.0);

  const baseFee = (views / 1000) * cpm;
  const totalMultiplier = delivMul * exclMul * rightsMul;
  const recommendedQuote = baseFee * totalMultiplier;
  const lowEstimate = recommendedQuote * 0.85;
  const highEstimate = recommendedQuote * 1.25;

  return {
    baseFee: Number.isFinite(baseFee) ? baseFee : 0,
    recommendedQuote: Number.isFinite(recommendedQuote) ? recommendedQuote : 0,
    lowEstimate: Number.isFinite(lowEstimate) ? lowEstimate : 0,
    highEstimate: Number.isFinite(highEstimate) ? highEstimate : 0,
  };
}

// Display formatters
export function formatCurrency(value: number, symbol: string = '$', position: 'prefix' | 'suffix' = 'prefix'): string {
  if (!Number.isFinite(value)) return `${symbol}0.00`;
  const formatted = Math.abs(value).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const sign = value < 0 ? '-' : '';
  return position === 'prefix' ? `${sign}${symbol}${formatted}` : `${sign}${formatted} ${symbol}`;
}

export function formatNumber(value: number, decimals: number = 0): string {
  if (!Number.isFinite(value)) return '0';
  return value.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function formatPercent(value: number, decimals: number = 2): string {
  if (!Number.isFinite(value)) return '0.00%';
  return `${value.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}%`;
}
